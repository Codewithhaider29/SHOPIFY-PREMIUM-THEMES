Within the folder there are 3 items � Readme.txt, Documentation folder and a .zip file. 
The file you have to upload is fashionplanet.zip.  Kindly refer  our documentation for installing the theme and customization. If you need any assistance, plz contact us through manager@iamdesigning.com
