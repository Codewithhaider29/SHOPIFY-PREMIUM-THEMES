Within the main folder [themeforest-beauty-store-shopify-theme.zip] there will be following folder and files.

Documentation
Readme.txt
Log.txt
demo-01.zip, demo-02.zip, demo-03.zip ,,, demo-15.zip

-------------------------------------------------------------------
https://themessupport.com/wedesigntech/shopify/beauty-store/

Kindly refer our documentation for installing the theme and doing customization. 
If you need any assistance, plz contact us through support@wedesignthemes.com


Thank You.
DesignThemes.










