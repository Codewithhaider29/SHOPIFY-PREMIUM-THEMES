// Section with Editor
$(document).on('shopify:section:load', function(e){ 
  $('#' + e.target.id).find('[data-section]').sectionJs();
}).ready(function() {
  $('[data-section]').each(function(){ $(this).sectionJs() });
});


$.fn.sectionJs = function(){
  var $this = this;
  
  if($this.data('section') == "headerSection") {
    $this.headerScript();
  }else if($this.data('section') == "heroSlickSlider") {
    $this.find('.hero-slider-active-1').heroSlickSlider();
    
  }else if($this.data('section') == "heroSlickSlider2") {
    $this.find('.hero-slider-active-2').heroSlickSlider2();
    
  } else if($this.data('section') == "bannercollection") {
    $this.find('.categories-slider-1').bannercollection();
    
  }else if($this.data('section') == "ProudctCarouselSlider") {
    $this.find('.product-slider-active-1').ProudctCarouselSlider();
    $this.daily_deal_of_the_day_fn();
    
  }else if($this.data('section') == "CarouselSlider") {
    $this.find('.product-slider-active-1').ProudctCarouselSlider();
    
  }else if($this.data('section') == "CarouselTestmonial") {
    $this.find('.testimonial-active-1').CarouselTestmonial();
    
  }else if($this.data('section') == "home_blog") {
    $this.find('.home-blog-active').home_blog();
  }else if($this.data('section') == "testmonial_with_blog") {
    $this.find('.testimonial-active-2').testmonial_with_blog();
  }else if($this.data('section') == "blog__template") {
    $this.blog__template();
  }else if($this.data('section') == "testmonial_section") {
    $this.find('.testimonial-active-3').testmonial_section();
  }else if($this.data('section') == "welcome__section") {
    $this.find('.total-years .count').welcome__section();
  }else if($this.data('section') == "mission__section") {
    $this.mission_section_js_active();
  } else if($this.data('section') == "related_product__section") {
    $this.related_product__section_active();
  }else if($this.data('section') == "funfact__section") {
     $this.find('.count').funfact__section_active_js();
  }else if($this.data('section') == "productPage_section") {
      $this.productPage();
  }
  else{} 

}


$.fn.blog__template = function() {
  // Isotope active
  $('.grid').imagesLoaded(function() {
    // init Isotope
    var $grid = $('.grid').isotope({
      itemSelector: '.grid-item',
      percentPosition: true,
      layoutMode: 'masonry',
      masonry: {
        // use outer width of grid-sizer for columnWidth
        columnWidth: '.grid-item',
      }
    });
  });
  
  
};

$.fn.daily_deal_of_the_day_fn = function() {
  
  $('[data-countdown]').each(function() {
    var $this = $(this), finalDate = $(this).data('countdown');
    $this.countdown(finalDate, function(event) {
      $this.html(event.strftime('<div class="count"><p>%D</p><span>days</span></div><div class="count"><p>%H</p><span>Hour</span></div><div class="count"><p>%M</p><span>Mint</span></div><div class="count"><p>%S</p><span>Sec</span></div>'));
    });
  });
  
  
};

// All Slick Prototype
$.fn.heroSlickSlider = function() {
  var $zaroSlickSlider = this;
  $zaroSlickSlider.slick({
    fade: true,
    loop: true,
    dots: false,
    prevArrow: '<span class="slider-icon-1-prev"><i class="far fa-chevron-left"></i></span>',
    nextArrow: '<span class="slider-icon-1-next"><i class="far fa-chevron-right"></i></span>',
  });
  
  
  

};

$.fn.heroSlickSlider2 = function() {
  var $zaroSlickSlider = this;
  $zaroSlickSlider.slick({
    fade: true,
    loop: true,
    dots: true,
    arrows: false,
  });
};

$.fn.testmonial_with_blog = function() {
    var $zaroSlickSlider = this;
 
  	var $status = $('.pagingInfo');
	var $slickElement = $('.testimonial-active-2');
    $slickElement.on('init reInit afterChange', function (event, slick, currentSlide, nextSlide) {
      //currentSlide is undefined on init -- set it to 0 in this case (currentSlide is 0 based)
      var i = (currentSlide ? currentSlide : 0) + 1;
      $status.text('0' + i + ' ------ ' + '0' +  slick.slideCount);
    });

    $zaroSlickSlider.slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      fade: false,
      loop: true,
      dots: false,
      arrows: true,
      prevArrow: '<span class="testimonial-icon-2-prev"><i class="far fa-angle-left"></i></span>',
      nextArrow: '<span class="testimonial-icon-2-next"><i class="far fa-angle-right"></i></span>',
    });
};

$.fn.home_blog = function() {
    var $zaroSlickSlider = this;
 
  	var $status = $('.pagingInfo');
	var $slickElement = $('.home-blog-active');
    $slickElement.on('init reInit afterChange', function (event, slick, currentSlide, nextSlide) {
      //currentSlide is undefined on init -- set it to 0 in this case (currentSlide is 0 based)
      var i = (currentSlide ? currentSlide : 0) + 1;
      $status.text('0' + i + ' ------ ' + '0' +  slick.slideCount);
    });

    $zaroSlickSlider.slick({
      slidesToShow: 3,
      slidesToScroll: 1,
      fade: false,
      loop: true,
      dots: false,
      arrows: true,
      margin:15,
            responsive: [
            {
                breakpoint: 1199,
                settings: {
                    slidesToShow: 3, 
                }
            },
            {
                breakpoint: 991,
                settings: {
                    slidesToShow: 2,
                }
            },
            {
                breakpoint: 767,
                settings: {
                    slidesToShow: 2,
                }
            },
            {
                breakpoint: 575,
                settings: {
                    slidesToShow: 1,
                }
            }
        ],
      prevArrow: '<span class="testimonial-icon-2-prev"><i class="far fa-angle-left"></i></span>',
      nextArrow: '<span class="testimonial-icon-2-next"><i class="far fa-angle-right"></i></span>',
    });
};







$.fn.testmonial_section = function() {
    var $zaroSlickSlider = this;
 
    $zaroSlickSlider.slick({
      slidesToShow: 3,
      slidesToScroll: 1,
      fade: false,
      loop: true,
      dots: true,
      arrows: false,
      responsive: [
            {
                breakpoint: 1199,
                settings: {
                    slidesToShow: 3, 
                }
            },
            {
                breakpoint: 991,
                settings: {
                    slidesToShow: 2,
                }
            },
            {
                breakpoint: 767,
                settings: {
                    slidesToShow: 1,
                }
            },
            {
                breakpoint: 575,
                settings: {
                    slidesToShow: 1,
                }
            }
        ]
    });
};



$.fn.funfact__section_active_js = function(){
  /*---- CounterUp ----*/
  this.counterUp({
    delay: 10,
    time: 2000
  });
  

};




$.fn.mission_section_js_active = function() {
  /*------ SVG img active ----*/
  SVGInject(document.querySelectorAll('img.injectable'), {});
  /*----------------------------------------
        SVG Inject With Vivus(After Inject) 
    ------------------------------------------*/
  SVGInject(document.querySelectorAll("img.svgInject"), {
    makeIdsUnique: true,
    afterInject: function (img, svg) {
      new Vivus(svg, {
        duration: 80
      });
    }
  });

  /* Vivus On Hover */
  $('[data-vivus-hover]').hover(function () {
    var svg = $(this).find('svg')[0];
    new Vivus(svg, {
      duration: 50
    });
  })

  
};

// Product Page
$.fn.productPage = function(){
  
  

  var $OwlMenuProduct = $('.active_thumb_carousel');
  if($OwlMenuProduct.length > 0){
    $OwlMenuProduct.owlCarousel({
      loop: false,
      nav: true,dots:false,
      margin:15,
      autoplay: false,
      autoplayTimeout: 5000,
      navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
      item: 4,
      responsive: {
        0: {
          items: 2
        },
        480: {
          items: 3
        },
        992: {
          items: 3,
        },
        1170: {
          items: 3,
        },
        1200: {
          items: 3
        }
      }
    });

  
  };

  
};


$.fn.related_product__section_active = function(){
  
  var $OwlMenuProduct = $('.releted-pro-active');
  if($OwlMenuProduct.length > 0){
    $OwlMenuProduct.owlCarousel({
        loop: true,
        nav: true,
        
        dots: false,
        smartSpeed: 1500,
        navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
        margin: 20,
        responsive: {
            0: {
                items: 1,
                autoplay: true,
                smartSpeed: 500
            },
            480: {
                items: 2
            },
            768: {
                items: 2
            },
            992: {
                items: 5
            },
            1200: {
              items: 5
            }
        }
    });
  };
  


};


$.fn.welcome__section = function() {
  /*---- CounterUp ----*/
  this.counterUp({
    delay: 10,
    time: 2000
  });

  /*---- Mouse Parallax ---------*/
  var scene = $('#scene');
  if(scene.length > 0) {
    var parallaxInstance = new Parallax(scene.get(0), {
      relativeInput: true,
      hoverOnly: true,
    });
  }
  
  
};






$.fn.ProudctCarouselSlider = function() {
  var $zaroSlickSlider = this;
  $zaroSlickSlider.slick({
        fade: false,
        loop: true,
        dots: false,
        prevArrow: '<span class="pro-icon-1-prev"><i class="far fa-angle-left"></i></span>',
        nextArrow: '<span class="pro-icon-1-next"><i class="far fa-angle-right"></i></span>'
  });
};

$.fn.CarouselTestmonial = function() {
  var $zaroSlickSlider = this;
  $zaroSlickSlider.slick({
        fade: false,
        loop: true,
        dots: false,
        prevArrow: '<span class="pro-icon-1-prev"><i class="far fa-angle-left"></i></span>',
        nextArrow: '<span class="pro-icon-1-next"><i class="far fa-angle-right"></i></span>'
  });
};

$.fn.bannercollection = function() {
  var $zaroSlickSlider = this;
  $zaroSlickSlider.slick({
        slidesToShow: 6,
        slidesToScroll: 1,
        fade: false,
        loop: true,
        dots: false,
        arrows: false,
        responsive: [
            {
                breakpoint: 1199,
                settings: {
                    slidesToShow: 4, 
                }
            },
            {
                breakpoint: 991,
                settings: {
                    slidesToShow: 3,
                }
            },
            {
                breakpoint: 767,
                settings: {
                    slidesToShow: 2,
                }
            },
            {
                breakpoint: 575,
                settings: {
                    slidesToShow: 1,
                }
            }
        ]
    });
};




















/*============== headerScript ==================*/
$.fn.headerScript = function(){
  
  /* Mega Menu */
  $('.mega_dropdown').parent('ul').addClass('mega-menu');
  $('.drop_item').parent('ul').addClass('single-column-menu');
  $('.multi_item').parent('ul').addClass('single-column-menu ');
  //Mega menu
  $('.mega_dropdown').parent('ul').addClass('mega-menu');
  $('.mega-menu').parent('li').addClass('mega_item');
  $('.drop_item').parent('ul').addClass('single-column-menu');
  $('.multi_item').parent('ul').addClass('single-column-menu ');
  $('.mega-menu').each(function(){
    if($(this).children('li').length){
      var ulChildren = $(this).children('li').length;
      if (ulChildren == 5) {
        $(this).addClass( "mega-menu-column-5" );
      }else if (ulChildren == 4) {
        $(this).addClass( "mega-menu-column-4" );
      }else if(ulChildren == 3){
        $(this).addClass( "mega-menu-column-3 mega-menu-column-4" );
      }else if(ulChildren == 2){
        $(this).addClass( "mega-menu-column-2  mega-menu-column-4" );
      }else if(ulChildren == 1){
        $(this).addClass( "mega-menu-column-4 mega-menu-column-1" );
      }else {
        $(this).addClass( "mega-menu-column-5 mega-full" );
      }
    }
  });

  /* Menu product activation */
  var $OwlMenuProduct = $('.menu_product_contain');
  if($OwlMenuProduct.length > 0){
    $OwlMenuProduct.owlCarousel({
      loop: true,
      nav: true,
      
      autoplay: false,
      margin: 0,
      autoplayTimeout: 8000,
      items: 1,
      dots:false,
      navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
    });  
  };
  
  /* SidebarSearch */
  function sidebarSearch() {
    var searchTrigger = $('.search-active'),
        endTriggersearch = $('.search-close'),
        container = $('.main-search-active');

    searchTrigger.on('click', function(e) {
      e.preventDefault();
      container.addClass('search-visible');
    });

    endTriggersearch.on('click', function() {
      container.removeClass('search-visible');
    });

  };
  sidebarSearch();

  /*---- Category toggle function ---*/
  var searchToggle = $('.categori-button-active');
  searchToggle.on('click', function(e){
    e.preventDefault();
    if($(this).hasClass('open')){
      $(this).removeClass('open');
      $(this).siblings('.categori-dropdown-active-large').removeClass('open');
    }else{
      $(this).addClass('open');
      $(this).siblings('.categori-dropdown-active-large').addClass('open');
    }
  })
  
  
    /*---- off can currancy toggle function ---*/
  var searchToggle = $('.ofcan-button-active');
  searchToggle.on('click', function(e){
    e.preventDefault();
    if($(this).hasClass('open')){
      $(this).removeClass('open');
      $(this).siblings('.offc-dropdown-active-large').removeClass('open');
    }else{
      $(this).addClass('open');
      $(this).siblings('.offc-dropdown-active-large').addClass('open');
    }
  })
  
  

  /* Show hide Category Option   */  
  $( ".categori-dropdown-active-large > ul > li:gt(6)" ).addClass( "side-hide" );
  if ($('.side-show').hasClass("side-hide")) {
    $('.side-show').removeClass('side-hide');
  } 
  $('.side-show').on('click', function(){
    $(this).toggleClass('show-hide');
  });
  $( '.side-show' ).on('click', function() {
    $( '.side-hide' ).slideToggle(300);
  });	

  /*-------- Mobile Menu Activation --*/
  jQuery('.mobile-menu nav').meanmenu({
    meanScreenWidth: "991",
  });

  /*=============================================
    =            mobile menu active            =
    =============================================*/
  $("#mobile-menu-trigger").on('click', function(){
    $("#mobile-menu-overlay,.menu_offcanvas_overlay").addClass("active");
  });

  $("#mobile-menu-close-trigger,.menu_offcanvas_overlay").on('click', function(){
    $("#mobile-menu-overlay,.menu_offcanvas_overlay").removeClass("active");
  });
  /*=====  End of mobile menu active  ======*/



  /*=============================================
    =            offcanvas mobile menu            =
    =============================================*/

  var $offCanvasNav = $('.offcanvas-navigation'),
      $offCanvasNavSubMenu = $offCanvasNav.find('.sub-menu');

  /*Add Toggle Button With Off Canvas Sub Menu*/
  $offCanvasNavSubMenu.parent().prepend('<span class="menu-expand"><i></i></span>');

  /*Close Off Canvas Sub Menu*/
  $offCanvasNavSubMenu.slideUp();

  /*Category Sub Menu Toggle*/
  $offCanvasNav.on('click', 'li a, li .menu-expand', function(e) {
    var $this = $(this);
    if ( ($this.parent().attr('class').match(/\b(menu-item-has-children|has-children|has-sub-menu)\b/)) && ($this.attr('href') === '#' || $this.hasClass('menu-expand')) ) {
      e.preventDefault();
      if ($this.siblings('ul:visible').length){
        $this.parent('li').removeClass('active');
        $this.siblings('ul').slideUp();
      } else {
        $this.parent('li').addClass('active');
        $this.closest('li').siblings('li').removeClass('active').find('li').removeClass('active');
        $this.closest('li').siblings('li').find('ul:visible').slideUp();
        $this.siblings('ul').slideDown();
      }
    }
  });

};



(function($) {
  "use strict";

  
  

  

  
  
  
  
  
  
  
  jQuery(document).ready(function(){

    
    
function dataBackgroundImage() {
    $('[data-bgimg]').each(function () {
      var bgImgUrl = $(this).data('bgimg');
      $(this).css({
        'background-image': 'url(' + bgImgUrl + ')', // + meaning concat
      });
    });
  }

  $(window).on('load', function () {
    dataBackgroundImage();
  });

    /*------ Wow Active ----*/
    new WOW().init();

    /*------ ScrollUp -------- */
    $.scrollUp({
      scrollText: '<i class="fal fa-long-arrow-up"></i>',
      easingType: 'linear',
      scrollSpeed: 900,
      animation: 'fade'
    });
    
    
    

      /*-----  Quantity Counter  ----*/
      $('.pro-qty').find('.dec, .inc').click(function( e ) {
        var $qty_field = $(this).parent().find('input'),
            $qtCount = parseInt($qty_field.val(), 10) + parseInt(e.currentTarget.className === 'inc' ? 1 : -1, 10);
        $qty_field.val($qtCount).change();
      });
      $('.pro-qty').find("input").change(function() {
        var $this = $(this),
            $min = 1,
            $value = parseInt($this.val(), 10),
            $max = parseInt($this.attr('totalqty'), 10);
        $value = Math.min($value, $max);
        $value = Math.max($value, $min);
        $this.val($value);
      }).on("keypress", function( e ) {
        if (e.keyCode === 13) {
          e.preventDefault();
        }
      });
    
      // Cart Page
      $('#cart_agree_to_check').on('click', function(){
        $(this).parent('.cart-calculation-button').toggleClass('disabled');
      });
    
    
      // Lazloady Js
      function lazyLoadjs(){
        $("img.lazyload").lazyload();
      };

    /*------------------------
        Clipboar Active
    -------------------------*/
    //     $('.cbtn').on('click', function() {
    //       var $this = $(this);
    //       var clipboard = new ClipboardJS('.cbtn');
    //       clipboard.on('success', function(e) {
    //         $this.text('Copied!');
    //         setTimeout(function() {
    //           $this.text('Copy');
    //         }, 2000);
    //       });
    //     });


    /*----------------------------------------
        SVG Inject With Vivus(After Inject) 
    ------------------------------------------*/
    //     SVGInject(document.querySelectorAll("img.svgInject"), {
    //         makeIdsUnique: true,
    //         afterInject: function (img, svg) {
    //             new Vivus(svg, {
    //                 duration: 80
    //             });
    //         }
    //     });

    /* Vivus On Hover */
    //     $('[data-vivus-hover]').hover(function () {
    //         var svg = $(this).find('svg')[0];
    //         new Vivus(svg, {
    //             duration: 50
    //         });
    //     })

    /*---- CounterUp ----*/
    //     $('.count').counterUp({
    //         delay: 10,
    //         time: 2000
    //     });






  });

})(jQuery);
