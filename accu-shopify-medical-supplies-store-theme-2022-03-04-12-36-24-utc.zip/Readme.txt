Within the main folder [themeforest-accu-shopify-theme.zip] there will be following folder and files.

Documentation
Readme.txt
Log.txt
accu.zip

-------------------------------------------------------------------
https://themessupport.com/wedesigntech/shopify/accu/


Kindly refer our documentation for installing the theme and doing customization. 
If you need any assistance, plz contact us through support@wedesignthemes.com


Thank You.
DesignThemes.










