Within the Main folder[themeforest-babs-shopify-theme.zip] there will be following folder and files.


Documentation
babs.zip
Readme.txt
Log.txt
 
You need to install the babs.zip file.

Online documentation URL:
http://themessupport.com/documentation/doc/buddhathemes/babs/

Kindly refer our documentation for installing the theme and doing customization. 
If you need any assistance, plz contact us through support@buddhathemes.com


Thankyou,
Buddhathemes.



