Within the main folder [Eli-Pack-v1] there will be following folder and files.


Documentation
Eli.zip
Readme.txt
log.txt


A that file that you need to install is : Eli.zip

------------------------------------------------------------------------------------------------------------------------------------


http://themessupport.com/documentation/doc/eli/


Kindly refer our documentation for installing the theme and doing customization. 
If you need any assistance, plz contact us through support@wedesignthemes.com


Thank You.
DesignThemes.










