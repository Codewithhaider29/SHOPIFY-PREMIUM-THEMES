= Credit =
AquaMag is based on Underscores http://underscores.me/, (C) 2012-2014 Automattic, Inc.

= Dummy Data =
If you need dummy data, please open the `readme` folder. Import the aquamag-dummy-data.xml to your site.

= Documentation =
Please open the `readme` folder, then open documentation.html on your browser.