<div class="form-search">
	<form class="navbar-form center-block" method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>"  role="search">
		<input type="text" name="s" id="s">
		<button type="submit" name="submit" id="searchsubmit"><i class="uk-icon-search"></i></button>
	</form>
</div>