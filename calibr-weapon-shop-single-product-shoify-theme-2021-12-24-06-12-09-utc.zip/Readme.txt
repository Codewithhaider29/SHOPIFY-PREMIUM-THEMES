Within the main folder [themeforest-calibr-shopify-theme.zip] there will be following folder and files.


Documentation
Readme.txt
Log.txt
calibr.zip   



-------------------------------------------------------------------
https://themessupport.com/dt-shop/calibr/

Kindly refer our documentation for installing the theme and doing customization. 
If you need any assistance, plz contact us through support@wedesignthemes.com


Thank You.
DesignThemes.










