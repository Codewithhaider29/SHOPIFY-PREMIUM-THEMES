	</main><!-- #main -->

	<footer id="footer" class="clearfix" <?php hybrid_attr( 'footer' ); ?>>

		<?php get_sidebar( 'footer' ); ?>

		<!-- Site Bottom / Start -->
		<div id="site-bottom" class="clearfix">
			<div class="container">
				<?php beginner_social_icons( 'footer' ); ?>
				<?php beginner_footer_text(); ?>
			</div>
		</div>
		<!-- Site Bottom / End -->

	</footer><!-- #colophon -->

</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
