Within the main folder [Citrus-Sectioned-V1] there will be following folder and files.


Citrus-Multi-Product.zip
Citrus-Single-Product.zip
Readme.txt


--------------------------------------------------------- 


Help links
~~~~~~~~~~


Mega Menu
https://youtu.be/6IBFSdZTd2Y


Pages:
https://youtu.be/Z4D4v5ScNQs


Currency:
https://youtu.be/V8uaCS0e8C4


Filters:
https://youtu.be/EpcGvd9ptCA


Countdown:
https://youtu.be/lVD8ADtmz-c



If you need any assistance, please contact us through the support mail support@wedesignthemes.com.


Thank You.
BuddhaThemes.










