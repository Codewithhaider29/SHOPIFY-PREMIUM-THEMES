<?php
/**
 * Portfolio Customizer
 */

/**
 * Register the customizer.
 */
function creatively_portfolio_customize_register( $wp_customize ) {

	// Register new section: Portfolio
	$wp_customize->add_section( 'creatively_portfolio' , array(
		'title'       => esc_html__( 'Portfolio', 'creatively' ),
		'panel'       => 'creatively_options',
		'priority'    => 5
	) );

	// Register Header Style setting
	$wp_customize->add_setting( 'creatively_portfolio_image_height', array(
		'default'           => 'dynamic',
		'sanitize_callback' => 'creatively_sanitize_portfolio_image_height'
	) );
	$wp_customize->add_control( 'creatively_portfolio_image_height', array(
		'label'             => esc_html__( 'Image height', 'creatively' ),
		'section'           => 'creatively_portfolio',
		'priority'          => 1,
		'type'              => 'radio',
		'choices'           => array(
			'dynamic' => esc_html__( 'Dynamic', 'creatively' ),
			'fixed'   => esc_html__( 'Fixed', 'creatively' )
		)
	) );

}
add_action( 'customize_register', 'creatively_portfolio_customize_register' );
