<?php
/**
 * Header & Menu Customizer
 */

/**
 * Register the customizer.
 */
function creatively_header_customize_register( $wp_customize ) {

	// Register new section: Header
	$wp_customize->add_section( 'creatively_header' , array(
		'title'       => esc_html__( 'Header', 'creatively' ),
		'panel'       => 'creatively_options',
		'priority'    => 3
	) );

	// Register Header Style setting
	$wp_customize->add_setting( 'creatively_header_style', array(
		'default'           => 'left',
		'sanitize_callback' => 'creatively_sanitize_header_style',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'creatively_header_style', array(
		'label'             => esc_html__( 'Style', 'creatively' ),
		'section'           => 'creatively_header',
		'priority'          => 1,
		'type'              => 'radio',
		'choices'           => array(
			'left'   => esc_html__( 'Logo on the left', 'creatively' ),
			'center' => esc_html__( 'Logo on the center', 'creatively' ),
			'right'  => esc_html__( 'Logo on the right', 'creatively' ),
		)
	) );

}
add_action( 'customize_register', 'creatively_header_customize_register' );
