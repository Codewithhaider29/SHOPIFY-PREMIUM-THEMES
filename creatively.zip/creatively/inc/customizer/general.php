<?php
/**
 * General Customizer
 */

/**
 * Register the customizer.
 */
function creatively_general_customize_register( $wp_customize ) {

	// Register new section: General
	$wp_customize->add_section( 'creatively_general' , array(
		'title'    => esc_html__( 'General', 'creatively' ),
		'panel'    => 'creatively_options',
		'priority' => 1
	) );

	// Register Custom RSS setting
	$wp_customize->add_setting( 'creatively_custom_rss', array(
		'default'           => '',
		'sanitize_callback' => 'esc_url_raw',
	) );
	$wp_customize->add_control( 'creatively_custom_rss', array(
		'label'             => esc_html__( 'Custom RSS', 'creatively' ),
		'description'       => esc_html__( 'If you use 3rd party RSS service, place the URL here to change the default WordPress RSS URL.', 'creatively' ),
		'section'           => 'creatively_general',
		'priority'          => 1,
		'type'              => 'url'
	) );

	// Register Thumbnail Aspect Ratio setting
	$wp_customize->add_setting( 'creatively_thumbnail_style', array(
		'default'           => 'landscape',
		'sanitize_callback' => 'creatively_sanitize_thumbnail_style',
	) );
	$wp_customize->add_control( 'creatively_thumbnail_style', array(
		'label'             => esc_html__( 'Thumbnail Aspect Ratio', 'creatively' ),
		'description'       => esc_html__( 'Applied to grid page template.', 'creatively' ),
		'section'           => 'creatively_general',
		'priority'          => 3,
		'type'              => 'radio',
		'choices'           => array(
			'landscape' => esc_html__( 'Landscape (4:3)', 'creatively' ),
			'square'    => esc_html__( 'Square (1:1)', 'creatively' ),
		)
	) );

	// Register Page comment manager setting
	$wp_customize->add_setting( 'creatively_page_comment', array(
		'default'           => 1,
		'sanitize_callback' => 'creatively_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'creatively_page_comment', array(
		'label'             => esc_html__( 'Pages: Enable comment on Pages', 'creatively' ),
		'section'           => 'creatively_general',
		'priority'          => 5,
		'type'              => 'checkbox'
	) );

	// Register Page title setting
	$wp_customize->add_setting( 'creatively_page_title', array(
		'default'           => 1,
		'sanitize_callback' => 'creatively_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'creatively_page_title', array(
		'label'             => esc_html__( 'Pages: Show page title', 'creatively' ),
		'section'           => 'creatively_general',
		'priority'          => 7,
		'type'              => 'checkbox'
	) );

	// Register Page featured image setting
	$wp_customize->add_setting( 'creatively_page_featured_image', array(
		'default'           => 0,
		'sanitize_callback' => 'creatively_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'creatively_page_featured_image', array(
		'label'             => esc_html__( 'Pages: Show page featured image', 'creatively' ),
		'section'           => 'creatively_general',
		'priority'          => 9,
		'type'              => 'checkbox'
	) );

	// Register Post comment manager setting
	$wp_customize->add_setting( 'creatively_post_comment', array(
		'default'           => 1,
		'sanitize_callback' => 'creatively_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'creatively_post_comment', array(
		'label'             => esc_html__( 'Posts: Enable comment on Posts', 'creatively' ),
		'section'           => 'creatively_general',
		'priority'          => 11,
		'type'              => 'checkbox'
	) );

	// Register Author Box setting
	$wp_customize->add_setting( 'creatively_author_box', array(
		'default'           => 1,
		'sanitize_callback' => 'creatively_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'creatively_author_box', array(
		'label'             => esc_html__( 'Posts: Show author box', 'creatively' ),
		'section'           => 'creatively_general',
		'priority'          => 13,
		'type'              => 'checkbox'
	) );

	// Register Next & Prev post setting
	$wp_customize->add_setting( 'creatively_next_prev_post', array(
		'default'           => 1,
		'sanitize_callback' => 'creatively_sanitize_checkbox'
	) );
	$wp_customize->add_control( 'creatively_next_prev_post', array(
		'label'             => esc_html__( 'Posts: Show next & prev post', 'creatively' ),
		'section'           => 'creatively_general',
		'priority'          => 15,
		'type'              => 'checkbox'
	) );

	// Register Footer Credits setting
	$wp_customize->add_setting( 'creatively_footer_credits', array(
		'sanitize_callback' => 'creatively_sanitize_textarea',
		'default'           => '243 Pedestrian Mountain Street &middot; Tel. 1-222-333-4444',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'creatively_footer_credits', array(
		'label'             => esc_html__( 'Footer Text', 'creatively' ),
		'section'           => 'creatively_general',
		'priority'          => 17,
		'type'              => 'textarea'
	) );

}
add_action( 'customize_register', 'creatively_general_customize_register' );

/**
 * Enable selective refresh
 */
function creatively_general_selective_refresh( WP_Customize_Manager $wp_customize ) {

	// Abort if selective refresh is not available.
	if ( ! isset( $wp_customize->selective_refresh ) ) {
		return;
	}

	// Footer Text
	$wp_customize->selective_refresh->add_partial( 'creatively_footer_credits', array(
		'selector'            => '.copyright',
		'render_callback'     => 'cobranding_customize_partial_footer_text'
	) );

}
add_action( 'customize_register', 'creatively_general_selective_refresh' );

/**
 * Render the Footer Text for the selective refresh partial.
 */
function cobranding_customize_partial_footer_text() {
	return creatively_sanitize_textarea( get_theme_mod( 'creatively_footer_credits' ) );
}
