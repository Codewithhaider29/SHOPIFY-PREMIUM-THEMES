<?php
/*
Widget Name: TJ: Clients
Description: A widget to display clients logo.
Author: Theme Junkie
Author URI: https://www.theme-junkie.com
*/

class TJ_Widget_Clients_Widget extends SiteOrigin_Widget {

	function __construct() {

		parent::__construct(
			'tj-clients',
			esc_html__( 'TJ: Clients', 'creatively' ),
			array(
				'description' => esc_html__( 'A widget to display clients logo.', 'creatively' ),
			),
			array(

			),
			false,
			plugin_dir_path(__FILE__)
		);

	}

	function get_widget_form() {

		return array(

			'title' => array(
				'type' => 'text',
				'label' => esc_html__( 'Title text', 'creatively' ),
			),

			'images' => array(
				'type' => 'repeater',
				'label' => esc_html__( 'Clients Logo', 'creatively' ),
				'item_name'  => esc_html__( 'Client', 'creatively' ),
				'item_label' => array(
					'selector'     => "[name*='title']",
					'update_event' => 'change',
					'value_method' => 'val'
				),
				'fields' => array(
					'image' => array(
						'type' => 'media',
						'label' => esc_html__( 'Logo', 'creatively' )
					),
					'title' => array(
						'type' => 'text',
						'label' => esc_html__( 'Name', 'creatively' )
					),
					'url' => array(
						'type' => 'link',
						'label' => esc_html__( 'URL', 'creatively' )
					),
				)
			),

		);
	}

	function get_template_name( $instance ) {
		return 'template';
	}

	public function get_template_variables( $instance, $args ) {
		return array(
			'title'  => $instance['title'],
			'images' => $instance['images'],
		);
	}

}

siteorigin_widget_register( 'tj-clients', __FILE__, 'TJ_Widget_Clients_Widget' );
