<div class="clients-container">
	
	<?php echo $args['before_title'] . wp_kses_post( $title ) . $args['after_title']; ?>

	<div class="clients">
		<?php
		foreach( $images as $image ) {
			echo '<div class="client">';
				if ( ! empty( $image['url'] ) ) echo '<a href="' . sow_esc_url( $image['url'] ) . '">';
				echo wp_get_attachment_image( $image['image'], 'full', false, array(
					'title' => $image['title']
				) );
				if ( ! empty( $image['url'] ) ) echo '</a>';
			echo '</div>';
		}
		?>
	</div>

</div>