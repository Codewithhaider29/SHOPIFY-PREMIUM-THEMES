<?php
/*
Widget Name: TJ: Featured Project
Description: A big hero image to showcase one of your best project.
Author: Theme Junkie
Author URI: https://www.theme-junkie.com
*/

class TJ_Widget_Featured_Project_Widget extends SiteOrigin_Widget {

	function __construct() {

		parent::__construct(
			'tj-featured-project',
			__( 'TJ: Featured Project', 'creatively' ),
			array(
				'description' => __( 'A big hero image to showcase one of your best project.', 'creatively' ),
			),
			array(

			),
			false,
			plugin_dir_path(__FILE__)
		);

	}

	function get_widget_form() {

		return array(

			'image' => array(
				'type' => 'media',
				'label' => esc_html__( 'Image file', 'creatively' ),
				'library' => 'image',
				'fallback' => true,
			),

			'alt' => array(
				'type' => 'text',
				'label' => esc_html__( 'Alt text', 'creatively' ) ,
			),

			'title' => array(
				'type' => 'text',
				'label' => esc_html__( 'Title text', 'creatively' ),
			),

			'categories' => array(
				'type' => 'text',
				'label' => esc_html__( 'Categories', 'creatively' ),
			),

			'url' => array(
				'type' => 'link',
				'label' => esc_html__( 'Destination URL', 'creatively' ),
			),
			'new_window' => array(
				'type' => 'checkbox',
				'default' => false,
				'label' => esc_html__( 'Open in new window', 'creatively' ),
			),

		);
	}

	function get_template_name( $instance ) {
		return 'template';
	}

	public function get_template_variables( $instance, $args ) {
		return array(
			'title'      => $instance['title'],
			'image'      => $instance['image'],
			'categories' => $instance['categories'],
			'alt'        => !empty( $instance['alt'] ) ? $instance['alt'] : get_post_meta( $instance['image'], '_wp_attachment_image_alt', true ),
			'url'        => $instance['url'],
			'new_window' => $instance['new_window'],
		);
	}

}

siteorigin_widget_register( 'tj-featured-project', __FILE__, 'TJ_Widget_Featured_Project_Widget' );
