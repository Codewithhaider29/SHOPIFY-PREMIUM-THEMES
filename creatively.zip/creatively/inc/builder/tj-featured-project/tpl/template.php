<?php $src = wp_get_attachment_image_src( $image, 'creatively-hero-image' ); ?>

<div class="featured-project-container">
	<?php if ( !empty( $url ) ) : ?><a class="project-link" href="<?php echo sow_esc_url( $url ) ?>" <?php if( $new_window ) echo 'target="_blank"' ?>><?php endif; ?>
		<img src="<?php echo esc_url( $src[0] ); ?>" width="<?php echo intval( $src[1] ); ?>" height="<?php echo intval( $src[2] ); ?>" <?php if( $alt ) echo 'alt="' . wp_kses_post( $alt ) . '"' ?>/>
		<span class="overlay"></span>
	<?php if ( !empty( $url ) ) : ?></a><?php endif; ?>

	<?php if ( !empty( $url ) ) : ?><a href="<?php echo sow_esc_url( $url ) ?>" <?php if( $new_window ) echo 'target="_blank"' ?>><?php endif; ?>
		<h2 class="project-title"><?php echo wp_kses_post( $title ); ?></h2>
	<?php if ( !empty( $url ) ) : ?></a><?php endif; ?>
	
	<span class="project-cat"><?php echo wp_kses_post( $categories ); ?></span>
</div>