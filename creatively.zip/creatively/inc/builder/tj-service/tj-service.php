<?php
/*
Widget Name: TJ: Service
Description: A widget to display your services.
Author: Theme Junkie
Author URI: https://www.theme-junkie.com
*/

class TJ_Widget_Service_Widget extends SiteOrigin_Widget {

	function __construct() {

		parent::__construct(
			'tj-service',
			esc_html__( 'TJ: Service', 'creatively' ),
			array(
				'description' => esc_html__( 'A widget to display your services.', 'creatively' ),
			),
			array(

			),
			false,
			plugin_dir_path(__FILE__)
		);

	}

	function get_widget_form() {

		return array(

			'title' => array(
				'type' => 'text',
				'label' => esc_html__( 'Title text', 'creatively' ),
			),

			'services' => array(
				'type' => 'repeater',
				'label' => esc_html__( 'Services', 'creatively' ),
				'item_name'  => esc_html__( 'Service', 'creatively' ),
				'item_label' => array(
					'selector'     => "[name*='title']",
					'update_event' => 'change',
					'value_method' => 'val'
				),
				'fields' => array(
					'title' => array(
						'type' => 'text',
						'label' => esc_html__( 'Name', 'creatively' )
					),
					'url' => array(
						'type' => 'link',
						'label' => esc_html__( 'URL', 'creatively' )
					),
					'details' => array(
						'type' => 'repeater',
						'label' => esc_html__( 'Service Details', 'creatively' ),
						'item_name'  => esc_html__( 'Service', 'creatively' ),
						'item_label' => array(
							'selector'     => "[name*='title']",
							'update_event' => 'change',
							'value_method' => 'val'
						),
						'fields' => array(
							'title' => array(
								'type' => 'text',
								'label' => esc_html__( 'Name', 'creatively' )
							),
						)
					),
				)
			),

		);
	}

	function get_template_name( $instance ) {
		return 'template';
	}

	public function get_template_variables( $instance, $args ) {
		return array(
			'title'    => $instance['title'],
			'services' => $instance['services']
		);
	}

}

siteorigin_widget_register( 'tj-service', __FILE__, 'TJ_Widget_Service_Widget' );
