<div class="services-container creatively-widget">
	
	<div class="services-content-left creatively-widget-title">
		<?php echo $args['before_title'] . wp_kses_post( $title ) . $args['after_title']; ?>
	</div>

	<div class="services-content-right">
		<div class="services-wrapper">
			<?php
			foreach( $services as $service ) {
				echo '<div class="service">';

					if ( ! empty( $service['url'] ) ) echo '<a class="main-service" href="' . sow_esc_url( $service['url'] ) . '">';
						echo '<span>' . $service['title'] . '</span>';
					if ( ! empty( $service['url'] ) ) echo '</a>';

					echo '<ul>';
						foreach( $service['details'] as $detail ) {
							echo '<li>' . $detail['title'] . '</li>';
						}
					echo '</ul>';
					
				echo '</div>';
			}
			?>
		</div>
	</div>

</div>