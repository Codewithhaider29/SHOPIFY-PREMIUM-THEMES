<?php
/**
 * Custom function for Siteorigin Page Builder
 */

/**
 * Custom SO builder widgets.
 */
function creatively_builder_widgets( $folders ) {

	// Check if required plugin is active
	include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
	if ( ! is_plugin_active( 'so-widgets-bundle/so-widgets-bundle.php' ) ) {
		return;
	}

	// Path to custom widgets.
	$folders[] = trailingslashit( get_template_directory() ) . 'inc/builder/';

	return $folders;
}
add_filter( 'siteorigin_widgets_widget_folders', 'creatively_builder_widgets' );

/**
 * Add new panel
 */
function creatively_panels_add_widgets_dialog_tabs( $tabs ){

	$tabs[] = array(
		'title'  => esc_html__( 'Creatively Widgets', 'creatively' ),
		'filter' => array(
			'installed' => true,
			'groups'    => array( 'creatively' )
		)
	);

	return $tabs;
}
add_filter( 'siteorigin_panels_widget_dialog_tabs', 'creatively_panels_add_widgets_dialog_tabs' );

/**
 * Set the groups for all Creatively Widgets
 */
function creatively_panels_add_widget_groups( $widgets ){
	$widgets['TJ_Widget_About_Widget']['groups'] = array( 'creatively' );
	$widgets['TJ_Widget_Clients_Widget']['groups'] = array( 'creatively' );
	$widgets['TJ_Widget_Featured_Project_Widget']['groups'] = array( 'creatively' );
	$widgets['TJ_Widget_Service_Widget']['groups'] = array( 'creatively' );
	$widgets['TJ_Widget_Team_Widget']['groups'] = array( 'creatively' );
	$widgets['TJ_Widget_Team_Details_Widget']['groups'] = array( 'creatively' );
	return $widgets;
}
add_filter( 'siteorigin_panels_widgets', 'creatively_panels_add_widget_groups' );
