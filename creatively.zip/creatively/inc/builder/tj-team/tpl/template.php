<div class="team-container creatively-widget">
	
	<div class="team-content-left creatively-widget-title">
		<?php echo $args['before_title'] . wp_kses_post( $title ) . $args['after_title']; ?>
	</div>

	<div class="team-content-center">
		<div class="team-desc"><?php echo wp_kses_post( $desc ); ?></div>
	</div>

	<div class="team-content-right">
		<div class="team-photo-wrapper">
			<?php
			foreach( $images as $image ) {
				echo '<div class="grid-image">';
					if ( ! empty( $image['url'] ) ) echo '<a href="' . sow_esc_url( $image['url'] ) . '">';
					echo wp_get_attachment_image( $image['image'], 'full', false, array(
						'title' => $image['title']
					) );
					if ( ! empty( $image['url'] ) ) echo '</a>';
				echo '</div>';
			}
			?>
		</div>
	</div>

</div>