<?php
/*
Widget Name: TJ: Team
Description: A widget to display your team photo.
Author: Theme Junkie
Author URI: https://www.theme-junkie.com
*/

class TJ_Widget_Team_Widget extends SiteOrigin_Widget {

	function __construct() {

		parent::__construct(
			'tj-team',
			esc_html__( 'TJ: Team', 'creatively' ),
			array(
				'description' => esc_html__( 'A widget to display your team photo.', 'creatively' ),
			),
			array(

			),
			false,
			plugin_dir_path(__FILE__)
		);

	}

	function get_widget_form() {

		return array(

			'title' => array(
				'type' => 'text',
				'label' => esc_html__( 'Title text', 'creatively' ),
			),

			'description' => array(
				'type' => 'textarea',
				'label' => esc_html__( 'Description text', 'creatively' ),
			),

			'images' => array(
				'type' => 'repeater',
				'label' => esc_html__( 'Team Photo', 'creatively' ),
				'item_name'  => esc_html__( 'Team', 'creatively' ),
				'item_label' => array(
					'selector'     => "[name*='title']",
					'update_event' => 'change',
					'value_method' => 'val'
				),
				'fields' => array(
					'image' => array(
						'type' => 'media',
						'label' => esc_html__( 'Image', 'creatively' )
					),
					'title' => array(
						'type' => 'text',
						'label' => esc_html__( 'Name', 'creatively' )
					),
					'url' => array(
						'type' => 'link',
						'label' => esc_html__( 'URL', 'creatively' )
					),
				)
			),

		);
	}

	function get_template_name( $instance ) {
		return 'template';
	}

	public function get_template_variables( $instance, $args ) {
		return array(
			'title'  => $instance['title'],
			'desc'   => $instance['description'],
			'images' => $instance['images'],
		);
	}

}

siteorigin_widget_register( 'tj-team', __FILE__, 'TJ_Widget_Team_Widget' );
