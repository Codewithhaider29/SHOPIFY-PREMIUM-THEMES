<?php
/*
Widget Name: TJ: Team Details
Description: A widget to display your team along with their bio and social media.
Author: Theme Junkie
Author URI: https://www.theme-junkie.com
*/

class TJ_Widget_Team_Details_Widget extends SiteOrigin_Widget {

	function __construct() {

		parent::__construct(
			'tj-team-details',
			esc_html__( 'TJ: Team Details', 'creatively' ),
			array(
				'description' => esc_html__( 'A widget to display your team along with their bio and social media.', 'creatively' ),
			),
			array(

			),
			false,
			plugin_dir_path(__FILE__)
		);

	}

	function get_widget_form() {

		return array(

			'title' => array(
				'type' => 'text',
				'label' => esc_html__( 'Title text', 'creatively' ),
			),

			'desc' => array(
				'type' => 'textarea',
				'label' => esc_html__( 'Description text', 'creatively' ),
			),

			'teams' => array(
				'type' => 'repeater',
				'label' => esc_html__( 'Team Details', 'creatively' ),
				'item_name'  => esc_html__( 'Team', 'creatively' ),
				'item_label' => array(
					'selector'     => "[name*='name']",
					'update_event' => 'change',
					'value_method' => 'val'
				),
				'fields' => array(
					'image' => array(
						'type' => 'media',
						'label' => esc_html__( 'Photo', 'creatively' )
					),
					'name' => array(
						'type' => 'text',
						'label' => esc_html__( 'Name', 'creatively' )
					),
					'bio' => array(
						'type' => 'textarea',
						'label' => esc_html__( 'Bio', 'creatively' )
					),
				)
			),

		);
	}

	function get_template_name( $instance ) {
		return 'template';
	}

	public function get_template_variables( $instance, $args ) {
		return array(
			'title'  => $instance['title'],
			'desc'   => $instance['desc'],
			'teams'  => $instance['teams'],
		);
	}

}

siteorigin_widget_register( 'tj-team-details', __FILE__, 'TJ_Widget_Team_Details_Widget' );
