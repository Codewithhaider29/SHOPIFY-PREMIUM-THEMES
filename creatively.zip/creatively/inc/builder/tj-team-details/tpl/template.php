<div class="team-details-container">

	<header class="team-details-header">
		<?php echo $args['before_title'] . wp_kses_post( $title ) . $args['after_title']; ?>
		<p class="team-details-desc"><?php echo wp_kses_post( $desc ); ?></p>
	</header>

	<div class="grid-area">
		<?php
		foreach( $teams as $team ) {
			echo '<div class="grid three-columns">';
				echo '<div class="team-details-photo">' . wp_get_attachment_image( intval( $team['image'] ), 'creatively-thumbnail-square', false, array( 'title' => $team['title'] ) ) . '</div>';
				echo '<div class="team-details-name">' . wp_kses_post( $team['name'] ) . '</div>';
				echo '<div class="team-details-bio"><p>' . wp_kses_post( $team['bio'] ) . '</p></div>';
			echo '</div>';
		}
		?>
	</div>

</div>
