<?php
/*
Widget Name: TJ: About
Description: A simple about widget.
Author: Theme Junkie
Author URI: https://www.theme-junkie.com
*/

class TJ_Widget_About_Widget extends SiteOrigin_Widget {

	function __construct() {

		parent::__construct(
			'tj-about',
			__( 'TJ: About', 'creatively' ),
			array(
				'description' => __( 'A simple about widget.', 'creatively' ),
			),
			array(

			),
			false,
			plugin_dir_path(__FILE__)
		);

	}

	function get_widget_form() {

		return array(

			'title' => array(
				'type' => 'text',
				'label' => esc_html__( 'Title text', 'creatively' ),
			),

			'description' => array(
				'type' => 'textarea',
				'label' => esc_html__( 'Description text', 'creatively' ),
			),

		);
	}

	function get_template_name( $instance ) {
		return 'template';
	}

	public function get_template_variables( $instance, $args ) {
		return array(
			'title' => $instance['title'],
			'desc'  => $instance['description'],
		);
	}

}

siteorigin_widget_register( 'tj-about', __FILE__, 'TJ_Widget_About_Widget' );
