<div class="about-container creatively-widget">
	
	<div class="about-content-left creatively-widget-title">
		<?php echo $args['before_title'] . wp_kses_post( $title ) . $args['after_title']; ?>
	</div>

	<div class="about-content-right">
		<div class="about-desc"><?php echo wp_kses_post( $desc ); ?></div>
	</div>

</div>