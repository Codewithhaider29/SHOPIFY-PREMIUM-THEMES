<?php
/**
 * Creatively Theme Customizer
 */

// Loads the customizer settings
require trailingslashit( get_template_directory() ) . 'inc/customizer/general.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/header.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/portfolio.php';

/**
 * Custom customizer functions.
 */
function creatively_customize_functions( $wp_customize ) {

	// Register new panel: Design
	$wp_customize->add_panel( 'creatively_design', array(
		'title'       => esc_html__( 'Design', 'creatively' ),
		'description' => esc_html__( 'This panel is used for customizing the design of your site.', 'creatively' ),
		'priority'    => 125,
	) );

	// Register new panel: Creatively Options
	$wp_customize->add_panel( 'creatively_options', array(
		'title'       => esc_html__( 'Theme Options', 'creatively' ),
		'description' => esc_html__( 'This panel is used for customizing the Creatively theme.', 'creatively' ),
		'priority'    => 130,
	) );

	// Live preview of Site Title
	$wp_customize->get_setting( 'blogname' )->transport = 'postMessage';

	// Enable selective refresh to the Site Title
	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'blogname', array(
			'selector'            => '.site-title a',
			'settings'         => array( 'blogname' ),
			'render_callback'  => function() {
				return get_bloginfo( 'name', 'display' );
			}
		) );
	}

	// Move the Colors section.
	$wp_customize->get_section( 'colors' )->panel    = 'creatively_design';
	$wp_customize->get_section( 'colors' )->priority = 1;

	// Move the Background Image section.
	$wp_customize->get_section( 'background_image' )->panel    = 'creatively_design';
	$wp_customize->get_section( 'background_image' )->priority = 7;

	// Move the Static Front Page section.
	$wp_customize->get_section( 'static_front_page' )->panel    = 'creatively_design';
	$wp_customize->get_section( 'static_front_page' )->priority = 9;

	// Move the Additional CSS section.
	$wp_customize->get_section( 'custom_css' )->panel    = 'creatively_design';
	$wp_customize->get_section( 'custom_css' )->priority = 11;

	// Move background color to background image section.
	$wp_customize->get_section( 'background_image' )->title = esc_html__( 'Background', 'creatively' );
	$wp_customize->get_control( 'background_color' )->section = 'background_image';

}
add_action( 'customize_register', 'creatively_customize_functions', 99 );

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function creatively_customize_preview_js() {
	wp_enqueue_script( 'creatively-customizer', get_template_directory_uri() . '/assets/js/customizer/customizer.js', array( 'customize-preview', 'jquery' ) );
}
add_action( 'customize_preview_init', 'creatively_customize_preview_js' );

/**
 * Custom RSS feed url.
 */
function creatively_custom_rss_url( $output, $feed ) {

	// Get the custom rss feed url
	$url = get_theme_mod( 'creatively_custom_rss' );

	// Do not redirect comments feed
	if ( strpos( $output, 'comments' ) ) {
		return $output;
	}

	// Check the settings.
	if ( ! empty( $url ) ) {
		$output = esc_url( $url );
	}

	return $output;
}
add_filter( 'feed_link', 'creatively_custom_rss_url', 10, 2 );

/**
 * Display theme documentation on customizer page.
 */
function creatively_documentation_link() {

	// Enqueue the script
	wp_enqueue_script( 'creatively-doc', get_template_directory_uri() . '/assets/js/customizer/doc.js', array(), '1.0.0', true );

	// Localize the script
	wp_localize_script( 'creatively-doc', 'prefixL10n',
		array(
			'prefixURL'   => esc_url( 'http://docs.theme-junkie.com/creatively/' ),
			'prefixLabel' => esc_html__( 'Documentation', 'creatively' ),
		)
	);

}
add_action( 'customize_controls_enqueue_scripts', 'creatively_documentation_link' );

/**
 * Sanitize the checkbox.
 *
 * @param boolean $input.
 * @return boolean (true|false).
 */
function creatively_sanitize_checkbox( $input ) {
	if ( 1 == $input ) {
		return true;
	} else {
		return false;
	}
}

/**
 * Sanitize the Footer Credits
 */
function creatively_sanitize_textarea( $text ) {
	if ( current_user_can( 'unfiltered_html' ) ) {
		$text = $text;
	} else {
		$text = wp_kses_post( $text );
	}
	return $text;
}

/**
 * Sanitize the Grid Thumbnail Aspect Ratio value.
 */
function creatively_sanitize_thumbnail_style( $ratio ) {
	if ( ! in_array( $ratio, array( 'landscape', 'square' ) ) ) {
		$ratio = 'landscape';
	}
	return $ratio;
}

/**
 * Sanitize the Header style value.
 */
function creatively_sanitize_header_style( $style ) {
	if ( ! in_array( $style, array( 'left', 'right', 'center' ) ) ) {
		$style = 'left';
	}
	return $style;
}

/**
 * Sanitize the Portfolio Image Height value.
 */
function creatively_sanitize_portfolio_image_height( $ratio ) {
	if ( ! in_array( $ratio, array( 'dynamic', 'fixed' ) ) ) {
		$ratio = 'dynamic';
	}
	return $ratio;
}
