<?php
/**
 * Enqueue scripts and styles.
 */

/**
 * Loads the theme styles & scripts.
 */
function creatively_enqueue() {

	// Load plugins stylesheet
	wp_enqueue_style( 'creatively-plugins-style', trailingslashit( get_template_directory_uri() ) . 'assets/css/plugins.min.css' );

	// Fonts
	wp_enqueue_style( 'creatively-fonts', creatively_fonts_url() );

	// if WP_DEBUG and/or SCRIPT_DEBUG turned on, load the unminified styles & script.
	if ( ! is_child_theme() && WP_DEBUG || SCRIPT_DEBUG ) {

		// Load main stylesheet
		wp_enqueue_style( 'creatively-style', get_stylesheet_uri() );

		// Load custom js plugins.
		wp_enqueue_script( 'creatively-plugins', trailingslashit( get_template_directory_uri() ) . 'assets/js/plugins.min.js', array( 'jquery', 'masonry' ), null, true );

		// Load custom js methods.
		wp_enqueue_script( 'creatively-main', trailingslashit( get_template_directory_uri() ) . 'assets/js/main.js', array( 'jquery', 'masonry' ), null, true );
		$script_handle = 'creatively-main';

	} else {

		// Load main stylesheet
		wp_enqueue_style( 'creatively-style', trailingslashit( get_template_directory_uri() ) . 'style.min.css' );

		// Load custom js plugins.
		wp_enqueue_script( 'creatively-scripts', trailingslashit( get_template_directory_uri() ) . 'assets/js/creatively.min.js', array( 'jquery', 'masonry' ), null, true );
		$script_handle = 'creatively-scripts';

	}

	// Pass var to js
	wp_localize_script( $script_handle, 'creatively',
		array(
			'endOfPages'   => esc_html__( 'No more pages to load.', 'creatively' ),
			'isNoGutter'   => ( is_page_template( 'page-templates/portfolio-no-gutter.php' ) ) ? true : false,
			'isTwoColumns' => ( is_page_template( 'page-templates/portfolio-2col.php' ) || is_page_template( 'page-templates/portfolio-2col-alt.php' ) ) ? true : false
		)
	);

	// If child theme is active, load the stylesheet.
	if ( is_child_theme() ) {
		wp_enqueue_style( 'creatively-child-style', get_stylesheet_uri() );
	}

	// Load comment-reply script.
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	// Loads HTML5 Shiv
	wp_enqueue_script( 'creatively-html5', trailingslashit( get_template_directory_uri() ) . 'assets/js/html5shiv.min.js', array( 'jquery' ), null, false );
	wp_script_add_data( 'creatively-html5', 'conditional', 'lte IE 9' );

	// Fontello for IE7
	wp_enqueue_style( 'creatively-fontello', trailingslashit( get_template_directory_uri() ) . 'assets/css/fontello-ie7.css' );
	wp_style_add_data( 'creatively-fontello', 'conditional', 'IE 7' );

}
add_action( 'wp_enqueue_scripts', 'creatively_enqueue' );

/**
 * js / no-js script.
 * @copyright http://www.paulirish.com/2009/avoiding-the-fouc-v3/
 */
function creatively_no_js_script() {
?>
<script>document.documentElement.className = document.documentElement.className.replace(/\bno-js\b/,'js');</script>
<?php
}
add_action( 'wp_head', 'creatively_no_js_script', 20 );
