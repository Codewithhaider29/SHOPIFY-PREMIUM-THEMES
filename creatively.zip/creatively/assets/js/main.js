( function( $ ) {

	/**
	 * Responsive videos
	 */
	var responsiveVideos = function() {
		$( '.entry, .widget' ).fitVids();
	};

	/**
	 * Isotope / Portfolio
	 */
	var filterablePortfolio = function() {

		// Set up variable
		var $wrapper,
			gutter = 28,
			columns = 3;

		// Conditional
		if ( creatively.isNoGutter ) {
			$wrapper = $( '.masonry-area-no-gutter' );
			gutter = '';
		} else if ( creatively.isTwoColumns ) {
			$wrapper = $( '.masonry-area' );
			columns = 2;
		} else {
			$wrapper = $( '.masonry-area' );
		}

		// Re-set columns based on window width
		var windowWidth = $( 'body' ).width();

		if ( windowWidth <= 500 ) {
			columns = 1;
		} else if ( windowWidth <= 800 ) {
			columns = 2;
		}

		var itemWidth = ( $wrapper.width() - gutter * ( columns - 1 ) ) / columns;

		$( '.masonry' ).css( {
			width: itemWidth,
			marginBottom: gutter
		} );

		// Initialize isotope
		$wrapper.imagesLoaded( function() {
			$wrapper.isotope( {
				itemSelector: '.masonry',
				masonry: {
					columnWidth: itemWidth,
					gutter: gutter,
					isFitWidth: true
				}
			} );
		} );

		// Hide pagination after isotope loaded completely
		$wrapper.on( 'arrangeComplete',
			function() {
				$( '.pagination' ).hide();
			}
		);

		// Filter links
		$( '.filter-links' ).on( 'click', 'a', function( event ) {
			event.preventDefault();

			var selector = $( this ).attr( 'data-filter' );
			$wrapper.isotope( {
				filter: selector
			} );

			$( this ).closest( 'ul' ).find( 'li' ).removeClass( 'active' );
			$( this ).closest( 'li' ).addClass( 'active' );

		} );

		// Infinite scroll
		$wrapper.infinitescroll( {
				navSelector: '.nav-links',
				nextSelector: '.nav-links a',
				itemSelector: '.masonry',
				loading: {
					msgText: '',
					finishedMsg: creatively.endOfPages
				}
			},

			// Trigger Masonry as a callback
			function( newElements ) {

				// hide new items while they are loading
				var $newElems = $( newElements ).css( {
					opacity: 0,
					width: itemWidth,
					marginBottom: gutter
				} );

				// ensure that images load before adding to masonry layout
				$newElems.imagesLoaded( function() {

					// show elems now they're ready
					$newElems.animate( {
						opacity: 1
					} );

					$wrapper.isotope( 'appended', $newElems, true );
				} );

			} );

	};

	/**
	 * Execute all functions
	 */
	$( function() {
		responsiveVideos();
		filterablePortfolio();
	} );

}( jQuery ) );
