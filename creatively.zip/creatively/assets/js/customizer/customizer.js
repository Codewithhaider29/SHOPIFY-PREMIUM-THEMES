/**
 * Theme Customizer enhancements for a better user experience.
 *
 * Contains handlers to make Theme Customizer preview reload changes asynchronously.
 */

( function( $ ) {

	// Set up variable
	api = wp.customize;

	// Site title and description.
	api( 'blogname', function( value ) {
		value.bind( function( to ) {
			$( '.site-title a' ).text( to );
		} );
	} );

	// Header style
	api( 'creatively_header_style', function( value ) {
		value.bind( function( to ) {
			if ( 'left' === to ) {
				$( 'body' ).removeClass( 'logo-center logo-right' ).addClass( 'logo-left' );
			} else if ( 'center' === to ) {
				$( 'body' ).removeClass( 'logo-left logo-right' ).addClass( 'logo-center' );
			} else {
				$( 'body' ).removeClass( 'logo-left logo-center' ).addClass( 'logo-right' );
			}
		} );
	} );

	// Header background color
	api( 'creatively_header_bg', function( value ) {
		value.bind( function( to ) {
			to = to ? to : '#fafafa';
			$( '.site-header' ).css( 'background-color', to );
		} );
	} );

	// Header color
	api( 'creatively_header_title_color', function( value ) {
		value.bind( function( to ) {
			to = to ? to : '#000000';
			$( '.site-title a' ).css( 'color', to );
		} );
	} );

	// Menu color
	api( 'creatively_header_menu_color', function( value ) {
		value.bind( function( to ) {
			to = to ? to : '#5a5b5c';
			$( '.menu-primary-items a' ).css( 'color', to );
		} );
	} );

	// Border color
	api( 'creatively_header_border_color', function( value ) {
		value.bind( function( to ) {
			to = to ? to : '#f1f1f1';
			$( '.logo-center .main-navigation' ).css( 'border-color', to );
		} );
	} );

} )( jQuery );
