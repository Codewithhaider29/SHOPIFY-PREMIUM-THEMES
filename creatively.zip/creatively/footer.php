	</div><!-- #content -->

	<footer id="colophon" class="site-footer">

		<div class="site-info">
			<div class="container">
				<?php if ( has_nav_menu ( 'social' ) ) : ?>
					<?php wp_nav_menu(
						array(
							'theme_location'  => 'social',
							'depth'           => 1,
							'link_before'     => '<span class="screen-reader-text">',
							'link_after'      => '</span>',
							'container_class' => 'social-links',
						)
					); ?>
				<?php endif; ?>
				<div class="copyright">
					<?php creatively_footer_text(); ?>
					<p>&copy; Copyright <?php date( 'Y' ); ?> <a href="<?php echo esc_url( home_url() ); ?>"><?php echo esc_attr( get_bloginfo( 'name' ) ); ?></a> &middot; Designed by <a href="https://www.theme-junkie.com/">Theme Junkie</a></p>
				</div><!-- .site-info -->
			</div>
		</div><!-- .site-info -->

	</footer><!-- #colophon -->

</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
