<?php
/**
 * Template Name: Full Width Template
 * Template Post Type: post, page
 */

get_header(); ?>

	<div class="container">

		<div id="primary" class="content-area">
			<main id="main" class="site-main">

				<?php while ( have_posts() ) : the_post(); ?>

					<?php if ( is_singular( 'post' ) ) : ?>
						<?php get_template_part( 'partials/content', 'single' ); ?>
						<?php creatively_post_author_box(); // Display the author box. ?>
						<?php creatively_next_prev_post(); // Display the next and previous post. ?>
					<?php else : ?>
						<?php get_template_part( 'partials/content', 'page' ); ?>
					<?php endif; ?>

					<?php
						// Get data set in customizer
						if ( is_singular( 'post' ) ) :
							$comment = get_theme_mod( 'creatively_post_comment', 1 );
						else :
							$comment = get_theme_mod( 'creatively_page_comment', 1 );
						endif;

						// Check if comment enable on customizer
						if ( $comment ) :
							// If enable and comments are open or we have at least one comment, load up the comment template
							if ( comments_open() || '0' != get_comments_number() ) :
								comments_template();
							endif;
						endif;
					?>

				<?php endwhile; // end of the loop. ?>

			</main><!-- #main -->
		</div><!-- #primary -->

	</div><!-- .container -->

<?php get_footer(); ?>

