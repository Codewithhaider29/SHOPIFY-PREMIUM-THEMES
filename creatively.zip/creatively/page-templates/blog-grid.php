<?php
/**
 * Template Name: Blog Grid Template
 */

get_header(); ?>

	<header class="archive-header">
		<?php while ( have_posts() ) : the_post(); ?>
			<?php printf( esc_html__( '%1$sBrowse:%2$s %3$s ', 'creatively' ), '<span>', '</span>', get_the_title() ); ?>
		<?php endwhile; ?>
	</header><!-- .page-header -->

	<div class="container">

		<div id="primary" class="content-area">
			<main id="main" class="site-main">

				<?php
					// Get post per page setting
					$limit = get_option( 'posts_per_page' );

					// For pagination
					if ( get_query_var( 'paged' ) ) {
						$paged = get_query_var( 'paged' );
					} elseif ( get_query_var( 'page' ) ) {
						$paged = get_query_var( 'page' );
					} else {
						$paged = 1;
					}

					// Arguments
					$args = array(
						'post_type'      => 'post',
						'posts_per_page' => $limit,
						'paged'          => $paged
					);

					// Perform the query.
					$wp_query = new WP_Query( $args );
				?>

				<?php if ( $wp_query->have_posts() ) : ?>

					<div class="grid-area">

						<?php while ( $wp_query->have_posts() ) : $wp_query->the_post(); ?>

							<div class="grid three-columns">

								<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

									<?php if ( has_post_thumbnail() ) : ?>
										<a class="thumbnail-link" href="<?php the_permalink(); ?>">
											<?php
												$ratio = get_theme_mod( 'creatively_thumbnail_style' );
												switch ( $ratio ) {
													case 'square':
														the_post_thumbnail( 'creatively-thumbnail-square' );
														break;
													default :
														the_post_thumbnail( 'creatively-thumbnail-landscape' );
												}
											?>
										</a>
									<?php endif; ?>

									<?php if ( 'post' == get_post_type() ) : ?>
										<?php
											/* translators: used between list items, there is a space after the comma */
											$categories_list = get_the_category_list( esc_html__( ', ', 'creatively' ) );
											if ( $categories_list && creatively_categorized_blog() ) :
										?>
										<span class="cat-links">
											<?php echo $categories_list; ?>
										</span>
										<?php endif; // End if categories ?>
									<?php endif; ?>

									<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>

									<div class="entry-summary">
										<p><?php echo wp_trim_words( get_the_excerpt(), 20 ); ?></p>
									</div>

									<span class="more-link-wrapper">
										<a href="<?php the_permalink(); ?>" class="more-link"><?php esc_html_e( 'Continue Reading', 'creatively' ); ?></a>
									</span>

								</article><!-- #post-## -->

							</div>

						<?php endwhile; ?>

					</div>

					<?php the_posts_pagination(); ?>

				<?php else : ?>

					<?php get_template_part( 'partials/content', 'none' ); ?>

				<?php endif; wp_reset_postdata(); ?>

			</main><!-- #main -->
		</div><!-- #primary -->

	</div><!-- .container -->

<?php get_footer(); ?>
