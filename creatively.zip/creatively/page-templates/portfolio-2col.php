<?php
/**
 * Template Name: Portfolio 2 Columns Template
 */

get_header(); ?>

	<header class="archive-header">
		<div class="container">
			<?php printf( esc_html__( '%1$sBrowse:%2$s %3$s ', 'creatively' ), '<span>', '</span>', get_the_title() ); ?>
		</div>
	</header><!-- .page-header -->

	<div class="container">

		<div id="primary" class="content-area">
			<main id="main" class="site-main">

				<?php if ( have_posts() ) : ?>

					<div class="portfolio-area">

						<div class="portfolio-filter">
							<?php $count = 0; // counter ?>

							<?php
							if ( taxonomy_exists( 'jetpack-portfolio-type' ) ) :
								$terms = get_terms( 'jetpack-portfolio-type' );
								if ( $terms && count( $terms ) > 1 ) : ?>
									<span class="filter"><?php esc_html_e( 'Filter:', 'creatively' ); ?></span>
									<ul class="filter-links">
										<li class="active">
											<a href="#" data-filter="*">
												<span><?php esc_html_e( 'All', 'creatively' ) ?></span>
											</a>
										<?php foreach ( $terms as $term ) : ?>
											<li>
												<a href="#" data-filter=".<?php echo esc_attr( $term->taxonomy . '-' . $term->slug ) ?>">
													<?php echo esc_attr( $term->name ); ?>
												</a>
											</li>
										<?php endforeach; ?>
									</ul>
								<?php endif; ?>
							<?php endif; ?>
						</div>

						<div class="masonry-area">

							<?php
								// Get post per page setting
								$limit = get_option( 'jetpack_portfolio_posts_per_page' );

								// For pagination
								if ( get_query_var( 'paged' ) ) {
									$paged = get_query_var( 'paged' );
								} elseif ( get_query_var( 'page' ) ) {
									$paged = get_query_var( 'page' );
								} else {
									$paged = 1;
								}

								// Arguments
								$args = array(
									'post_type'      => 'jetpack-portfolio',
									'posts_per_page' => $limit,
									'paged'          => $paged
								);

								// Perform the query.
								$wp_query = new WP_Query( $args );
							?>

							<?php if ( $wp_query->have_posts() ) : ?>

								<?php while ( $wp_query->have_posts() ) : $wp_query->the_post(); ?>

									<div <?php post_class( "masonry two-columns" ); ?>>

										<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

											<?php creatively_masonry_image_height(); ?>

											<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>

											<span class="overlay"></span>

										</article><!-- #post-## -->

									</div>

								<?php endwhile; ?>

							<?php endif; wp_reset_postdata(); ?>

						</div>

						<?php the_posts_pagination(); ?>

					</div>

				<?php else : ?>

					<?php get_template_part( 'partials/content', 'none' ); ?>

				<?php endif; ?>

			</main><!-- #main -->
		</div><!-- #primary -->

	</div><!-- .container -->

<?php get_footer(); ?>
