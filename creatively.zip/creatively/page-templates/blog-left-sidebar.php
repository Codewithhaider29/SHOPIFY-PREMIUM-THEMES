<?php
/**
 * Template Name: Blog Left Sidebar Template
 */

get_header(); ?>

	<header class="archive-header">
		<?php while ( have_posts() ) : the_post(); ?>
			<?php printf( esc_html__( '%1$sBrowse:%2$s %3$s ', 'creatively' ), '<span>', '</span>', get_the_title() ); ?>
		<?php endwhile; ?>
	</header><!-- .page-header -->

	<div class="container">

		<div id="primary" class="content-area">
			<main id="main" class="site-main">

				<?php
					// Get post per page setting
					$limit = get_option( 'posts_per_page' );

					// For pagination
					if ( get_query_var( 'paged' ) ) {
						$paged = get_query_var( 'paged' );
					} elseif ( get_query_var( 'page' ) ) {
						$paged = get_query_var( 'page' );
					} else {
						$paged = 1;
					}

					// Arguments
					$args = array(
						'post_type'      => 'post',
						'posts_per_page' => $limit,
						'paged'          => $paged
					);

					// Perform the query.
					$wp_query = new WP_Query( $args );
				?>

				<?php if ( $wp_query->have_posts() ) : ?>

					<?php while ( $wp_query->have_posts() ) : $wp_query->the_post(); ?>

						<?php get_template_part( 'partials/content' ); ?>

					<?php endwhile; ?>

					<?php the_posts_pagination(); ?>

				<?php else : ?>

					<?php get_template_part( 'partials/content', 'none' ); ?>

				<?php endif; wp_reset_postdata(); ?>

			</main><!-- #main -->
		</div><!-- #primary -->

		<?php get_sidebar(); // Loads the sidebar.php template. ?>

	</div><!-- .container -->

<?php get_footer(); ?>
