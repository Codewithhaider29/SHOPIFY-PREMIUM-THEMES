<?php
/**
 * Template Name: Grid Page Template
 */

get_header(); ?>

	<header class="archive-header">
		<?php while ( have_posts() ) : the_post(); ?>
			<?php printf( esc_html__( '%1$sBrowse:%2$s %3$s ', 'creatively' ), '<span>', '</span>', get_the_title() ); ?>
		<?php endwhile; ?>
	</header><!-- .page-header -->

	<div class="container">

		<?php
			$child_pages = new WP_Query( array(
				'post_type'      => 'page',
				'orderby'        => 'menu_order',
				'order'          => 'ASC',
				'post_parent'    => $post->ID,
				'posts_per_page' => 999,
				'no_found_rows'  => true,
			) );
		?>

		<?php if ( $child_pages->have_posts() ) : ?>

			<div class="grid-area">

				<?php while ( $child_pages->have_posts() ) : $child_pages->the_post(); ?>

					<div class="grid three-columns">
						<?php get_template_part( 'partials/content', 'grid' ); ?>
					</div><!-- .grid -->

				<?php endwhile; ?>

			</div><!-- .grid-area -->

		<?php
			endif;
			wp_reset_postdata();
		?>

	</div><!-- .container -->

<?php get_footer(); ?>
