Within the main folder [themeforest-aronic-shopify-theme.zip] there will be following folder and files.

Primary Demo Documentation
Other Demos Documentation
Readme.txt
Log.txt
Modern Tools.zip
Auto.zip
Hand Tools.zip
Drill Kit.zip
Renovation.zip
Tool Collections.zip
Measurement.zip
Tool Sale.zip
Cutting.zip
Hardware.zip
Mechanic.zip

-------------------------------------------------------------------
https://themessupport.com/wedesigntech/shopify/aronic/


Kindly refer our documentation for installing the theme and doing customization. 
If you need any assistance, plz contact us through support@wedesignthemes.com


Thank You.











