Please unpack the whole package after downloading it from Themeforest.
On that extracted themeforest-ebait-shopify-theme, You can find files like
Documentation,
ebait.zip ,
Log.txt and Readme.txt.

You need to install the file "ebait.zip".


Online documentation link :  
 
https://themessupport.com/dt-shop/ebait/