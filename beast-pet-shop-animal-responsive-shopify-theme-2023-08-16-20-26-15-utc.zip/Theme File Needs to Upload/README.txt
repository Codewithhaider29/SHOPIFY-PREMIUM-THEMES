
New User:

Please, install the 'Online Store 2.0' version. 'Online Store 2.0' is supported by Shopify's latest technology and feature.


Previous User:

'Online Store 2.0' It's a new feature of Shopify. We added this feature to our store. If you want to use this version, you need to re-customize your store. It's not possible to update with the previous version.