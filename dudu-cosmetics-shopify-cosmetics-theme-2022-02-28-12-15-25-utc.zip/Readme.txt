Within the main folder [themeforest-dudu-shopify-theme.zip] there will be following folder and files.

Documentation
Readme.txt
Log.txt
dudu-01.zip, dudu-02.zip, dudu-03.zip

-------------------------------------------------------------------
https://themessupport.com/wedesigntech/shopify/dudu-shop/

Kindly refer our documentation for installing the theme and doing customization. 
If you need any assistance, plz contact us through support@wedesignthemes.com


Thank You.
DesignThemes.










