Within the main folder [dEShop-Pack-V1] there will be following folder and files.


Documentation
Readme.txt
Log.txt
dEShop.zip             



----------------------------------------------------------------------
Online Documentation URL -   http://wedesignthemes.com/shopify/dEShop/
----------------------------------------------------------------------



Kindly refer our documentation for installing the theme and doing customization. 
If you need any assistance, plz contact us through support@wedesignthemes.com





Thankyou,
DesignThemes.










