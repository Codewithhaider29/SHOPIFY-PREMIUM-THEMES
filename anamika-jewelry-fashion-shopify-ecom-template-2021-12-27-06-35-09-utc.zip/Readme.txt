Please unpack the whole package after downloading it from Themeforest.
On that extracted themeforest-anamika-shopify-theme, You can find files like
Documentation,
anamika.zip ,
Log.txt and Readme.txt.

You need to install the file "anamika.zip".


Online documentation link :  
http://themessupport.com/dt-shop/anamika/