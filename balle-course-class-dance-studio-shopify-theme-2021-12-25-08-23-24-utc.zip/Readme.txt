Within the Main folder[themeforest-balle-shopify-theme.zip] there will be following folder and files.


Documentation
balle.zip
Readme.txt
Log.txt
 
You need to install the balle.zip file. 

Online documentation URL:
http://themessupport.com/documentation/doc/balle/

Kindly refer our documentation for installing the theme and doing customization. 
If you need any assistance, plz contact us through support@wedesignthemes.com


Thankyou,
Designthemes.



