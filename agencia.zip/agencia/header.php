<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">

<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<div id="page" class="site">

	<div class="wide-container">

		<header id="masthead" class="site-header">
			<div class="container">
				<div class="site-header-inner">

					<a href="#menu-overlay" class="menu-toggle">
						<i class="fa fa-bars"></i>
					</a>

					<?php agencia_site_branding(); ?>

					<?php if ( has_nav_menu ( 'social' ) ) : ?>
						<?php wp_nav_menu(
							array(
								'theme_location'  => 'social',
								'link_before'     => '<span class="screen-reader-text">',
								'link_after'      => '</span>',
								'depth'           => 1,
								'container'       => '',
								'menu_id'         => 'social-menu',
								'menu_class'      => 'social-menu'
							)
						); ?>
					<?php endif; ?>

					<?php
						$search = get_theme_mod( 'agencia_header_search', 1 );
						if ( $search ) :
					?>
						<a href="#search-overlay" class="search-toggle">
							<i class="fa fa-search"></i>
						</a>
					<?php endif; ?>

				</div>
			</div>
		</header><!-- #masthead -->

		<div id="content" class="site-content">
