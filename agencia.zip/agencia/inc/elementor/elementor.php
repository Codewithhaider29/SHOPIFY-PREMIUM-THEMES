<?php
/**
 * Elementor compatibility and custom functions
 *
 * @package    Agencia
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2018, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */

namespace Elementor;

/**
 * Elementor setup function.
 *
 * @return void
 */
function agencia_update_elementor_global_option () {
	update_option( 'elementor_disable_color_schemes', 'yes' );
	update_option( 'elementor_disable_typography_schemes', 'yes' );
	update_option( 'elementor_container_width', '1130' );
}
add_action( 'after_switch_theme', 'Elementor\agencia_update_elementor_global_option' );

/**
 * Add widgets
 */
function agencia_elementor_custom_widgets() {
	require_once get_template_directory() . '/inc/elementor/widgets/portfolio.php';
}
add_action( 'elementor/widgets/widgets_registered', 'Elementor\agencia_elementor_custom_widgets' );

