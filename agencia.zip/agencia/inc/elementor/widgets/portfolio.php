<?php
/**
 * Portfolio widgets
 */

namespace Elementor;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Agencia_Widget_Portfolio_Grid extends Widget_Base {

	public function get_name() {
		return 'agencia-portfolio';
	}

	public function get_title() {
		return esc_html__( 'Portfolio', 'agencia' );
	}

	public function get_icon() {
		return 'eicon-posts-grid';
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'section_portfolio_grid',
			[
				'label' => esc_html__( 'Portfolio', 'agencia' ),
			]
		);

		$this->add_control(
			'count',
			[
				'label' 		=> esc_html__( 'Posts Per Page', 'agencia' ),
				'description' 	=> esc_html__( 'You can enter "-1" to display all portfolio.', 'agencia' ),
				'type' 			=> Controls_Manager::TEXT,
				'default' 		=> '8',
				'label_block' 	=> true,
			]
		);

		$this->add_control(
			'order',
			[
				'label' 		=> __( 'Order', 'agencia' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> '',
				'options' 		=> [
					'' 			=> __( 'Default', 'agencia' ),
					'DESC' 		=> __( 'DESC', 'agencia' ),
					'ASC' 		=> __( 'ASC', 'agencia' ),
				],
			]
		);

		$this->add_control(
			'orderby',
			[
				'label' 		=> __( 'Order By', 'agencia' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> '',
				'options' 		=> [
					'' 				=> __( 'Default', 'agencia' ),
					'date' 			=> __( 'Date', 'agencia' ),
					'title' 		=> __( 'Title', 'agencia' ),
					'name' 			=> __( 'Name', 'agencia' ),
					'modified' 		=> __( 'Modified', 'agencia' ),
					'author' 		=> __( 'Author', 'agencia' ),
					'rand' 			=> __( 'Random', 'agencia' ),
					'ID' 			=> __( 'ID', 'agencia' ),
					'comment_count' => __( 'Comment Count', 'agencia' ),
					'menu_order' 	=> __( 'Menu Order', 'agencia' ),
				],
			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings();

		// Vars
		$posts_per_page = $settings['count'];
		$order 			= $settings['order'];
		$orderby  		= $settings['orderby'];

		$args = array(
			'post_type'         => 'portfolio',
			'posts_per_page'    => $posts_per_page,
			'order'             => $order,
			'orderby'           => $orderby
		);

		// Build the WordPress query
		$portfolio = new \WP_Query( $args );

		// Output posts
		if ( $portfolio->have_posts() ) : ?>

			<div class="content-portfolio">

				<?php

				// Start loop
				while ( $portfolio->have_posts() ) : $portfolio->the_post();

					// Create new post object.
					$post = new \stdClass();

					// Get post data
					$get_post = get_post();

					// Post Data
					$post->ID           = $get_post->ID;
					$post->permalink    = get_the_permalink( $post->ID );
					$post->title        = $get_post->post_title;
					?>

					<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

						<div class="thumbnail">
							<a class="post-thumbnail" href="<?php the_permalink(); ?>">
								<?php
									the_post_thumbnail( 'agencia-portfolio', array(
										'alt' => the_title_attribute( array(
											'echo' => false,
										) ),
									) );
								?>
								<i class="fa fa-external-link" aria-hidden="true"></i>
							</a>
						</div>

					</article>

				<?php
				// End entry loop
				endwhile; ?>

			</div><!-- .agencia-portfolio -->

			<?php
			// Reset the post data to prevent conflicts with WP globals
			wp_reset_postdata();

		// If no posts are found display message
		else : ?>

			<p><?php _e( 'It seems we can&rsquo;t find what you&rsquo;re looking for.', 'agencia' ); ?></p>

		<?php
		// End post check
		endif; ?>

	<?php
	}

}

Plugin::instance()->widgets_manager->register_widget_type( new Agencia_Widget_Portfolio_Grid() );
