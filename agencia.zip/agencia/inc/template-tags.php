<?php
/**
 * Custom template tags for this theme.
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package    Agencia
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2018, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */

if ( ! function_exists( 'agencia_site_branding' ) ) :
	/**
	 * Site branding for the site.
	 *
	 * Display site title by default, but user can change it with their custom logo.
	 * They can upload it on Customizer page.
	 */
	function agencia_site_branding() {

		// Get the logo.
		$logo_id  = get_theme_mod( 'custom_logo' );
		$logo_url = wp_get_attachment_image_src( $logo_id , 'full' );

		// Retina logo.
		$retina_id  = get_theme_mod( 'agencia_retina_logo' );
		$retina_url = wp_get_attachment_image_src( $retina_id , 'full' );
		$retina = '';

		if ( $retina_id ) {
			$retina = 'data-rjs=' . esc_url( $retina_url[0] ) . '';
		}

		// Check if logo available, then display it.
		if ( $logo_id ) :
			echo '<div class="site-branding">'. "\n";
				echo '<div class="logo">';
					echo '<a href="' . esc_url( get_home_url() ) . '" rel="home">' . "\n";
						echo '<img src="' . esc_url( $logo_url[0] ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '" ' . $retina . ' />' . "\n";
					echo '</a>' . "\n";
				echo '</div>' . "\n";
			echo '</div>' . "\n";

		// If not, then display the Site Title and Site Description.
		else :
			echo '<div class="site-branding">'. "\n";
				echo '<h1 class="site-title"><a href="' . esc_url( get_home_url() ) . '" rel="home">' . esc_attr( get_bloginfo( 'name' ) ) . '</a></h1>'. "\n";
			echo '</div>'. "\n";
		endif;

	}
endif;

if ( ! function_exists( 'agencia_post_header' ) ) :
	/**
	 * Post categories and post title.
	 */
	function agencia_post_header() {
		?>
		<?php if ( 'post' == get_post_type() ) : ?>
			<?php
				/* translators: used between list items, there is a space after the comma */
				$categories_list = get_the_category_list( esc_html__( ', ', 'agencia' ) );
				if ( $categories_list ) :
			?>
				<span class="cat-links">
					<?php echo $categories_list; ?>
				</span>
			<?php endif; // End if categories ?>
		<?php endif; ?>

		<?php the_title(
			sprintf(
				'<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>'
			);
		?>

		<?php
	}
endif;

if ( ! function_exists( 'agencia_post_thumbnail' ) ) :
	/**
	 * Displays an optional post thumbnail.
	 *
	 * Wraps the post thumbnail in an anchor element on index views, or a div
	 * element when on single views.
	 */
	function agencia_post_thumbnail( $size = 'thumbnail' ) {
		if ( post_password_required() || is_attachment() || ! has_post_thumbnail() ) {
			return;
		}

		if ( is_single() ) :
		?>

		<div class="post-thumbnail">
			<?php the_post_thumbnail( $size ); ?>
		</div><!-- .post-thumbnail -->

		<?php else : ?>

		<a class="post-thumbnail" href="<?php the_permalink(); ?>">
			<?php
				the_post_thumbnail( $size, array(
					'alt' => the_title_attribute( array(
						'echo' => false,
					) ),
				) );
			?>
		</a>

		<?php endif; // End is_singular().
	}
endif;

if ( ! function_exists( 'agencia_post_meta' ) ) :
	/**
	 * Prints HTML with meta information for the current post-date/time and author.
	 */
	function agencia_post_meta() {

		// Hide on job page.
		if ( 'post' != get_post_type() ) {
			return;
		}

		$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time>';

		$time_string = sprintf( $time_string,
			esc_attr( get_the_date( 'c' ) ),
			human_time_diff( get_the_time( 'U' ), current_time( 'timestamp' ) )
		);

		$posted_on = sprintf(
			/* translators: %s: ago. */
			esc_html_x( '%s ago', 'post date', 'agencia' ),
			'<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>'
		);

		$byline = sprintf(
			'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
		);

		echo '<span class="posted-on">' . $posted_on . '</span><span class="byline"> ' . $byline . '</span>'; // WPCS: XSS OK.

	}
endif;

if ( ! function_exists( 'agencia_social_share' ) ) :
	/**
	 * Display social share buttons.
	 */
	function agencia_social_share() {

		// Show on post.
		if ( 'post' != get_post_type() ) {
			return;
		}

		// Get the data set in customizer
		$share = get_theme_mod( 'agencia_post_share', 1 );

		// Check if user choose to show or hide it.
		if ( !$share ) {
			return;
		}
		?>
			<div class="post-share">
				<ul>
					<li class="twitter"><a href="https://twitter.com/intent/tweet?text=<?php echo urlencode( esc_attr( get_the_title( get_the_ID() ) ) ); ?>&amp;url=<?php echo urlencode( get_permalink( get_the_ID() ) ); ?>" target="_blank"><i class="fa fa-twitter"></i><span class="screen-reader-text">Twitter</span></a></li>
					<li class="facebook"><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode( get_permalink( get_the_ID() ) ); ?>" target="_blank"><i class="fa fa-facebook"></i><span class="screen-reader-text">Facebook</span></a></li>
					<li class="google-plus"><a href="https://plus.google.com/share?url=<?php echo urlencode( get_permalink( get_the_ID() ) ); ?>" target="_blank"><i class="fa fa-google-plus"></i><span class="screen-reader-text">Google+</span></a></li>
					<li class="linkedin"><a href="https://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo urlencode( get_permalink( get_the_ID() ) ); ?>&amp;title=<?php echo urlencode( esc_attr( get_the_title( get_the_ID() ) ) ); ?>" target="_blank"><i class="fa fa-linkedin"></i><span class="screen-reader-text">LinkedIn</span></a></li>
					<li class="pinterest"><a href="https://pinterest.com/pin/create/button/?url=<?php echo urlencode( get_permalink( get_the_ID() ) ); ?>&amp;media=<?php echo urlencode( wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) ) ); ?>" target="_blank"><i class="fa fa-pinterest"></i><span class="screen-reader-text">Pinterest</span></a></li>
					<li class="email"><a href="mailto:?subject=<?php echo esc_url( urlencode( '[' . get_bloginfo( 'name' ) . '] ' . get_the_title( get_the_ID() ) ) ); ?>&amp;body=<?php echo esc_url( urlencode( get_permalink( get_the_ID() ) ) ); ?>"><i class="fa fa-envelope"></i><span class="screen-reader-text">Email</span></a></li>
				</ul>
			</div>
		<?php
	}
endif;

if ( ! function_exists( 'agencia_post_author_box' ) ) :
	/**
	 * Author post informations.
	 */
	function agencia_post_author_box() {

		// Get the data set in customizer
		$enable = get_theme_mod( 'agencia_author_box', 1 );

		// Disable if user choose it.
		if ( !$enable ) {
			return;
		}

		// Bail if not on the single post.
		if ( ! is_single() ) {
			return;
		}

		// Bail if not in 'post' type
		if ( 'post' != get_post_type() ) {
			return;
		}

		// Bail if user hasn't fill the Biographical Info field.
		if ( ! get_the_author_meta( 'description' ) ) {
			return;
		}

		// Get the author social information.
		$url       = get_the_author_meta( 'url' );
		$twitter   = get_the_author_meta( 'twitter' );
		$facebook  = get_the_author_meta( 'facebook' );
		$gplus     = get_the_author_meta( 'gplus' );
		$instagram = get_the_author_meta( 'instagram' );
		$pinterest = get_the_author_meta( 'pinterest' );
		$linkedin  = get_the_author_meta( 'linkedin' );
	?>

		<div class="author-bio">

			<div class="author-avatar">
				<?php echo get_avatar( is_email( get_the_author_meta( 'user_email' ) ), apply_filters( 'agencia_author_bio_avatar_size', 120 ), '', strip_tags( get_the_author() ) ); ?>
			</div>

			<div class="description">

				<h3 class="author-title name">
					<a class="author-name url fn n" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" rel="author"><?php echo strip_tags( get_the_author() ); ?></a>
				</h3>

				<p class="bio"><?php echo wp_kses_post( get_the_author_meta( 'description' ) ); ?></p>

				<?php if ( $url || $twitter || $facebook || $gplus || $instagram || $pinterest || $linkedin ) : ?>
					<div class="author-social-links">
						<?php if ( $url ) { ?>
							<a href="<?php echo esc_url( $url ); ?>"><i class="fa fa-home"></i></a>
						<?php } ?>
						<?php if ( $twitter ) { ?>
							<a href="<?php echo esc_url( $twitter ); ?>"><i class="fa fa-twitter"></i></a>
						<?php } ?>
						<?php if ( $facebook ) { ?>
							<a href="<?php echo esc_url( $facebook ); ?>"><i class="fa fa-facebook"></i></a>
						<?php } ?>
						<?php if ( $gplus ) { ?>
							<a href="<?php echo esc_url( $gplus ); ?>"><i class="fa fa-google-plus"></i></a>
						<?php } ?>
						<?php if ( $instagram ) { ?>
							<a href="<?php echo esc_url( $instagram ); ?>"><i class="fa fa-instagram"></i></a>
						<?php } ?>
						<?php if ( $pinterest ) { ?>
							<a href="<?php echo esc_url( $pinterest ); ?>"><i class="fa fa-pinterest"></i></a>
						<?php } ?>
						<?php if ( $linkedin ) { ?>
							<a href="<?php echo esc_url( $linkedin ); ?>"><i class="fa fa-linkedin"></i></a>
						<?php } ?>
					</div>
				<?php endif; ?>

			</div>

		</div><!-- .author-bio -->

	<?php
	}
endif;

if ( ! function_exists( 'agencia_next_prev_post' ) ) :
	/**
	 * Custom next post link
	 *
	 * @since 1.0.0
	 */
	function agencia_next_prev_post() {

		// Get the data set in customizer
		$nav  = get_theme_mod( 'agencia_next_prev_post', 1 );

		if ( !$nav ) {
			return;
		}

		// Display on single post page.
		if ( ! is_single() ) {
			return;
		}

		// Get the next and previous post id.
		$next = get_adjacent_post( false, '', false );
		$prev = get_adjacent_post( false, '', true );
	?>
		<div class="post-pagination">

			<?php if ( $prev ) : ?>
				<div class="prev-post">

					<div class="post-detail">
						<span><span class="arrow"><i class="fa fa-chevron-left" aria-hidden="true"></i></span><?php esc_html_e( 'Don\'t Miss it', 'agencia' ); ?></span>
						<a href="<?php echo esc_url( get_permalink( $prev->ID ) ); ?>" class="post-title"><?php echo esc_attr( get_the_title( $prev->ID ) ); ?></a>
					</div>

				</div>
			<?php endif; ?>

			<?php if ( $next ) : ?>
				<div class="next-post">

					<div class="post-detail">
						<span><?php esc_html_e( 'Up Next', 'agencia' ); ?><span class="arrow"><i class="fa fa-chevron-right" aria-hidden="true"></i></span></span>
						<a href="<?php echo esc_url( get_permalink( $next->ID ) ); ?>" class="post-title"><?php echo esc_attr( get_the_title( $next->ID ) ); ?></a>
					</div>

				</div>
			<?php endif; ?>

		</div>
	<?php
	}
endif;

if ( ! function_exists( 'agencia_related_posts' ) ) :
	/**
	 * Related posts.
	 */
	function agencia_related_posts() {

		// Get the data set in customizer
		$enable  = get_theme_mod( 'agencia_related_posts', 1 );
		$title   = get_theme_mod( 'agencia_related_posts_title', esc_html__( 'You Might Also Like', 'agencia' ) );
		$number  = get_theme_mod( 'agencia_related_posts_number', 5 );

		// Disable if user choose it.
		if ( !$enable ) {
			return;
		}

		// Get the taxonomy terms of the current page for the specified taxonomy.
		$terms = wp_get_post_terms( get_the_ID(), 'category', array( 'fields' => 'ids' ) );

		// Bail if the term empty.
		if ( empty( $terms ) ) {
			return;
		}

		// Posts query arguments.
		$query = array(
			'post__not_in' => array( get_the_ID() ),
			'tax_query'    => array(
				array(
					'taxonomy' => 'category',
					'field'    => 'id',
					'terms'    => $terms,
					'operator' => 'IN'
				)
			),
			'posts_per_page' => absint( $number ),
			'post_type'      => 'post',
		);

		// Allow dev to filter the query.
		$args = apply_filters( 'agencia_related_posts_args', $query );

		// The post query
		$related = new WP_Query( $args );

		if ( $related->have_posts() ) : ?>

			<div class="related-posts">
				<h3 class="related-posts-title"><?php echo wp_kses_post( $title ); ?></h3>
				<?php while ( $related->have_posts() ) : $related->the_post(); ?>
					<article class="post-layout-default">

						<div class="thumbnail">
							<?php agencia_post_thumbnail( 'agencia-post' ); ?>
						</div>

						<div class="content">
							<header class="entry-header">
								<?php agencia_post_header(); ?>
							</header>

							<div class="entry-summary">
								<?php the_excerpt(); ?>
							</div>

							<div class="post-meta">
								<?php agencia_post_meta(); ?>
							</div>
						</div>

					</article><!-- #post-## -->

				<?php endwhile; ?>
			</div>

		<?php endif;

		// Restore original Post Data.
		wp_reset_postdata();

	}
endif;

if ( ! function_exists( 'agencia_comment' ) ) :
	/**
	 * Template for comments and pingbacks.
	 *
	 * Used as a callback by wp_list_comments() for displaying the comments.
	 */
	function agencia_comment( $comment, $args, $depth ) {
		$GLOBALS['comment'] = $comment;
		switch ( $comment->comment_type ) :
			case 'pingback' :
			case 'trackback' :
			// Display trackbacks differently than normal comments.
		?>
		<li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">
			<article id="comment-<?php comment_ID(); ?>" class="comment-container">
				<p><?php esc_html_e( 'Pingback:', 'agencia' ); ?> <span><?php comment_author_link(); ?></span> <?php edit_comment_link( esc_html__( '(Edit)', 'agencia' ), '<span class="edit-link">', '</span>' ); ?></p>
			</article>
		<?php
				break;
			default :
			// Proceed with normal comments.
		?>
		<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
			<article id="comment-<?php comment_ID(); ?>" class="comment-container">

				<div class="comment-avatar">
					<?php echo get_avatar( $comment, apply_filters( 'agencia_comment_avatar_size', 80 ) ); ?>
					<span class="name"><?php echo get_comment_author_link(); ?></span>
					<?php echo agencia_comment_author_badge(); ?>
				</div>

				<div class="comment-body">
					<div class="comment-wrapper">

						<div class="comment-head">
							<?php
								$edit_comment_link = '';
								if ( get_edit_comment_link() )
									$edit_comment_link = sprintf( esc_html__( '&middot; %1$sEdit%2$s', 'agencia' ), '<a href="' . get_edit_comment_link() . '" title="' . esc_attr__( 'Edit Comment', 'agencia' ) . '">', '</a>' );

								printf( '<span class="date"><a href="%1$s"><time datetime="%2$s">%3$s</time></a> %4$s</span>',
									esc_url( get_comment_link( $comment->comment_ID ) ),
									get_comment_time( 'c' ),
									/* translators: 1: date, 2: time */
									sprintf( esc_html__( '%1$s at %2$s', 'agencia' ), get_comment_date(), get_comment_time() ),
									$edit_comment_link
								);
							?>
						</div><!-- comment-head -->

						<div class="comment-content comment-entry">
							<?php if ( '0' == $comment->comment_approved ) : ?>
								<p class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'agencia' ); ?></p>
							<?php endif; ?>
							<?php comment_text(); ?>
							<span class="reply">
								<?php comment_reply_link( array_merge( $args, array( 'reply_text' => wp_kses_post( __( '<i class="fa fa-reply"></i> Reply', 'agencia' ) ), 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
							</span><!-- .reply -->
						</div><!-- .comment-content -->

					</div>
				</div>

			</article><!-- #comment-## -->
		<?php
			break;
		endswitch; // end comment_type check
	}
endif;

if ( ! function_exists( 'agencia_comment_author_badge' ) ) :
	/**
	 * Custom badge for post author comment
	 */
	function agencia_comment_author_badge() {

		// Set up empty variable
		$output = '';

		// Get comment classes
		$classes = get_comment_class();

		if ( in_array( 'bypostauthor', $classes ) ) {
			$output = '<span class="author-badge">' . esc_html__( 'Author', 'agencia' ) . '</span>';
		}

		// Display the badge
		return apply_filters( 'agencia_comment_author_badge', $output );
	}
endif;

if ( ! function_exists( 'agencia_newsletter' ) ) :
	/**
	 * Newsletter
	 */
	function agencia_newsletter() {

		// Get the customizer data
		$enable    = get_theme_mod( 'agencia_newsletter_enable', 1 );
		$title     = get_theme_mod( 'agencia_newsletter_title', esc_html__( 'Want More News Like This?', 'agencia' ) );
		$desc      = get_theme_mod( 'agencia_newsletter_desc', esc_html__( 'Sign up to receive our weekly email newsletter and never miss an update!', 'agencia' ) );
		$shortcode = get_theme_mod( 'agencia_newsletter_shortcode' );

		if ( !$enable ) {
			return;
		}
	?>
		<div class="newsletter">
			<div class="container">

				<h3 class="newsletter-title"><?php echo esc_html( $title ); ?></h3>
				<div class="newsletter-desc"><?php echo esc_html( $desc ); ?></div>
				<div class="newsletter-form"><?php echo do_shortcode( $shortcode ); ?></div>

			</div>
		</div>
	<?php
	}
endif;

if ( ! function_exists( 'agencia_footer_text' ) ) :
	/**
	 * Footer text.
	 */
	function agencia_footer_text() {

		// Get the customizer data
		$default = '&copy; Copyright ' . date( 'Y' ) . ' <a href="' . esc_url( home_url() ) . '">' . esc_attr( get_bloginfo( 'name' ) ) . '</a> &middot; Designed and Developed by <a href="http://www.theme-junkie.com/">Theme Junkie</a>';
		$footer_text = get_theme_mod( 'agencia_footer_credits', $default );

		// Display the data
		echo '<p class="copyright">' . wp_kses_post( $footer_text ) . '</p>';

	}
endif;
