<?php
/**
 * Page Customizer
 */

/**
 * Register the customizer.
 */
function agencia_page_customize_register( $wp_customize ) {

	// Register new section: Page
	$wp_customize->add_section( 'agencia_page' , array(
		'title'    => esc_html__( 'Pages', 'agencia' ),
		'panel'    => 'agencia_options',
		'priority' => 11
	) );

	// Register Page comment manager setting
	$wp_customize->add_setting( 'agencia_page_comment', array(
		'default'           => 1,
		'sanitize_callback' => 'agencia_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'agencia_page_comment', array(
		'label'             => esc_html__( 'Enable comment on Pages', 'agencia' ),
		'section'           => 'agencia_page',
		'priority'          => 1,
		'type'              => 'checkbox'
	) );

	// Register Page title setting
	$wp_customize->add_setting( 'agencia_page_title', array(
		'default'           => 1,
		'sanitize_callback' => 'agencia_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'agencia_page_title', array(
		'label'             => esc_html__( 'Enable page title', 'agencia' ),
		'section'           => 'agencia_page',
		'priority'          => 3,
		'type'              => 'checkbox'
	) );

	// Register Page agencia image setting
	$wp_customize->add_setting( 'agencia_page_agencia_image', array(
		'default'           => 0,
		'sanitize_callback' => 'agencia_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'agencia_page_agencia_image', array(
		'label'             => esc_html__( 'Enable page featured image', 'agencia' ),
		'section'           => 'agencia_page',
		'priority'          => 5,
		'type'              => 'checkbox'
	) );

}
add_action( 'customize_register', 'agencia_page_customize_register' );
