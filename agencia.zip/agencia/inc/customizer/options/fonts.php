<?php
/**
 * Fonts Customizer
 */

/**
 * Register the customizer.
 */
function agencia_fonts_customize_register( $wp_customize ) {

	// Register new section: Fonts
	$wp_customize->add_section( 'agencia_fonts' , array(
		'title'       => esc_html__( 'Fonts', 'agencia' ),
		'description' => esc_html__( 'These options is used for customizing the fonts. The Google Fonts can be found here: https://fonts.google.com/.', 'agencia' ),
		'panel'       => 'agencia_options',
		'priority'    => 3
	) );

	// Register heading custom text.
	$wp_customize->add_setting( 'agencia_heading_font_title', array(
		'sanitize_callback' => 'esc_attr'
	) );
	$wp_customize->add_control( new Agencia_Custom_Text( $wp_customize, 'agencia_heading_font_title', array(
		'label'             => esc_html__( 'Heading', 'agencia' ),
		'section'           => 'agencia_fonts',
		'priority'          => 2
	) ) );

	// Register heading font setting.
	$wp_customize->add_setting( 'agencia_heading_font', array(
		'default'           => 'Raleway:400,400i,700,700i',
		'sanitize_callback' => 'wp_filter_post_kses',
	) );
	$wp_customize->add_control( 'agencia_heading_font', array(
		'description'       => esc_html__( 'Font name/style/sets', 'agencia' ),
		'section'           => 'agencia_fonts',
		'priority'          => 3,
		'type'              => 'text'
	) );

	// Register heading font family setting.
	$wp_customize->add_setting( 'agencia_heading_font_family', array(
		'default'           => '\'Raleway\', sans-serif',
		'sanitize_callback' => 'wp_kses_post',
	) );
	$wp_customize->add_control( 'agencia_heading_font_family', array(
		'description'       => esc_html__( 'Font family', 'agencia' ),
		'section'           => 'agencia_fonts',
		'priority'          => 4,
		'type'              => 'text'
	) );

	// Register body custom text.
	$wp_customize->add_setting( 'agencia_body_font_title', array(
		'sanitize_callback' => 'esc_attr'
	) );
	$wp_customize->add_control( new Agencia_Custom_Text( $wp_customize, 'agencia_body_font_title', array(
		'label'             => esc_html__( 'Body', 'agencia' ),
		'section'           => 'agencia_fonts',
		'priority'          => 5
	) ) );

	// Register body font setting.
	$wp_customize->add_setting( 'agencia_body_font', array(
		'default'           => 'Domine:400,700',
		'sanitize_callback' => 'wp_filter_post_kses',
	) );
	$wp_customize->add_control( 'agencia_body_font', array(
		'description'       => esc_html__( 'Font name/style/sets', 'agencia' ),
		'section'           => 'agencia_fonts',
		'priority'          => 6,
		'type'              => 'text'
	) );

	// Register body font family setting.
	$wp_customize->add_setting( 'agencia_body_font_family', array(
		'default'           => '\'Domine\', serif',
		'sanitize_callback' => 'wp_kses_post',
	) );
	$wp_customize->add_control( 'agencia_body_font_family', array(
		'description'       => esc_html__( 'Font family', 'agencia' ),
		'section'           => 'agencia_fonts',
		'priority'          => 7,
		'type'              => 'text'
	) );

}
add_action( 'customize_register', 'agencia_fonts_customize_register' );
