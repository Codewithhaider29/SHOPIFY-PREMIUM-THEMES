<?php
/**
 * Newsletter Customizer
 */

/**
 * Register the customizer.
 */
function agencia_newsletter_customize_register( $wp_customize ) {

	// Register new section: Newsletter
	$wp_customize->add_section( 'agencia_newsletter' , array(
		'title'    => esc_html__( 'Newsletter', 'agencia' ),
		'panel'    => 'agencia_options',
		'priority' => 15
	) );

	// Register enable newsletter setting
	$wp_customize->add_setting( 'agencia_newsletter_enable', array(
		'default'           => 1,
		'sanitize_callback' => 'agencia_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'agencia_newsletter_enable', array(
		'label'             => esc_html__( 'Enable newsletter', 'agencia' ),
		'section'           => 'agencia_newsletter',
		'priority'          => 1,
		'type'              => 'checkbox'
	) );

	// Register title setting
	$wp_customize->add_setting( 'agencia_newsletter_title', array(
		'default'           => esc_html__( 'Want News About Web Design?', 'agencia' ),
		'sanitize_callback' => 'agencia_sanitize_html',
	) );
	$wp_customize->add_control( 'agencia_newsletter_title', array(
		'label'             => esc_html__( 'Title', 'agencia' ),
		'section'           => 'agencia_newsletter',
		'priority'          => 3,
		'type'              => 'text'
	) );

	// Register description setting
	$wp_customize->add_setting( 'agencia_newsletter_desc', array(
		'default'           => esc_html__( 'Sign up to receive our weekly email newsletter and never miss an update!', 'agencia' ),
		'sanitize_callback' => 'agencia_sanitize_html',
	) );
	$wp_customize->add_control( 'agencia_newsletter_desc', array(
		'label'             => esc_html__( 'Description', 'agencia' ),
		'section'           => 'agencia_newsletter',
		'priority'          => 5,
		'type'              => 'text'
	) );

	// Register shortcode setting
	$wp_customize->add_setting( 'agencia_newsletter_shortcode', array(
		'default'           => '',
		'sanitize_callback' => 'agencia_sanitize_html',
	) );
	$wp_customize->add_control( 'agencia_newsletter_shortcode', array(
		'label'             => esc_html__( 'Form Shortcode', 'agencia' ),
		'section'           => 'agencia_newsletter',
		'priority'          => 7,
		'type'              => 'text'
	) );

}
add_action( 'customize_register', 'agencia_newsletter_customize_register' );
