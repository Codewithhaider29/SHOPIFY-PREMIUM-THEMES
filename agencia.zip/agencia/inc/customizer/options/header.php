<?php
/**
 * Header Customizer
 */

/**
 * Register the customizer.
 */
function agencia_header_customize_register( $wp_customize ) {

	// Register new section: Header
	$wp_customize->add_section( 'agencia_header' , array(
		'title'       => esc_html__( 'Header', 'agencia' ),
		'panel'       => 'agencia_options',
		'priority'    => 5
	) );

	// Register top bar background color setting
	$wp_customize->add_setting( 'agencia_header_bg_color', array(
		'default'           => '#ffffff',
		'sanitize_callback' => 'agencia_sanitize_hex_color',
		'transport'         => 'postMessage'
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'agencia_header_bg_color', array(
		'label'             => esc_html__( 'Header background color', 'agencia' ),
		'section'           => 'agencia_header',
		'priority'          => 1
	) ) );

	// Register fixed top bar setting
	$wp_customize->add_setting( 'agencia_top_bar_fixed', array(
		'default'           => 0,
		'sanitize_callback' => 'agencia_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'agencia_top_bar_fixed', array(
		'label'             => esc_html__( 'Fixed top bar', 'agencia' ),
		'section'           => 'agencia_header',
		'priority'          => 3,
		'type'              => 'checkbox'
	) );

	// Register show search setting
	$wp_customize->add_setting( 'agencia_header_search', array(
		'default'           => 1,
		'sanitize_callback' => 'agencia_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'agencia_header_search', array(
		'label'             => esc_html__( 'Show search button', 'agencia' ),
		'section'           => 'agencia_header',
		'priority'          => 5,
		'type'              => 'checkbox'
	) );

}
add_action( 'customize_register', 'agencia_header_customize_register' );
