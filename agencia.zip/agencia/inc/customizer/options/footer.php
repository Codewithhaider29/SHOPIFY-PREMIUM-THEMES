<?php
/**
 * Footer Customizer
 */

/**
 * Register the customizer.
 */
function agencia_footer_customize_register( $wp_customize ) {

	// Register new section: Footer
	$wp_customize->add_section( 'agencia_footer' , array(
		'title'    => esc_html__( 'Footer', 'agencia' ),
		'panel'    => 'agencia_options',
		'priority' => 17
	) );

	// Register footer widget column setting
	$wp_customize->add_setting( 'agencia_footer_widget_column', array(
		'default'           => '4',
		'sanitize_callback' => 'agencia_sanitize_select',
	) );
	$wp_customize->add_control( 'agencia_footer_widget_column', array(
		'label'             => esc_html__( 'Footer Widget Columns', 'agencia' ),
		'section'           => 'agencia_footer',
		'priority'          => 1,
		'type'              => 'radio',
		'choices'           => array(
			'3' => esc_html__( '3 Columns', 'agencia' ),
			'4' => esc_html__( '4 Columns', 'agencia' ),
			'6' => esc_html__( '6 Columns', 'agencia' )
		)
	) );

	// Register Footer Credits setting
	$wp_customize->add_setting( 'agencia_footer_credits', array(
		'sanitize_callback' => 'agencia_sanitize_html',
		'default'           => '&copy; Copyright ' . date( 'Y' ) . ' <a href="' . esc_url( home_url() ) . '">' . esc_attr( get_bloginfo( 'name' ) ) . '</a> &middot; Designed and Developed by <a href="http://www.theme-junkie.com/">Theme Junkie</a>',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'agencia_footer_credits', array(
		'label'             => esc_html__( 'Footer Text', 'agencia' ),
		'section'           => 'agencia_footer',
		'priority'          => 3,
		'type'              => 'textarea'
	) );
	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'agencia_footer_credits', array(
			'selector'         => '.copyright',
			'settings'         => array( 'agencia_footer_credits' ),
			'render_callback'  => function() {
				return agencia_sanitize_html( get_theme_mod( 'agencia_footer_credits' ) );
			}
		) );
	}

}
add_action( 'customize_register', 'agencia_footer_customize_register' );
