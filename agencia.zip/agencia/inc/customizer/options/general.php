<?php
/**
 * General Customizer
 */

/**
 * Register the customizer.
 */
function agencia_general_customize_register( $wp_customize ) {

	// Register new section: General
	$wp_customize->add_section( 'agencia_general' , array(
		'title'    => esc_html__( 'General', 'agencia' ),
		'panel'    => 'agencia_options',
		'priority' => 1
	) );

	// Register container setting
	$wp_customize->add_setting( 'agencia_container_style', array(
		'default'           => 'fullwidth',
		'sanitize_callback' => 'agencia_sanitize_select',
	) );
	$wp_customize->add_control( 'agencia_container_style', array(
		'label'             => esc_html__( 'Container', 'agencia' ),
		'section'           => 'agencia_general',
		'priority'          => 1,
		'type'              => 'radio',
		'choices'           => array(
			'fullwidth' => esc_html__( 'Full Width', 'agencia' ),
			'boxed'     => esc_html__( 'Boxed', 'agencia' ),
			'framed'    => esc_html__( 'Framed', 'agencia' )
		)
	) );

	// Register pagination setting
	$wp_customize->add_setting( 'agencia_posts_pagination', array(
		'default'           => 'number',
		'sanitize_callback' => 'agencia_sanitize_select',
	) );
	$wp_customize->add_control( 'agencia_posts_pagination', array(
		'label'             => esc_html__( 'Pagination type', 'agencia' ),
		'section'           => 'agencia_general',
		'priority'          => 3,
		'type'              => 'radio',
		'choices'           => array(
			'number'      => esc_html__( 'Number', 'agencia' ),
			'traditional' => esc_html__( 'Older / Newer', 'agencia' )
		)
	) );

	// Register sticky sidebar setting
	$wp_customize->add_setting( 'agencia_sticky_sidebar', array(
		'default'           => 0,
		'sanitize_callback' => 'agencia_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'agencia_sticky_sidebar', array(
		'label'             => esc_html__( 'Enable sticky sidebar', 'agencia' ),
		'section'           => 'agencia_general',
		'priority'          => 5,
		'type'              => 'checkbox'
	) );

}
add_action( 'customize_register', 'agencia_general_customize_register' );
