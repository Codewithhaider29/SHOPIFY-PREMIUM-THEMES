<?php
/**
 * Colors Customizer
 */

/**
 * Register the customizer.
 */
function agencia_colors_customize_register( $wp_customize ) {

	// Register predefined colors setting
	$wp_customize->add_setting( 'agencia_predefined_colors', array(
		'default'           => 'default',
		'sanitize_callback' => 'agencia_sanitize_select',
	) );
	$wp_customize->add_control( 'agencia_predefined_colors', array(
		'label'             => esc_html__( 'Predefined Colors', 'agencia' ),
		'section'           => 'colors',
		'priority'          => 1,
		'type'              => 'radio',
		'choices'           => array(
			'default' => esc_html__( 'Default', 'agencia' ),
			'pink'    => esc_html__( 'Pink', 'agencia' ),
			'purple'  => esc_html__( 'Purple', 'agencia' ),
			'green'   => esc_html__( 'Green', 'agencia' ),
			'blue'    => esc_html__( 'Blue', 'agencia' )
		)
	) );

	// Register accent color setting
	$wp_customize->add_setting( 'agencia_accent_color', array(
		'default'           => '#14b6cc',
		'sanitize_callback' => 'agencia_sanitize_hex_color'
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'agencia_accent_color', array(
		'label'             => esc_html__( 'Accent Color', 'agencia' ),
		'description'       => esc_html__( 'To get this color picker working, please set the Predefined Colors to &quot;Default&quot;', 'agencia' ),
		'section'           => 'colors',
		'priority'          => 3
	) ) );

	// Register body colors setting
	$wp_customize->add_setting( 'agencia_body_colors_text', array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr'
	) );
	$wp_customize->add_control( new Agencia_Custom_Text( $wp_customize, 'agencia_body_colors_text', array(
		'label'             => esc_html__( 'Body', 'agencia' ),
		'description'       => esc_html__( 'Body area colors setting.', 'agencia' ),
		'section'           => 'colors',
		'priority'          => 5
	) ) );

		// Register body background color setting
		$wp_customize->add_setting( 'agencia_body_bg_color', array(
			'default'           => '#ffffff',
			'sanitize_callback' => 'agencia_sanitize_hex_color',
			'transport'         => 'postMessage'
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'agencia_body_bg_color', array(
			'label'             => esc_html__( 'Background Color', 'agencia' ),
			'section'           => 'colors',
			'priority'          => 7
		) ) );

		// Register body text color setting
		$wp_customize->add_setting( 'agencia_body_text_color', array(
			'default'           => '#000000',
			'sanitize_callback' => 'agencia_sanitize_hex_color'
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'agencia_body_text_color', array(
			'label'             => esc_html__( 'Text Color', 'agencia' ),
			'section'           => 'colors',
			'priority'          => 9
		) ) );

		// Register body heading color setting
		$wp_customize->add_setting( 'agencia_body_heading_color', array(
			'default'           => '#000000',
			'sanitize_callback' => 'agencia_sanitize_hex_color'
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'agencia_body_heading_color', array(
			'label'             => esc_html__( 'Heading Color', 'agencia' ),
			'section'           => 'colors',
			'priority'          => 11
		) ) );

}
add_action( 'customize_register', 'agencia_colors_customize_register' );
