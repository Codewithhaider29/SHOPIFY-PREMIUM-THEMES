<?php
/**
 * Blog Customizer
 */

/**
 * Register the customizer.
 */
function agencia_blog_customize_register( $wp_customize ) {

	// Register new section: Blog
	$wp_customize->add_section( 'agencia_blog' , array(
		'title'       => esc_html__( 'Blog', 'agencia' ),
		'panel'       => 'agencia_options',
		'priority'    => 7
	) );

	// Register blog layouts setting
	$wp_customize->add_setting( 'agencia_blog_layouts', array(
		'default'           => '2c-l',
		'sanitize_callback' => 'agencia_sanitize_select',
	) );
	$wp_customize->add_control( 'agencia_blog_layouts', array(
		'label'             => esc_html__( 'Blog Layout', 'agencia' ),
		'section'           => 'agencia_blog',
		'priority'          => 1,
		'type'              => 'radio',
		'choices'           => array(
			'2c-l'   => esc_html__( 'Right sidebar', 'agencia' ),
			'2c-r'   => esc_html__( 'Left sidebar', 'agencia' ),
			'1c'     => esc_html__( 'No sidebar', 'agencia' )
		),
	) );

	// Register blog types setting
	$wp_customize->add_setting( 'agencia_blog_types', array(
		'default'           => 'default',
		'sanitize_callback' => 'agencia_sanitize_select',
	) );
	$wp_customize->add_control( 'agencia_blog_types', array(
		'label'             => esc_html__( 'Blog Types', 'agencia' ),
		'section'           => 'agencia_blog',
		'priority'          => 3,
		'type'              => 'radio',
		'choices'           => array(
			'default'       => esc_html__( 'Default', 'agencia' ),
			'grid-two'      => esc_html__( 'Grid 2 columns', 'agencia' ),
			'grid-three'    => esc_html__( 'Grid 3 columns', 'agencia' )
		),
	) );

}
add_action( 'customize_register', 'agencia_blog_customize_register' );
