<?php
/**
 * Customizer: Custom styles
 */

function agencia_custom_css() {

	// Set up empty variable.
	$css = '';

	// Get the customizer value.
	// Colors
	$accent               = get_theme_mod( 'agencia_accent_color', '#14b6cc' );
	$body_bg_color        = get_theme_mod( 'agencia_body_bg_color', '#ffffff' );
	$body_text_color      = get_theme_mod( 'agencia_body_text_color', '#000000' );
	$body_heading_color   = get_theme_mod( 'agencia_body_heading_color', '#000000' );
	$header_bg_color     = get_theme_mod( 'agencia_header_bg_color', '#333333' );

	// Typography
	$heading_font         = get_theme_mod( 'agencia_heading_font_family', '\'Raleway\', sans-serif' );
	$body_font            = get_theme_mod( 'agencia_body_font_family', '\'Domine\', serif' );

	if ( $heading_font != '\'Raleway\', sans-serif' ) {
		$css .= '
			h1, h2, h3, h4, h5, h6, .entry-author {
				font-family: ' . wp_kses_post( $heading_font ) . ';
			}
		';
	}

	if ( $body_font != '\'Domine\', serif' ) {
		$css .= '
			body {
				font-family: ' . wp_kses_post( $body_font ) . ';
			}
		';
	}

	// Accent
	if ( $accent != '#14b6cc' ) {
		$css .= '
			.secondary-navigation .secondary-menu-items,
			button, input[type="button"],
			input[type="reset"],
			input[type="submit"],
			.button,
			.pagination .current,
			.pagination .page-numbers:hover,
			.block-title,
			.author-badge,
			.format-icon,
			.elementor-page .elementor-widget-container h5 {
				background-color: ' . sanitize_hex_color( $accent ) . ';
			}

			.site-branding .site-title a:hover,
			.menu-toggle:hover,
			.primary-menu li a:hover,
			.social-menu li a:hover,
			.cat-links a,
			.entry-title a:hover,
			.post-meta a:hover,
			.widget_entries_thumbnail li .cat-links a,
			.widget li a:hover,
			.footer-sidebar .widget-title,
			.footer-sidebar .widget li a:hover,
			.site-info .copyright a,
			.post-pagination .post-detail span,
			.tag-links a:hover,
			.post-pagination .post-detail a:hover,
			.author-bio .description .name a:hover,
			.logged-in-as a,
			.post-edit-link,
			.cat-links,
			.agencia-elements .view-more,
			.page-content a,
			.widget_entries_thumbnail .post-title:hover,
			.elementor-widget-wp-widget-agencia-posts .post-title:hover {
			  color: ' . sanitize_hex_color( $accent ) . ';
			}

			.primary-menu .sub-menu li:hover,
			blockquote {
			  border-color: ' . sanitize_hex_color( $accent ) . ';
			}

		';
	}

	if ( $body_bg_color != '#ffffff' ) {
		$css .= '.wide-container { background-color: ' . sanitize_hex_color( $body_bg_color ) . '; }';
	}

	if ( $body_text_color != '#000000' ) {
		$css .= 'body { color: ' . sanitize_hex_color( $body_text_color ) . '; }';
	}

	if ( $body_heading_color != '#000000' ) {
		$css .= 'h1, h2, h3, h4, h5, h6, h1 a, h2 a, h3 a, h4 a, h5 a, h6 a, h1.entry-title a, h2.entry-title a, h1.entry-title a:visited, h2.entry-title a:visited, h1 a:visited, h2 a:visited, h3 a:visited, h4 a:visited, h5 a:visited, h6 a:visited, .ad-widget .widget-title, .footer-sidebar .widget-title { color: ' . sanitize_hex_color( $body_heading_color ) . '; }';
	}

	if ( $header_bg_color != '#333333' ) {
		$css .= '.site-header { background-color: ' . sanitize_hex_color( $header_bg_color ) . '; }';
	}

	// Print the custom style
	wp_add_inline_style( 'agencia-style', $css );

}
add_action( 'wp_enqueue_scripts', 'agencia_custom_css' );
