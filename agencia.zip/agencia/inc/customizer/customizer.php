<?php
/**
 * Agencia Theme Customizer
 */

// Loads custom control
require trailingslashit( get_template_directory() ) . 'inc/customizer/custom/text.php';

// Loads the customizer options
require trailingslashit( get_template_directory() ) . 'inc/customizer/options/retina-logo.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/options/general.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/options/header.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/options/blog.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/options/post.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/options/page.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/options/newsletter.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/options/footer.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/options/fonts.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/options/colors.php';

/**
 * Custom customizer functions.
 */
function agencia_customize_functions( $wp_customize ) {

	// Register new panel: Theme Options
	$wp_customize->add_panel( 'agencia_options', array(
		'title'       => esc_html__( 'Theme Options', 'agencia' ),
		'description' => esc_html__( 'This panel is used for customizing the Agencia theme.', 'agencia' ),
		'priority'    => 130,
	) );

	// Live preview of Site Title
	$wp_customize->get_setting( 'blogname' )->transport = 'postMessage';

	// Enable selective refresh to the Site Title
	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'blogname', array(
			'selector'            => '.site-title a',
			'settings'         => array( 'blogname' ),
			'render_callback'  => function() {
				return get_bloginfo( 'name', 'display' );
			}
		) );
	}

	// Move the Colors section.
	$wp_customize->get_section( 'colors' )->panel    = 'agencia_options';
	$wp_customize->get_section( 'colors' )->priority = 2;

	// Move the Theme Layout
	// $wp_customize->get_section( 'layout' )->panel    = 'agencia_options';
	// $wp_customize->get_section( 'layout' )->title    = esc_html__( 'Layouts', 'agencia' );
	// $wp_customize->get_section( 'layout' )->priority = 5;
	// $wp_customize->get_control( 'theme-layout-control' )->label    = esc_html__( 'Post / Page Layout', 'agencia' );
	// $wp_customize->get_control( 'theme-layout-control' )->priority = 1;
	// $wp_customize->get_control( 'theme-layout-control' )->active_callback = function() {
	// 	return is_page() || is_single();
	// };

	// Move the Background Image section.
	$wp_customize->get_section( 'background_image' )->panel    = 'agencia_options';
	$wp_customize->get_section( 'background_image' )->priority = 3;

	// Move background color to background image section.
	$wp_customize->get_section( 'background_image' )->title = esc_html__( 'Background', 'agencia' );
	$wp_customize->get_control( 'background_color' )->section = 'background_image';


}
add_action( 'customize_register', 'agencia_customize_functions', 99 );

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function agencia_customize_preview_js() {
	wp_enqueue_script( 'agencia-customizer', get_template_directory_uri() . '/inc/customizer/assets/js/preview.js', array( 'customize-preview', 'jquery' ) );
}
add_action( 'customize_preview_init', 'agencia_customize_preview_js' );

/**
 * Display theme documentation on customizer page.
 */
function agencia_documentation_link() {

	// Enqueue the script
	wp_enqueue_script( 'agencia-doc', get_template_directory_uri() . '/inc/customizer/assets/js/doc.js', array(), '1.0.0', true );

	// Localize the script
	wp_localize_script( 'agencia-doc', 'agenciaL10n',
		array(
			'agenciaURL'   => esc_url( 'http://docs.theme-junkie.com/agencia/' ),
			'agenciaLabel' => esc_html__( 'Documentation', 'agencia' ),
		)
	);

}
add_action( 'customize_controls_enqueue_scripts', 'agencia_documentation_link' );
