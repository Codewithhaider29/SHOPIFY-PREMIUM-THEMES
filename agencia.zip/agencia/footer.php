		</div><!-- #content -->

		<footer id="colophon" class="site-footer">

			<div class="container">
				<?php get_template_part( 'sidebar', 'footer' ); // Loads the sidebar-footer.php template. ?>
			</div>

			<?php agencia_newsletter(); ?>

			<div class="site-info">
				<div class="container">
					<?php if ( has_nav_menu ( 'social' ) ) : ?>
						<?php wp_nav_menu(
							array(
								'theme_location'  => 'social',
								'link_before'     => '<span class="screen-reader-text">',
								'link_after'      => '</span>',
								'depth'           => 1,
								'container'       => '',
								'menu_id'         => 'social-menu',
								'menu_class'      => 'social-menu'
							)
						); ?>
					<?php endif; ?>
					<?php agencia_footer_text(); ?>
				</div>
			</div><!-- .site-info -->

		</footer><!-- #colophon -->

	</div><!-- .wide-container -->

</div><!-- #page -->

<a href="#" class="back-to-top" title="<?php esc_html_e( 'Back to top', 'agencia' ); ?>"><i class="fa fa-chevron-up" aria-hidden="true"></i></a>

<div id="menu-overlay" class="menu-popup popup-content mfp-hide">
	<?php if ( has_nav_menu ( 'primary' ) ) : ?>
		<nav class="primary-navigation">
			<?php wp_nav_menu(
				array(
					'theme_location'  => 'primary',
					'menu_id'         => 'menu-primary-items',
					'menu_class'      => 'menu-primary-items',
					'container'       => false
				)
			); ?>
		</nav>
	<?php endif; ?>
</div>

<div id="search-overlay" class="search-popup popup-content mfp-hide">
	<form method="get" class="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
		<input type="search" class="search-field field" placeholder="<?php echo esc_attr_x( 'Type keyword &hellip;', 'placeholder', 'agencia' ) ?>" value="<?php echo get_search_query() ?>" name="s" title="<?php echo esc_attr_x( 'Search for:', 'label', 'agencia' ) ?>" />
	</form>
</div>

<?php wp_footer(); ?>

</body>
</html>
