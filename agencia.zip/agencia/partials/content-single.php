<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<header class="entry-header">
		<?php if ( 'post' == get_post_type() ) : ?>
			<?php
				/* translators: used between list items, there is a space after the comma */
				$categories_list = get_the_category_list( esc_html__( ', ', 'agencia' ) );
				if ( $categories_list ) :
			?>
				<span class="cat-links">
					<?php echo $categories_list; ?>
				</span>
			<?php endif; // End if categories ?>
		<?php endif; ?>

		<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>

		<div class="post-meta">
			<?php agencia_post_meta(); ?>
		</div>
	</header>

	<div class="thumbnail">
		<?php agencia_post_thumbnail( 'agencia-post-large' ); ?>
	</div>

	<div class="content">

		<?php agencia_social_share(); ?>

		<div class="post-content">

			<?php the_content(); ?>
			<?php
				wp_link_pages( array(
					'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'agencia' ),
					'after'  => '</div>',
				) );
			?>

			<?php
				$tags   = get_the_tags();
				$enable = get_theme_mod( 'agencia_post_tags', 1 );
				$title  = get_theme_mod( 'agencia_post_tags_title', esc_html__( 'Topics', 'agencia' ) );
				if ( $enable && $tags ) :
			?>
				<span class="tag-links">
					<span class="tag-title"><?php echo esc_html( $title ); ?></span>
					<?php foreach( $tags as $tag ) : ?>
						<a href="<?php echo esc_url( get_tag_link( $tag->term_id ) ); ?>">#<?php echo esc_attr( $tag->name ); ?></a>
					<?php endforeach; ?>
				</span>
			<?php endif; ?>

		</div>

	</div>

</article><!-- #post-## -->
