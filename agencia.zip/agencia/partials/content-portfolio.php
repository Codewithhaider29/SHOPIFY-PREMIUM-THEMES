<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<div class="thumbnail">
		<a class="post-thumbnail" href="<?php the_permalink(); ?>">
			<?php
				the_post_thumbnail( 'agencia-portfolio', array(
					'alt' => the_title_attribute( array(
						'echo' => false,
					) ),
				) );
			?>
			<i class="fa fa-external-link" aria-hidden="true"></i>
		</a>
	</div>

</article>
