<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<div class="thumbnail">
		<?php agencia_post_thumbnail( 'agencia-post-large' ); ?>
	</div>

	<div class="portfolio-content">

		<?php the_title( '<h1 class="entry-title block-title">', '</h1>' ); ?>

		<div class="portfolio-meta">
			<ul>
				<?php
					$desc = get_post_meta( $post->ID, 'tj_portfolio_short_desc', true );
					if ( $desc ) :
				?>
					<li>
						<span class="info"><?php esc_html_e( 'Info:', 'agencia' ) ?></span>
						<span class="detail"><?php echo esc_html( $desc ); ?></span>
					</li>
				<?php endif; ?>
				<?php
					$client = get_post_meta( $post->ID, 'tj_portfolio_client', true );
					if ( $client ) :
				?>
					<li>
						<span class="info"><?php esc_html_e( 'Client:', 'agencia' ) ?></span>
						<span class="detail"><?php echo esc_html( $client ); ?></span>
					</li>
				<?php endif; ?>
				<?php
					$link = get_post_meta( $post->ID, 'tj_portfolio_link', true );
					if ( $link ) :
				?>
					<li>
						<span class="info"><?php esc_html_e( 'URL:', 'agencia' ) ?></span>
						<span class="detail"><a href="<?php echo esc_url( $link ); ?>" rel="nofollow"><?php echo esc_html( $link ); ?></a></span>
					</li>
				<?php endif; ?>
			</ul>
		</div>

		<div class="portfolio-description">
			<?php the_content(); ?>
		</div>

	</div>

</article><!-- #post-## -->
