<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<div class="thumbnail">
		<?php agencia_post_thumbnail( 'agencia-post' ); ?>
	</div>

	<div class="content">
		<header class="entry-header">
			<?php agencia_post_header(); ?>
		</header>

		<div class="entry-summary">
			<?php the_excerpt(); ?>
		</div>

		<div class="post-meta">
			<?php agencia_post_meta(); ?>
		</div>
	</div>

</article><!-- #post-## -->
