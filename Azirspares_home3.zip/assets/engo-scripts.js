jQuery(document).ready(function($) {
  var $body = $('body');
  
  $('.js-chosen-all-cate').on('click', function() {
    $(this).toggleClass('chosen-with-drop');
  });

  $('.js-click-menu1').on('click', function() {
    $('.js-menu1').addClass('open');
  });

  $('.js-click-overlay, .js-close-menu1').on('click', function() {
    $('.js-menu1').removeClass('open');
  });

  $('.js-click-all-departments').on('click', function() {
    $('.js-wrap-all-departments').toggleClass('has-open');
  });

  $('.menu-toggle').on('click', function() {
    $('.azirspares-menu-clone-wrap').addClass('open');
  });

  $('.azirspares-menu-clone-wrap .azirspares-menu-close-panels').on('click', function() {
    $('.azirspares-menu-clone-wrap').removeClass('open');
  });


  $('body').on("click", ".azirspares-menu-next-panel", function(j) {
    var i = $(this)
    , n = i.closest(".menu-item")
    , o = i.closest(".azirspares-menu-panel")
    , m = i.attr("href");
    if ($(m).length) {
      o.addClass("azirspares-menu-sub-opened");
      $(m).addClass("azirspares-menu-panel-opened").removeClass("azirspares-menu-hidden").attr("data-parent-panel", o.attr("id"));
      var l = n.find(".azirspares-menu-item-title").attr("title")
      , k = "";
      if ($(".azirspares-menu-panels-actions-wrap .azirspares-menu-current-panel-title").length > 0) {
        k = $(".azirspares-menu-panels-actions-wrap .azirspares-menu-current-panel-title").html()
      }
      if (typeof l != "undefined" && typeof l != !1) {
        if (!$(".azirspares-menu-panels-actions-wrap .azirspares-menu-current-panel-title").length) {
          $(".azirspares-menu-panels-actions-wrap").prepend('<span class="azirspares-menu-current-panel-title"></span>')
        }
        $(".azirspares-menu-panels-actions-wrap .azirspares-menu-current-panel-title").html(l)
      } else {
        $(".azirspares-menu-panels-actions-wrap .azirspares-menu-current-panel-title").remove()
      }
      $(".azirspares-menu-panels-actions-wrap .azirspares-menu-prev-panel").remove();
      $(".azirspares-menu-panels-actions-wrap").prepend('<a data-prenttitle="' + k + '" class="azirspares-menu-prev-panel" href="#' + o.attr("id") + '" data-cur-panel="' + m + '" data-target="#' + o.attr("id") + '"></a>')
    }
    j.preventDefault()
  });

  $('body').on("click", ".azirspares-menu-prev-panel", function(k) {
    var i = $(this)
    , j = i.attr("data-cur-panel")
    , n = i.attr("href");
    $(j).removeClass("azirspares-menu-panel-opened").addClass("azirspares-menu-hidden");
    $(n).addClass("azirspares-menu-panel-opened").removeClass("azirspares-menu-sub-opened");
    var m = $(n).attr("data-parent-panel");
    if (typeof m == "undefined" || typeof m == !1) {
      $(".azirspares-menu-panels-actions-wrap .azirspares-menu-prev-panel").remove();
      $(".azirspares-menu-panels-actions-wrap .azirspares-menu-current-panel-title").remove()
    } else {
      $(".azirspares-menu-panels-actions-wrap .azirspares-menu-prev-panel").attr("href", "#" + m).attr("data-cur-panel", n).attr("data-target", "#" + m);
      var l = $("#" + m).find('.azirspares-menu-next-panel[data-target="' + n + '"]').closest(".menu-item").find(".azirspares-menu-item-title").attr("data-title");
      l = a(this).data("prenttitle");
      if (typeof l != "undefined" && typeof l != !1) {
        if (!$(".azirspares-menu-panels-actions-wrap .azirspares-menu-current-panel-title").length) {
          $(".azirspares-menu-panels-actions-wrap").prepend('<span class="azirspares-menu-current-panel-title"></span>')
        }
        $(".azirspares-menu-panels-actions-wrap .azirspares-menu-current-panel-title").html(l)
      } else {
        $(".azirspares-menu-panels-actions-wrap .azirspares-menu-current-panel-title").remove()
      }
    }
    k.preventDefault()
  });


//   $('body').find('.vertical-menu').each(function() {
//     var _main = $(this);
//     _main.children('.menu-item.parent').each(function() {
//       var curent = $(this).find('.submenu');
//       $(this).children('.toggle-submenu').on('click', function() {
//         $(this).parent().children('.submenu').stop().slideToggle(300);
//         _main.find('.submenu').not(curent).stop().slideUp(300);
//         $(this).parent().toggleClass('show-submenu');
//         _main.find('.menu-item.parent').not($(this).parent()).removeClass('show-submenu')
//       });
//       var next_curent = $(this).find('.submenu');
//       next_curent.children('.menu-item.parent').each(function() {
//         var child_curent = $(this).find('.submenu');
//         $(this).children('.toggle-submenu').on('click', function() {
//           $(this).parent().parent().find('.submenu').not(child_curent).stop().slideUp(300);
//           $(this).parent().children('.submenu').stop().slideToggle(300);
//           $(this).parent().parent().find('.menu-item.parent').not($(this).parent()).removeClass('show-submenu');
//           $(this).parent().toggleClass('show-submenu')
//         })
//       })
//     })
//   });

  $(document).on('click', 'a.backtotop', function(e) {
    $('html, body').animate({
      scrollTop: 0
    }, 800);
    e.preventDefault()
  });
  $(document).on('scroll', function() {
    if ($(window).scrollTop() > 200) {
      $('.backtotop').addClass('active')
    } else {
      $('.backtotop').removeClass('active')
    }
    if ($(window).scrollTop() > 0) {
      $('body').addClass('scroll-mobile')
    } else {
      $('body').removeClass('scroll-mobile')
    }
  });

  if ($('#banner-adv').length > 0) {
    $('.close-banner').on('click', function() {
      $('#banner-adv').hide()
    });
  }

  function azirspares_sticky_menu($elem) {
    var $this = $elem;
    $this.on('azirspares_sticky_menu', function() {
      $this.each(function() {
        var previousScroll = 0
        , header = $(this).closest('.header')
        , header_wrap_stick = $(this)
        , header_position = $(this).find('.header-position')
        , headerOrgOffset = header_position.offset().top;
        if ($(window).width() > 1024) {
          header_wrap_stick.css('height', header_wrap_stick.outerHeight());
          $(document).on('scroll', function(ev) {
            var currentScroll = $(this).scrollTop();
            if (currentScroll > headerOrgOffset) {
              if (currentScroll > previousScroll) {
                header_position.addClass('hide-header')
              } else {
                header_position.removeClass('hide-header');
                header_position.addClass('fixed')
              }
            } else {
              header_position.removeClass('fixed')
            }
            previousScroll = currentScroll
          })
        } else {
          header_wrap_stick.css("height", "auto")
        }
      })
    }).trigger('azirspares_sticky_menu');
    $(window).on('resize', function() {
      $this.trigger('azirspares_sticky_menu')
    })
  }

  if ($('.header-sticky .header-wrap-stick').length) {
    azirspares_sticky_menu($('.header-sticky .header-wrap-stick'));
  }

  function azirspares_vertical_menu($elem) {
    var _countLi = 0
    , _verticalMenu = $elem.find('.vertical-menu')
    , _blockNav = $elem.closest('.block-nav-category')
    , _blockTitle = $elem.find('.block-title');
    $elem.each(function() {
      var _dataItem = $(this).data('items') - 1;
      _countLi = $(this).find('.vertical-menu>li').length;
      if (_countLi > (_dataItem + 1)) {
        $(this).addClass('show-button-all')
      }
      $(this).find('.vertical-menu>li').each(function(i) {
        _countLi = _countLi + 1;
        if (i > _dataItem) {
          $(this).addClass('link-other')
        }
      })
    });
    $elem.find('.vertical-menu').each(function() {
      var _main = $(this);
      _main.children('.menu-item.parent').each(function() {
        var curent = $(this).find('.submenu');
        $(this).children('.toggle-submenu').on('click', function() {
          $(this).parent().children('.submenu').stop().slideToggle(300);
          _main.find('.submenu').not(curent).stop().slideUp(300);
          $(this).parent().toggleClass('show-submenu');
          _main.find('.menu-item.parent').not($(this).parent()).removeClass('show-submenu')
        });
        var next_curent = $(this).find('.submenu');
        next_curent.children('.menu-item.parent').each(function() {
          var child_curent = $(this).find('.submenu');
          $(this).children('.toggle-submenu').on('click', function() {
            $(this).parent().parent().find('.submenu').not(child_curent).stop().slideUp(300);
            $(this).parent().children('.submenu').stop().slideToggle(300);
            $(this).parent().parent().find('.menu-item.parent').not($(this).parent()).removeClass('show-submenu');
            $(this).parent().toggleClass('show-submenu')
          })
        })
      })
    });
    if (_verticalMenu.length > 0) {
      $(document).on('click', '.open-cate', function(e) {
        _blockNav.find('li.link-other').each(function() {
          $(this).slideDown()
        });
        $(this).addClass('close-cate').removeClass('open-cate').html($(this).data('closetext'));
        e.preventDefault()
      });
      $(document).on('click', '.close-cate', function(e) {
        _blockNav.find('li.link-other').each(function() {
          $(this).slideUp()
        });
        $(this).addClass('open-cate').removeClass('close-cate').html($(this).data('alltext'));
        e.preventDefault()
      });
      _blockTitle.on('click', function() {
        $(this).toggleClass('active');
//         $(this).parent().toggleClass('has-open');
//         $body.toggleClass('category-open');
      })
    }
  }
  
  if ($('.block-nav-category').length) {
    azirspares_vertical_menu($('.block-nav-category'))
  }

  function azirspares_better_equal_elems($elem) {
    $elem.each(function() {
      if ($(this).find('.equal-elem').length) {
        $(this).find('.equal-elem').css({
          'height': 'auto'
        });
        var _height = 0;
        $(this).find('.equal-elem').each(function() {
          if (_height < $(this).height()) {
            _height = $(this).height()
          }
        });
        $(this).find('.equal-elem').height(_height)
      }
    });
  }

  if ($('.equal-container.better-height').length) {
    azirspares_better_equal_elems($('.equal-container.better-height'));
  }

  if ($('.seller-items').length) {
    azirspares_better_equal_elems($('.seller-items'));
  }

  $(window).resize(function() {
    if ($('.equal-container.better-height').length) {
      azirspares_better_equal_elems($('.equal-container.better-height'));
    }
  });

  function azirspares_popover_button() {
    $('[data-toggle="tooltip"]').each(function() {
      $(this).tooltip({
        title: $(this).text()
      })
    });
    $('.product-item .engoc-btn-quickview,.product-item .compare,.product-item .add_to_wishlist').each(function() {
      $(this).tooltip({
        title: $(this).text(),
        trigger: 'hover',
        placement: 'top'
      })
    })
  }

  azirspares_popover_button();

  function azirspares_init_carousel($elem) {
    $elem.not('.slick-initialized').each(function() {
      var _this = $(this)
      , _responsive = _this.data('responsive')
      , _config = [];
      if (_this.hasClass('slick-vertical')) {
        _config.prevArrow = '<span class="fa fa-angle-up prev"></span>';
        _config.nextArrow = '<span class="fa fa-angle-down next"></span>'
      } else {
        _config.prevArrow = '<span class="fa fa-angle-left prev"></span>';
        _config.nextArrow = '<span class="fa fa-angle-right next"></span>'
      }
      _config.responsive = _responsive;
      _this.on('init', function(event, slick, direction) {
        azirspares_popover_button()
      });
      _this.slick(_config);
    })
  }

  if ($('.owl-slick').length) {
    $('.owl-slick').each(function() {
      if (!$(this).is('.cat_list_mobile')) {
        azirspares_init_carousel($(this))
      }
    })
  }

  function azirspares_product_gallery($elem) {
    $elem.each(function() {
      var _items = $(this).closest('.product-inner').data('items')
      , _main_slide = $(this).find('.product-gallery-slick')
      , _dot_slide = $(this).find('.gallery-dots');
      _main_slide.not('.slick-initialized').each(function() {
        var _this = $(this)
        , _config = [];
        if ($('body').hasClass('rtl')) {
          _config.rtl = !0
        }
        _config.prevArrow = '<span class="fa fa-angle-left prev"></span>';
        _config.nextArrow = '<span class="fa fa-angle-right next"></span>';
        _config.cssEase = 'linear';
        _config.infinite = !0;
        _config.fade = !0;
        _config.slidesMargin = 0;
        _config.arrows = !1;
        _config.asNavFor = _dot_slide;
        _this.slick(_config)
      });
      _dot_slide.not('.slick-initialized').each(function() {
        var _config = [];
        if ($('body').hasClass('rtl')) {
          _config.rtl = !0
        }
        _config.slidesToShow = _items;
        _config.infinite = !0;
        _config.focusOnSelect = !0;
        _config.vertical = !0;
        _config.slidesMargin = 0;
        _config.prevArrow = '<span class="fa fa-angle-up prev"></span>';
        _config.nextArrow = '<span class="fa fa-angle-down next"></span>';
        _config.asNavFor = _main_slide;
        _config.responsive = [{
          breakpoint: 1200,
          settings: {
            vertical: !1,
            prevArrow: '<span class="fa fa-angle-left prev"></span>',
            nextArrow: '<span class="fa fa-angle-right next"></span>',
          }
        }];
        $(this).slick(_config)
      })
    })
  }

  if ($('.product-gallery').length) {
    azirspares_product_gallery($('.product-gallery'));

    if ($('.equal-container.better-height').length) {
      azirspares_better_equal_elems($('.equal-container.better-height'));
    }
  }

  function azirspares_category_product($elem) {
    $elem.each(function () {
      var _main = $(this);
      _main.find('.cat-parent').each(function () {
        if ($(this).hasClass('current-cat-parent')) {
          $(this).addClass('show-sub');
          $(this).children('.children').stop().slideDown(300);
        }
        $(this).children('.children').before('<span class="carets"></span>');
      });
      _main.children('.cat-parent').each(function () {
        var curent = $(this).find('.children');
        $(this).children('.carets').on('click', function () {
          $(this).parent().toggleClass('show-sub');
          $(this).parent().children('.children').stop().slideToggle(300);
          _main.find('.children').not(curent).stop().slideUp(300);
          _main.find('.cat-parent').not($(this).parent()).removeClass('show-sub');
        });
        var next_curent = $(this).find('.children');
        next_curent.children('.cat-parent').each(function () {
          var child_curent = $(this).find('.children');
          $(this).children('.carets').on('click', function () {
            $(this).parent().toggleClass('show-sub');
            $(this).parent().parent().find('.cat-parent').not($(this).parent()).removeClass('show-sub');
            $(this).parent().parent().find('.children').not(child_curent).stop().slideUp(300);
            $(this).parent().children('.children').stop().slideToggle(300);
          })
        });
      });
    });
  }

  if ($('.widget_product_categories .product-categories').length) {
    azirspares_category_product($('.widget_product_categories .product-categories'));
  }
  
  if ($('.azjs-slider-for').length) {
    $('.azjs-slider-for').slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: !1,
      fade: !0,
      asNavFor: '.azjs-slider-nav'
    })
  }
  if ($('.azjs-slider-nav').length) {
    $('.azjs-slider-nav').slick({
      slidesToShow: 4,
      slidesToScroll: 1,
      asNavFor: '.azjs-slider-for',
      arrows: true,
      prevArrow: '<span class="fa fa-angle-left prev slick-arrow"></span>',
      nextArrow: '<span class="fa fa-angle-right next slick-arrow"></span>',
      vertical: true,
      infinite: false,
      dots: !1,
      focusOnSelect: !0,
      responsive: [
        {
          breakpoint: 992,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 1,
            vertical: false
          }
        }
      ]
    })
  }
  
  if ($('.famiau-slider-for').length) {
    $('.famiau-slider-for').slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: !1,
      fade: !0,
      asNavFor: '.famiau-slider-nav'
    })
  }
  if ($('.famiau-slider-nav').length) {
    $('.famiau-slider-nav').slick({
      slidesToShow: 5,
      slidesToScroll: 1,
      asNavFor: '.famiau-slider-for',
      dots: !1,
      focusOnSelect: !0
    })
  }
  
  $('.engojs-filter-v1-select').on('click', function() {
    var tag_value = $(this).data('value');
    $(this).closest('.engojs-filter-v1-parent').find('.engojs-filter-v1-inner').attr('data-tag', tag_value);
    
    var collection_url = '/collections/all?constraint=';
    var all_tag_value= $('.engojs-filter-v1-wrapper .engojs-filter-v1-inner').map(function() { 
      if ($(this).attr('data-tag') != "") { 
        return $(this).attr('data-tag');
      } 
    })
    .get()
    .join('+');
    
    var newURL = collection_url + all_tag_value;
    $(this).closest('.engojs-filter-v1-wrapper').find('.engojs-filter-v1-btn').attr('href', newURL);
  });
  
  $('.engojs-filter-v2-select').on('click', function() {
    var tag_value = $(this).data('value');
    $(this).closest('.engojs-filter-v2-parent').find('.engojs-filter-v2-inner').attr('data-tag', tag_value);
    
    var collection_url = '/collections/all?constraint=';
    var all_tag_value= $('.engojs-filter-v2-wrapper .engojs-filter-v2-inner').map(function() { 
      if ($(this).attr('data-tag') != "") { 
        return $(this).attr('data-tag');
      } 
    })
    .get()
    .join('+');
    
    var newURL = collection_url + all_tag_value;
    $(this).closest('.engojs-filter-v2-wrapper').find('.engojs-filter-v2-btn').attr('href', newURL);
  });

  $('.engoj-bstab-slick').on('click', function() {
    var tab_id = $(this).attr('href');
    $(this).closest('.owl-slick').find('.slick-slide').removeClass('active');
    $(this).closest('.azirspares-tabs').find('.tab-panel').removeClass('active');

    $(this).parent('.slick-slide').addClass('active');
    $(this).closest('.azirspares-tabs').find(tab_id).addClass('active');
  });
  
  
  
  function slideshowV2() {
    $('.js-slideshow-v2').slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      infinite: true,
      arrows: false,
      dots: true,
      fade: true
    });

    $('.js-slideshow-v2 .slideshow-content').eq(0).addClass('active');

    $('.js-slideshow-v2').on('beforeChange', function (event, slick, currentSlide, nextSlide) {
      var mySlideNumber = nextSlide;
      var prev = mySlideNumber - 2;
      $('.section-slideshow-v2 .slideshow-content').eq(mySlideNumber).addClass('active');

      $('.section-slideshow-v2 .slideshow-content').eq(prev).removeClass('active');
    })                  
  }

  function slideshowV3() {
    $('.js-slideshow-v3').slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      infinite: true,
      arrows: false,
      dots: true,
      fade: true
    });
    if ($(window).width() > 1199) {
      $('.section-slideshow-v3').on('mousemove',function(event){
        var left = event.clientX;
        var top = event.clientY
        $('.js-effect-v3').each(function(){
          var top1 = $('.col-lg-7').position().top + $('.slider-v3').position().top
          var left1 = $('.col-lg-7').position().left + $('.slider-v3').position().left
          $('.js-effect-v3').css("transform",function(){
            var x = -(left-left1)/40
            var y = -(top-top1)/40
            return 'translate('+x+'px,'+y+'px)'
          })
        })
      })
    }
    $(window).resize(function(){
      if ($(window).width() > 1199) {
        $('.section-slideshow-v3').on('mousemove',function(event){
          var left = event.clientX;
          var top = event.clientY
          $('.js-effect-v3').each(function(){
            var top1 = $('.col-lg-7').position().top + $('.slider-v3').position().top
            var left1 = $('.col-lg-7').position().left + $('.slider-v3').position().left
            $('.js-effect-v3').css("transform",function(){
              var x = -(left-left1)/40
              var y = -(top-top1)/40
              return 'translate('+x+'px,'+y+'px)'
            })
          })
        })
      } else {
        $('.js-effect-v3').css("transform","none")
      }
    })


    $('.js-slideshow-v3 .slideshow-content').eq(0).addClass('active');

    $('.js-slideshow-v3').on('beforeChange', function (event, slick, currentSlide, nextSlide) {
      var mySlideNumber = nextSlide;
      var prev = mySlideNumber - 2;
      $('.section-slideshow-v3 .slideshow-content').eq(mySlideNumber).addClass('active');

      $('.section-slideshow-v3 .slideshow-content').eq(prev).removeClass('active');
    })
  }

  function slideshowV4() {
    $('.js-slideshow-v4').slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      infinite: true,
      arrows: false,
      dots: true,
      fade: true
    });
    if ($(window).width() > 1199) {
      $('.section-slideshow-v4').on('mousemove',function(event){
        var left = event.clientX;
        var top = event.clientY
        $('.js-effect-v4').each(function(){
          var top1 = $('.js-effect-v4').position().top 
          var left1 = $('.js-effect-v4').position().left 
          $('.js-effect-v4').css("transform",function(){
            var x = -(left-left1)/40
            var y = -(top-top1)/40
            return 'translate('+x+'px,'+y+'px)'
          })
        })
      })
    }

    $(window).resize(function(){
      if ($(window).width() > 1199) {
        $('.section-slideshow-v4').on('mousemove',function(event){
          var left = event.clientX;
          var top = event.clientY
          $('.js-effect-v4').each(function(){
            var top1 = $('.js-effect-v4').position().top 
            var left1 = $('.js-effect-v4').position().left 
            $('.js-effect-v4').css("transform",function(){
              var x = -(left-left1)/40
              var y = -(top-top1)/40
              return 'translate('+x+'px,'+y+'px)'
            })
          })
        })
      } else {
        $('.js-effect-v4').css("transform","none")
      }
    })
    $('.js-slideshow-v4 .slideshow-content').eq(0).addClass('active');

    $('.js-slideshow-v4').on('beforeChange', function (event, slick, currentSlide, nextSlide) {
      var mySlideNumber = nextSlide;
      var prev = mySlideNumber - 2;
      $('.section-slideshow-v4 .slideshow-content').eq(mySlideNumber).addClass('active');

      $('.section-slideshow-v4 .slideshow-content').eq(prev).removeClass('active');
    })
  }
  function slideshowBannerV1() {
    $('.js-slideshow-banner').slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      infinite: true,
      arrows: false,
      autoPlay: true,
      dots: true,
      fade: true
    });

    $('.js-slideshow-banner .slideshow-content').eq(0).addClass('active');

    $('.js-slideshow-banner').on('beforeChange', function (event, slick, currentSlide, nextSlide) {
      var mySlideNumber = nextSlide;
      var prev = mySlideNumber - 2;
      $('.section-slideshow .slideshow-content').eq(mySlideNumber).addClass('active');

      $('.section-slideshow .slideshow-content').eq(prev).removeClass('active');
    })
  }
  function slideshowBannerV2() {
    $('.js-slideshow-banner-v2').slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      infinite: true,
      arrows: false,
      autoPlay: true,
      dots: true,
      fade: true
    });

    $('.js-slideshow-banner-v2 .slideshow-content').eq(0).addClass('active');

    $('.js-slideshow-banner-v2').on('beforeChange', function (event, slick, currentSlide, nextSlide) {
      var mySlideNumber = nextSlide;
      var prev = mySlideNumber - 2;
      $('.js-slideshow-banner-v2 .slideshow-content').eq(mySlideNumber).addClass('active');

      $('.js-slideshow-banner-v2 .slideshow-content').eq(prev).removeClass('active');
    })

    $('.js-slideshow').on('mousemove',function(event){
      var left = event.clientX;
      var top = event.clientY
      $('.js-effect-image-slide').each(function(){
        var top1 = $('.js-effect-image-slide').parent().position().top 
        var left1 = $('.js-effect-image-slide').parent().position().left 
        $('.js-effect-image-slide').css("transform",function(){
          var x = -(left-left1)/40
          var y = -(top-top1)/40
          return 'translate('+x+'px,'+y+'px)'
        })
      })
    })
  }

  function filter() {
    $(".dropdown-menu li a").click(function(){
      $(this).addClass('active')
      $(this).parents(".dropdown").find('.dropdown-toggle').html($(this).text() + ' <i class="fa fa-angle-down"></i>');
      $(this).parents(".dropdown").find('.dropdown-toggle').val($(this).data('value'));
    });
  }

  function fancyBox() {
    $('[data-fancybox="images"]').fancybox({
      thumbs : {
        autoStart : true
      }
    });
  }

  function pinLookbook() {
    $('.js-lookbook').each(function(){
      $(this).on('click',function(){
        var data = parseInt($(this).attr('data-click')) - 1;
        setTimeout(function(){
          $('.js-popup-lookbook').find('.slick-dots').children().eq(data).click()
          $('.js-popup-lookbook').addClass('active');
          $('.js-bg-overlay-popup-lookbook').addClass('active');
        })
      });
    })
    $('.js-close-popup-lookbook').on('click',function() {
      $('.js-popup-lookbook').removeClass('active');
      $('.js-bg-overlay-popup-lookbook').removeClass('active');
    });

    $('.js-bg-overlay-popup-lookbook').on('click',function() {
      $(this).removeClass('active');
      $('.js-popup-lookbook').removeClass('active');
    });
  }

  function popupLookbookItem() {
    $('.js-popup-lb-slide').slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      autoplay: false,
      infinite: true,
      fade: true,
      arrows: true,
      prevArrow: '<div class="slide-arrow slide-prev"><i class="fa fa-angle-left"></i></div>',
      nextArrow: '<div class="slide-arrow slide-next"><i class="fa fa-angle-right"></i></div>',
      dots: true,
      adaptiveHeight: true,
    });
  }

  function popupPointHover() {
    $('.popup-lookbook-item').each(function(){
      $(this).find('.js-hover-lookbook').each(function(){
        if ($(window).width() >= 768) {
          $(this).on('mouseenter',function(){
            var dataHover = parseInt($(this).attr('data-hover'))
            $(this).parent().parent().find('.product_item').addClass('active')
            $(this).parent().parent().find('.product_item').eq(dataHover).removeClass('active')
          })
          $(this).on('mouseleave',function(){
            var dataHover = parseInt($(this).attr('data-hover'))
            $(this).parent().parent().find('.product_item').removeClass('active')
          })
        }
        if ($(window).width() < 768) {
          $(this).on('click',function(){
            var top1 = $(this).parent().height()
            var dataHover = parseInt($(this).attr('data-hover'))
            var top2 = $(this).parent().parent().find('.product_item').eq(dataHover).position().top
            $(this).parent().parent().find('.product_item').addClass('active')
            $(this).parent().parent().find('.product_item').eq(dataHover).removeClass('active')
            $('.content-popup-lookbook').animate({
              scrollTop: top1 + top2 + 'px'
            },300)

          })
        }
      })
      $(this).find('.product_item').each(function(){
        $(this).on('mouseenter',function(){
          var dataHover = parseInt($(this).attr('data-hover'))
          $(this).parent().children().addClass('active')
          $(this).removeClass('active')
          $(this).parentsUntil('.popup-lookbook-item').find('.js-hover-lookbook').eq(dataHover).addClass('active')
        })
        $(this).on('mouseleave',function(){
          $(this).parent().children().removeClass('active')
          $(this).parentsUntil('.popup-lookbook-item').find('.js-hover-lookbook').removeClass('active')
        })
      })
    })
    $(window).on('resize',function(){
      $('.popup-lookbook-item').each(function(){
        $(this).find('.js-hover-lookbook').each(function(){
          if ($(window).width() >= 768) {
            $(this).on('mouseenter',function(){
              var dataHover = parseInt($(this).attr('data-hover'))
              $(this).parent().parent().find('.product_item').addClass('active')
              $(this).parent().parent().find('.product_item').eq(dataHover).removeClass('active')
            })
            $(this).on('mouseleave',function(){
              var dataHover = parseInt($(this).attr('data-hover'))
              $(this).parent().parent().find('.product_item').removeClass('active')
            })
          }
          if ($(window).width() < 768) {
            $(this).on('click',function(){
              var top1 = $(this).parent().height()
              var dataHover = parseInt($(this).attr('data-hover'))
              var top2 = $(this).parent().parent().find('.product_item').eq(dataHover).position().top
              $(this).parent().parent().find('.product_item').addClass('active')
              $(this).parent().parent().find('.product_item').eq(dataHover).removeClass('active')
              $('.content-popup-lookbook').animate({
                scrollTop: top1 + top2 + 'px'
              },300)

            })
          }
        })
        $(this).find('.product_item').each(function(){
          $(this).on('mouseenter',function(){
            var dataHover = parseInt($(this).attr('data-hover'))
            $(this).parent().children().addClass('active')
            $(this).removeClass('active')
            $(this).parentsUntil('.popup-lookbook-item').find('.js-hover-lookbook').eq(dataHover).addClass('active')
          })
          $(this).on('mouseleave',function(){
            $(this).parent().children().removeClass('active')
            $(this).parentsUntil('.popup-lookbook-item').find('.js-hover-lookbook').removeClass('active')
          })
        })
      })
    })
  }

  function instagramPopupMobile() {
    if ($(window).width() < 992 ) {
      if ($(window).width() < 768 ) {
        var align = ($(window).width() - 290)/2;
      } else {
        var align = ($(window).width()/2 - 290)/2;
      }
      $('.js-hover-lookbook').each(function(){
        var top = $(this).position().top;
        var left = -$(this).position().left - 15 + align;
        var height = $(this).parent().height()
        var dk = top/height;
        $(this).find('.product_lookbook').css('left',left)
        if (dk > 0.5 ) {
          $(this).find('.product_lookbook').css('bottom','45px')
        } else {
          $(this).find('.product_lookbook').css('top','45px')
        }
        $(this).on('click',function(){
          if ($(this).find('.product_lookbook').hasClass('active')) {
            $(this).find('.product_lookbook').toggleClass('active')
          } else {
            $('.instagram-shop-content').find('.product_lookbook').removeClass('active')
            $(this).find('.product_lookbook').addClass('active')
          }
        })
      })
    } else {
      $('.instagram-shop-content').find('.product_lookbook').css({'top':'','left':'','bottom':''})
    }
    $(window).resize(function(){
      if ($(window).width() < 992 ) {
        if ($(window).width() < 768 ) {
          var align = ($(window).width() - 290)/2;
        } else {
          var align = ($(window).width()/2 - 290)/2;
        }
        $('.js-hover-lookbook').each(function(){
          var top = $(this).position().top;
          var left = -$(this).position().left - 15 + align;
          var height = $(this).parent().height()
          var dk = top/height;
          $(this).find('.product_lookbook').css('left',left)
          if (dk > 0.5 ) {
            $(this).find('.product_lookbook').css('bottom','45px')
          } else {
            $(this).find('.product_lookbook').css('top','45px')
          }
          $(this).on('click',function(){
            if ($(this).find('.product_lookbook').hasClass('active')) {
              $(this).find('.product_lookbook').toggleClass('active')
            } else {
              $('.instagram-shop-content').find('.product_lookbook').removeClass('active')
              $(this).find('.product_lookbook').addClass('active')
            }
          })
        })
      } else {
        $('.instagram-shop-content').find('.product_lookbook').css({'top':'','left':'','bottom':''})
      }
    })
  }

  function popupSocialShare() {
    $('.js-share').on('click',function(){
      $('.js-share-content').addClass('active');
      $('.js-share-overlay').addClass('active');
    });
    $('.js-share-overlay').on('click',function() {
      $(this).removeClass('active');
      $('.js-share-content').removeClass('active');
    });
  }

  function upsellProduct() {
    $('.js-product-slide').slick({
      autoplay: false,
      slidesToShow: 4,
      slidesToScroll: 2,
      infinite: true,
      arrows: false,
      dots: true,
      responsive: [
        {
          breakpoint: 1500,
          settings: {
            arrows: false,
            slidesToShow: 3,
            slidesToScroll: 1
          }
        },
        {
          breakpoint: 768,
          settings: {
            arrows: false,
            slidesToShow: 2,
            slidesToScroll: 1
          }
        }
      ]
    });
  }
  
  function slideProductDetail() {
    // Js product single slider
    $('.js-click-product').slick({
      slidesToShow: 5,
      slidesToScroll: 1,
      asNavFor: '.js-product-slider',
      dots: false,
      focusOnSelect: true,
      prevArrow: '<span class="fa fa-angle-left slick-prev slick-arrow"></span>',
      nextArrow: '<span class="fa fa-angle-right slick-next slick-arrow"></span>',
      infinite: true,
      arrows: true,
    });
    $('.js-product-slider').slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      infinite: false,
      arrows: false,
      asNavFor: '.js-click-product'
    });
  }

  slideshowV2();
  slideshowV3();
  slideshowV4();
  slideshowBannerV1();
  slideshowBannerV2();
  filter();
  fancyBox();
  popupLookbookItem();
  pinLookbook();
  popupPointHover();
  instagramPopupMobile();
  popupSocialShare();
  upsellProduct();
  slideProductDetail();
});