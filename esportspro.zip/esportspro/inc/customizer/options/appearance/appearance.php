<?php
/**
 * Appearance panel
 */
Kirki::add_panel( 'appearance', array(
	'title'          => esc_attr__( 'Appearance', 'esportspro' ),
	'description'    => esc_attr__( 'Customize the design of the elements of the theme.', 'esportspro' ),
	'priority'       => 135,
) );

/**
 * Global colors section
 */
Kirki::add_section( 'global_color', array(
	'title'          => esc_attr__( 'Global Colors', 'esportspro' ),
	'priority'       => 1,
	'panel'          => 'appearance'
) );

/**
 * Primary color
 */
Kirki::add_field( 'esportspro_options', array(
	'type'        => 'color',
	'settings'    => 'primary_color',
	'label'       => esc_attr__( 'Primary Color', 'esportspro' ),
	'section'     => 'global_color',
	'default'     => '#f4375b',
	'choices'     => array(
		'alpha' => true,
	),
	'output'      => array(
		array(
			'element'  => esportspro_primary_colors( 'colors' ),
			'property' => 'color',
			'exclude'  => array( '#f4375b' )
		),
		array(
			'element'  => esportspro_primary_colors( 'backgrounds' ),
			'property' => 'background-color',
			'exclude'  => array( '#f4375b' )
		),
		array(
			'element'  => esportspro_primary_colors( 'borders' ),
			'property' => 'border-color',
			'exclude'  => array( '#f4375b' )
		),
	),
	'transport'   => 'postMessage',
	'js_vars'     => array(
		array(
			'element'  => esportspro_primary_colors( 'colors' ),
			'property' => 'color',
			'function' => 'css',
		),
		array(
			'element'  => esportspro_primary_colors( 'backgrounds' ),
			'property' => 'background-color',
			'function' => 'css',
		),
		array(
			'element'  => esportspro_primary_colors( 'borders' ),
			'property' => 'border-color',
			'function' => 'css',
		),
	),
) );

/**
 * Text color
 */
Kirki::add_field( 'esportspro_options', array(
	'type'        => 'color',
	'settings'    => 'text_color',
	'label'       => esc_attr__( 'Text Color', 'esportspro' ),
	'section'     => 'global_color',
	'default'     => '#10161F',
	'choices'     => array(
		'alpha' => true,
	),
	'output'      => array(
		array(
			'element'  => 'body',
			'property' => 'color',
			'exclude'  => array( '#10161F' )
		),
	),
	'transport'   => 'postMessage',
	'js_vars'     => array(
		array(
			'element'  => 'body',
			'property' => 'color',
			'function' => 'css',
		),
	),
) );

/**
 * Heading color
 */
Kirki::add_field( 'esportspro_options', array(
	'type'        => 'color',
	'settings'    => 'heading_color',
	'label'       => esc_attr__( 'Heading Color', 'esportspro' ),
	'section'     => 'global_color',
	'default'     => '#10161F',
	'choices'     => array(
		'alpha' => true,
	),
	'output'      => array(
		array(
			'element'  => esportspro_heading_selector(),
			'property' => 'color',
			'exclude'  => array( '#10161F' )
		),
	),
	'transport'   => 'postMessage',
	'js_vars'     => array(
		array(
			'element'  => esportspro_heading_selector(),
			'property' => 'color',
			'function' => 'css',
		),
	),
) );
