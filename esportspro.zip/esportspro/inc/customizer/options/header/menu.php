<?php
/**
 * Menu section
 */
Kirki::add_section( 'menu', array(
	'title'          => esc_attr__( 'Menu', 'esportspro' ),
	'priority'       => 15,
	'panel'          => 'header'
) );

/**
 * Typography
 */
Kirki::add_field( 'esportspro_options', array(
	'type'        => 'typography',
	'settings'    => 'menu_typography',
	'label'       => esc_attr__( 'Typography', 'esportspro' ),
	'section'     => 'menu',
	'default'     => array(
		'font-family'    => 'Roboto',
		'variant'        => '500',
		'font-size'      => '15px',
		'letter-spacing' => '0',
		'text-transform' => 'regular'
	),
	'output'       => array(
		array(
			'element'  => '.menu-primary-items a',
			'suffix'   => '!important'
		),
	),
) );

/**
 * Menu color
 */
Kirki::add_field( 'esportspro_options', array(
	'type'        => 'color',
	'settings'    => 'menu_color',
	'label'       => esc_attr__( 'Color', 'esportspro' ),
	'section'     => 'menu',
	'default'     => '#10161F',
	'choices'     => array(
		'alpha' => true,
	),
	'output'      => array(
		array(
			'element'  => '.menu-primary-items a',
			'property' => 'color',
			'exclude'  => array( '#10161F' ),
			'suffix'   => '!important'
		),
	),
	'transport'   => 'postMessage',
	'js_vars'     => array(
		array(
			'element'  => '.menu-primary-items a',
			'property' => 'color',
			'function' => 'css',
		),
	),
) );

/**
 * Menu color hover
 */
Kirki::add_field( 'esportspro_options', array(
	'type'        => 'color',
	'settings'    => 'menu_color_hover',
	'label'       => esc_attr__( 'Color: Hover', 'esportspro' ),
	'section'     => 'menu',
	'default'     => '#f4375b',
	'choices'     => array(
		'alpha' => true,
	),
	'output'      => array(
		array(
			'element'  => '.menu-primary-items a:hover',
			'property' => 'color',
			'exclude'  => array( '#f4375b' ),
			'suffix'   => '!important'
		),
	),
	'transport'   => 'postMessage',
	'js_vars'     => array(
		array(
			'element'  => '.menu-primary-items a:hover',
			'property' => 'color',
			'function' => 'css',
		),
	),
) );

/**
 * Menu color current menu item
 */
Kirki::add_field( 'esportspro_options', array(
	'type'        => 'color',
	'settings'    => 'menu_color_current',
	'label'       => esc_attr__( 'Color: Current Menu', 'esportspro' ),
	'section'     => 'menu',
	'default'     => '#f4375b',
	'choices'     => array(
		'alpha' => true,
	),
	'output'      => array(
		array(
			'element'  => '.menu-primary-items li.current-menu-item > a',
			'property' => 'color',
			'exclude'  => array( '#f4375b' ),
			'suffix'   => '!important'
		),
	),
	'transport'   => 'postMessage',
	'js_vars'     => array(
		array(
			'element'  => '.menu-primary-items li.current-menu-item > a',
			'property' => 'color',
			'function' => 'css',
		),
	),
) );

/**
 * Spacing
 */
Kirki::add_field( 'esportspro_options', array(
	'type'        => 'slider',
	'settings'    => 'menu_spacing',
	'label'       => esc_attr__( 'Spacing', 'esportspro' ),
	'description' => esc_attr__( 'Distance between menu item.', 'esportspro' ),
	'section'     => 'menu',
	'default'     => '4',
	'choices'     => array(
		'min'  => '1',
		'max'  => '10',
		'step' => '1',
	),
	'output'      => array(
		array(
			'element'  => '.menu-primary-items li',
			'property' => 'margin-right',
			'units'    => 'rem',
			'exclude'  => array( '4' ),
		),
	),
	'transport'   => 'postMessage',
	'js_vars'     => array(
		array(
			'element'  => '.menu-primary-items li',
			'property' => 'margin-right',
			'function' => 'css',
			'units'    => 'rem',
		),
	),
) );

/**
 * Info
 */
Kirki::add_field( 'esportspro_options', array(
	'type'        => 'custom',
	'settings'    => 'submenu',
	'section'     => 'menu',
	'default'     => '<div style="padding: 5px 8px;background-color: #f5f5f5; font-weight: 700; border: 1px solid rgba(0, 0, 0, 0.1);">' . esc_html__( 'Sub menu settings', 'esportspro' ) . '</div>',
	'priority'    => 10,
) );

/**
 * Submenu background color
 */
Kirki::add_field( 'esportspro_options', array(
	'type'        => 'color',
	'settings'    => 'submenu_bg',
	'label'       => esc_attr__( 'Background Color', 'esportspro' ),
	'section'     => 'menu',
	'default'     => '#f9f9f9',
	'choices'     => array(
		'alpha' => true,
	),
	'output'      => array(
		array(
			'element'  => '.menu-primary-items .sub-menu',
			'property' => 'background-color',
			'exclude'  => array( '#f9f9f9' ),
		),
	),
	'transport'   => 'postMessage',
	'js_vars'     => array(
		array(
			'element'  => '.menu-primary-items .sub-menu',
			'property' => 'background-color',
			'function' => 'css',
		),
	),
) );

/**
 * Submenu color
 */
Kirki::add_field( 'esportspro_options', array(
	'type'        => 'color',
	'settings'    => 'submenu_color',
	'label'       => esc_attr__( 'Color', 'esportspro' ),
	'section'     => 'menu',
	'default'     => '#10161F',
	'choices'     => array(
		'alpha' => true,
	),
	'output'      => array(
		array(
			'element'  => '.menu-primary-items .sub-menu a',
			'property' => 'color',
			'exclude'  => array( '#10161F' ),
			'suffix'   => '!important'
		),
	),
	'transport'   => 'postMessage',
	'js_vars'     => array(
		array(
			'element'  => '.menu-primary-items .sub-menu a',
			'property' => 'color',
			'function' => 'css',
		),
	),
) );

/**
 * Submenu color hover
 */
Kirki::add_field( 'esportspro_options', array(
	'type'        => 'color',
	'settings'    => 'submenu_color_hover',
	'label'       => esc_attr__( 'Color: Hover', 'esportspro' ),
	'section'     => 'menu',
	'default'     => '#f4375b',
	'choices'     => array(
		'alpha' => true,
	),
	'output'      => array(
		array(
			'element'  => '.menu-primary-items .sub-menu a:hover',
			'property' => 'color',
			'exclude'  => array( '#f4375b' ),
			'suffix'   => '!important'
		),
		array(
			'element'  => '.menu-primary-items .sub-menu li:hover',
			'property' => 'border-color',
			'exclude'  => array( '#f4375b' ),
			'suffix'   => '!important'
		),
	),
	'transport'   => 'postMessage',
	'js_vars'     => array(
		array(
			'element'  => '.menu-primary-items .sub-menu a:hover',
			'property' => 'color',
			'function' => 'css',
		),
		array(
			'element'  => '.menu-primary-items .sub-menu li:hover',
			'property' => 'border-color'
		),
	),
) );
