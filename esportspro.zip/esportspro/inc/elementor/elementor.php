<?php
/**
 * Elementor compatibility and custom functions
 */

namespace Elementor;

/**
 * Add widgets
 */
function esportspro_elementor_custom_widgets() {

	// Check if plugin is active.
	include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
	if ( is_plugin_active( 'theme-junkie-portfolio-content/tj-portfolio-content.php' ) ) {
		require_once get_template_directory() . '/inc/elementor/widgets/portfolio.php';
	}

}
add_action( 'elementor/widgets/widgets_registered', 'Elementor\esportspro_elementor_custom_widgets' );

/**
 * Custom scripts
 */
function esportspro_elementor_scripts() {
	wp_register_script( 'esportspro-portfolio', trailingslashit( get_template_directory_uri() ) . 'inc/elementor/js/portfolio.js', [ 'jquery', 'masonry' ], false, true );
	wp_register_script( 'esportspro-isotope', trailingslashit( get_template_directory_uri() ) . 'inc/elementor/js/isotope.pkgd.js', [ 'jquery' ], false, true );
}
add_action( 'elementor/frontend/after_register_scripts', 'Elementor\esportspro_elementor_scripts' );
