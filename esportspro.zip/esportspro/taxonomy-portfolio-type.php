<?php get_header(); ?>

	<div class="container">

		<div id="primary" class="content-area">
			<main id="main" class="site-main">

				<?php if ( have_posts() ) : ?>

					<div class="esportspro-portfolio">

						<?php while ( have_posts() ) : the_post(); ?>

							<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

								<div class="esportspro-portfolio-inner">

									<?php if ( has_post_thumbnail() ) { ?>
										<div class="esportspro-portfolio-media">
											<?php esportspro_post_thumbnail( 'esportspro-featured' ); ?>
										</div><!-- .esportspro-portfolio-media -->
									<?php } ?>

									<div class="esportspro-portfolio-details">

										<?php the_title( sprintf( '<h2 class="esportspro-portfolio-title entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>

										<span class="esportspro-portfolio-terms"><?php echo get_the_term_list( get_the_ID(), 'portfolio-type', '', ', ' ) ?></span>

									</div><!-- .esportspro-portfolio-details -->

								</div>

							</article>

						<?php endwhile; ?>

					</div>

				<?php else : ?>

					<?php get_template_part( 'partials/content/content', 'none' ); ?>

				<?php endif; ?>

			</main><!-- #main -->
		</div><!-- #primary -->

	</div><!-- .container -->

<?php get_footer(); ?>
