<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<div class="portfolio-inner">

		<div class="portfolio-details">

			<?php the_title( '<h1 class="portfolio-title">', '</h1>' ); ?>

			<?php
				$short_desc = get_post_meta( $post->ID, 'tj_portfolio_short_desc', true );
				if ( $short_desc ) :
			?>
				<div class="portfolio-short-desc"><?php echo esc_html( $short_desc ); ?></div>
			<?php endif; ?>

			<div class="portfolio-content">

				<?php the_content(); ?>
				<?php
					wp_link_pages( array(
						'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'esportspro' ),
						'after'  => '</div>',
					) );
				?>

			</div>

			<?php
				$client = get_post_meta( $post->ID, 'tj_portfolio_client', true );
				if ( $client ) :
			?>
				<div class="portfolio-client portfolio-detail">
					<span class="info"><?php esc_html_e( 'Client Name:', 'esportspro' ) ?></span>
					<span class="detail"><?php echo esc_html( $client ); ?></span>
				</div>
			<?php endif; ?>

			<?php
				$link = get_post_meta( $post->ID, 'tj_portfolio_link', true );
				if ( $link ) :
			?>
				<div class="portfolio-link portfolio-detail">
					<span class="info"><?php esc_html_e( 'URL:', 'esportspro' ) ?></span>
					<span class="detail"><a href="<?php echo esc_url( $link ); ?>" rel="nofollow"><?php echo esc_url( $link ); ?></a></span>
				</div>
			<?php endif; ?>

		</div>

		<div class="portfolio-gallery">

			<ul>
				<?php
					$ids = get_post_meta( $post->ID, 'tj_image_ids', true );
					$ids = array_filter( explode( ',', $ids ) );
					if ( $ids ) :
				?>
					<?php foreach ( $ids as $id ) : ?>
						<li>
							<?php echo wp_get_attachment_image( $id, 'esportspro-featured' ); ?>
						</li>
					<?php endforeach; ?>
				<?php endif; ?>
			</ul>

		</div>

	</div>

</article><!-- #post-## -->
