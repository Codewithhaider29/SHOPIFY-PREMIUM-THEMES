<?php
// Return early if no widget found.
if ( ! is_active_sidebar( 'header' ) ) {
	return;
}
?>
<div class="header-widget">
	<?php dynamic_sidebar( 'header' ); ?>
</div>