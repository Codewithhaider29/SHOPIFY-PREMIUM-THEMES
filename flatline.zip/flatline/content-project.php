<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> <?php hybrid_attr( 'post' ); ?>>
	
	<?php flatline_post_thumbnail(); ?>

	<header class="entry-header">
		<time class="entry-date published" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>" <?php hybrid_attr( 'entry-published' ); ?>><?php echo esc_html( get_the_date() )?></time>
		<?php the_title( '<h1 class="entry-title" ' . hybrid_get_attr( 'entry-title' ) . '>', '</h1>' ); ?>
	</header><!-- .entry-header -->

	<div class="entry-content" <?php hybrid_attr( 'entry-content' ); ?>>
		<?php the_content(); ?>
		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'flatline' ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->

	<footer class="entry-footer">

		<?php
			$type = get_the_term_list( $post->ID, 'jetpack-portfolio-type', '<span class="genericon genericon-document"></span>', ', ' );
			if ( ! empty( $type ) && ! is_wp_error( $type ) ) :
		?>
			<span class="cat-links" <?php hybrid_attr( 'entry-terms', 'category' ); ?>>
				<?php echo $type; ?>
			</span>
		<?php endif; // End if categories ?>

		<?php
			$tags = get_the_term_list( $post->ID, 'jetpack-portfolio-tag', '<span class="genericon genericon-tag"></span>', ', ' );
			if ( ! empty( $tags ) && ! is_wp_error( $tags ) ) : 
		?>
			<span class="tag-links" <?php hybrid_attr( 'entry-terms', 'post_tag' ); ?>>
				<?php echo $tags; ?>
			</span>
		<?php endif; ?>

		<?php if ( ! post_password_required() && ( comments_open() || '0' != get_comments_number() ) ) : ?>
			<span class="entry-comment"><span class="genericon genericon-comment"></span> <?php comments_popup_link( __( '0 Comment', 'flatline' ), __( '1 Comment', 'flatline' ), __( '% Comments', 'flatline' ) ); ?></span>
		<?php endif; ?>

		<?php edit_post_link( __( 'Edit', 'flatline' ), '<span class="edit-link"><span class="genericon genericon-edit"></span> ', '</span>' ); ?>

	</footer><!-- .entry-footer -->
	
</article><!-- #post-## -->
