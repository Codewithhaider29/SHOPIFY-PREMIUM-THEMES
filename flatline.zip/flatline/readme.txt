= Credit =
- FlatLine is based off Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc.
- Hybrid folder is based off Hybrid Core part http://themehybrid.com/hybrid-core, (C) 2010-2015 Justin Tadlock.

= Useful Links = 
- Documentation: http://docs.theme-junkie.com/flatline
- Support      : http://www.theme-junkie.com/support
- Twitter      : https://twitter.com/theme_junkie