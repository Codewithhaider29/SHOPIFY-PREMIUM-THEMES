<?php
/**
 * Call to action widget.
 *
 * @package    FlatLine
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2015, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */
class FlatLine_Call_Action_Widget extends WP_Widget {

	/**
	 * Sets up the widgets.
	 *
	 * @since 1.0.0
	 */
	function __construct() {

		// Set up the widget options.
		$widget_options = array(
			'classname'   => 'widget-flatline-call-action call-action-widget',
			'description' => __( 'Display call to action block on front page.', 'flatline' )
		);

		// Create the widget.
		parent::__construct(
			'flatline-call-action',                         // $this->id_base
			__( 'Front Page: Call To Action', 'flatline' ), // $this->name
			$widget_options                                 // $this->widget_options
		);
	}

	/**
	 * Outputs the widget based on the arguments input through the widget controls.
	 *
	 * @since 1.0.0
	 */
	function widget( $args, $instance ) {
		extract( $args );

		// Output the theme's $before_widget wrapper.
		echo $before_widget;

			// Open wrapper.
			echo '<div class="call-to-action">';

				echo '<div class="cta-text-content">';

					// Main text.
					if ( $instance['text'] ) {
						echo '<h3>' . esc_html( $instance['text'] ) . '</h3>';
					}

					// Additional text.
					if ( $instance['desc'] ) {
						echo '<p>' . esc_html( $instance['desc'] ) . '</p>';
					}

				echo '</div>';

				if ( $instance['btn_text'] ) {
					echo '<a class="cta-action-btn" href="' . esc_url( $instance['btn_url'] ) . '">' . esc_html( $instance['btn_text'] ) . '</a>';
				}

			// Close wrapper.
			echo '</div>';

		// Close the theme's widget wrapper.
		echo $after_widget;

	}

	/**
	 * Updates the widget control options for the particular instance of the widget.
	 *
	 * @since 1.0.0
	 */
	function update( $new_instance, $old_instance ) {

		$instance = $new_instance;

		$instance['text']     = stripslashes( $new_instance['text'] );
		$instance['desc']     = stripslashes( $new_instance['desc'] );
		$instance['btn_text'] = strip_tags( $new_instance['btn_text'] );
		$instance['btn_url']  = esc_url_raw( $new_instance['btn_url'] );

		return $instance;
	}

	/**
	 * Displays the widget control options in the Widgets admin screen.
	 *
	 * @since 1.0.0
	 */
	function form( $instance ) {

		// Default value.
		$defaults = array(
			'text'     => '',
			'desc'     => '',
			'btn_text' => '',
			'btn_url'  => '',
		);

		$instance = wp_parse_args( (array) $instance, $defaults );
	?>

		<p>
			<label for="<?php echo $this->get_field_id( 'text' ); ?>">
				<?php _e( 'Main Text', 'flatline' ); ?>
			</label>
			<textarea class="widefat" name="<?php echo $this->get_field_name( 'text' ); ?>" id="<?php echo $this->get_field_id( 'text' ); ?>" cols="30" rows="6"><?php echo stripslashes( $instance['text'] ); ?></textarea>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'desc' ); ?>">
				<?php _e( 'Additional Text', 'flatline' ); ?>
			</label>
			<textarea class="widefat" name="<?php echo $this->get_field_name( 'desc' ); ?>" id="<?php echo $this->get_field_id( 'desc' ); ?>" cols="30" rows="6"><?php echo stripslashes( $instance['desc'] ); ?></textarea>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'btn_text' ); ?>">
				<?php _e( 'Button Text', 'flatline' ); ?>
			</label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'btn_text' ); ?>" name="<?php echo $this->get_field_name( 'btn_text' ); ?>" value="<?php echo esc_attr( $instance['btn_text'] ); ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'btn_url' ); ?>">
				<?php _e( 'Button URL', 'flatline' ); ?>
			</label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'btn_url' ); ?>" name="<?php echo $this->get_field_name( 'btn_url' ); ?>" value="<?php echo esc_url( $instance['btn_url'] ); ?>" />
		</p>

	<?php

	}

}