<?php
/**
 * Testimonials widget.
 *
 * @package    FlatLine
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2015, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */
class FlatLine_Testimonials_Widget extends WP_Widget {

	/**
	 * Sets up the widgets.
	 *
	 * @since 1.0.0
	 */
	function __construct() {

		// Set up the widget options.
		$widget_options = array(
			'classname'   => 'widget-flatline-testimonials testimonials-widget',
			'description' => __( 'Display testimonials on front page.', 'flatline' )
		);

		// Create the widget.
		parent::__construct(
			'flatline-testimonials',                      // $this->id_base
			__( 'Front Page: Testimonials', 'flatline' ), // $this->name
			$widget_options                               // $this->widget_options
		);
	}

	/**
	 * Outputs the widget based on the arguments input through the widget controls.
	 *
	 * @since 1.0.0
	 */
	function widget( $args, $instance ) {
		extract( $args );

		// Output the theme's $before_widget wrapper.
		echo $before_widget;

			echo '<div class="testimonial-header">';

				// If the title not empty, display it.
				if ( $instance['title'] ) {
					echo $before_title . apply_filters( 'widget_title', $instance['title'], $instance, $this->id_base ) . $after_title;
				}

				echo '<a class="more-testimonial" href="' . esc_url( get_home_url( '', 'testimonial' ) ) . '">' . __( 'See All Testimonial', 'flatline' ) . '</a>';

			echo '</div>';

			global $post;

			$testimonials = new WP_Query( array(
				'post_type'      => 'jetpack-testimonial',
				'order'          => 'ASC',
				'orderby'        => 'menu_order',
				'posts_per_page' => $instance['num'],
				'no_found_rows'  => true,
			) );

			if ( $testimonials->have_posts() ) :

				echo '<div class="testimonials">';

					while ( $testimonials->have_posts() ) : $testimonials->the_post();

						echo '<article id="post-' . get_the_id() . '" class="' . implode( ' ', get_post_class( '', $post->ID ) ) . '">';
							if ( has_post_thumbnail() ) :
								echo get_the_post_thumbnail( $post->ID, 'flatline-testimonial-widget', array( 'class' => 'testimonial-thumbnail', 'alt' => esc_attr( get_the_title() ) ) );
							endif;
							echo '<div class="testimonial-content">' . esc_html( get_the_content() ) . '</div>';
							echo '<h3 class="testimonial-author">' . esc_attr( get_the_title() ) . '</h3>';
						echo '</article>';

					endwhile;

				echo '</div>';

			endif;

 			// Reset post data.
 			wp_reset_postdata();

		// Close the theme's widget wrapper.
		echo $after_widget;

	}

	/**
	 * Updates the widget control options for the particular instance of the widget.
	 *
	 * @since 1.0.0
	 */
	function update( $new_instance, $old_instance ) {

		$instance = $new_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['num']   = absint( $new_instance['num'] );

		return $instance;
	}

	/**
	 * Displays the widget control options in the Widgets admin screen.
	 *
	 * @since 1.0.0
	 */
	function form( $instance ) {

		// Default value.
		$defaults = array(
			'title' => esc_html__( 'Testimonials', 'flatline' ),
			'num'   => 2,
		);

		$instance = wp_parse_args( (array) $instance, $defaults );
	?>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>">
				<?php _e( 'Title', 'flatline' ); ?>
			</label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo esc_attr( $instance['title'] ); ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'num' ); ?>">
				<?php _e( 'Number of testimonials to show', 'flatline' ); ?>
			</label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'num' ); ?>" name="<?php echo $this->get_field_name( 'num' ); ?>" type="number" step="1" min="0" value="<?php echo (int)( $instance['num'] ); ?>" />
		</p>

		<p><em>Please note, to display testimonials you need to install Jetpack plugin.</em></p>

	<?php

	}

}