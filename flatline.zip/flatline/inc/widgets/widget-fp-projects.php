<?php
/**
 * Projects widget.
 *
 * @package    FlatLine
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2015, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */
class FlatLine_Projects_Widget extends WP_Widget {

	/**
	 * Sets up the widgets.
	 *
	 * @since 1.0.0
	 */
	function __construct() {

		// Set up the widget options.
		$widget_options = array(
			'classname'   => 'widget-flatline-projects projects-widget',
			'description' => __( 'Display recent projects on front page.', 'flatline' )
		);

		// Create the widget.
		parent::__construct(
			'flatline-projects',                      // $this->id_base
			__( 'Front Page: Projects', 'flatline' ), // $this->name
			$widget_options                           // $this->widget_options
		);
	}

	/**
	 * Outputs the widget based on the arguments input through the widget controls.
	 *
	 * @since 1.0.0
	 */
	function widget( $args, $instance ) {
		extract( $args );

		// Output the theme's $before_widget wrapper.
		echo $before_widget;

			echo '<div class="projects-text">';

				// If the title not empty, display it.
				if ( $instance['title'] ) {
					echo $before_title . apply_filters( 'widget_title', $instance['title'], $instance, $this->id_base ) . $after_title;
				}

				if ( $instance['desc'] ) {
					echo '<p>' . stripslashes( $instance['desc'] ) . '</p>';
				}

				echo '<a class="more-projects" href="' . esc_url( get_home_url( '', 'portfolio' ) ) . '">' . __( 'See All Projects', 'flatline' ) . '</a>';

			echo '</div>';

			global $post;

			$projects = new WP_Query( array(
				'post_type'      => 'jetpack-portfolio',
				'order'          => 'ASC',
				'orderby'        => 'menu_order',
				'posts_per_page' => 3,
				'no_found_rows'  => true,
			) );

			if ( $projects->have_posts() ) :

				echo '<div class="projects">';

					while ( $projects->have_posts() ) : $projects->the_post();

						echo '<article id="post-' . get_the_id() . '" class="' . implode( ' ', get_post_class( '', $post->ID ) ) . '">';
							echo '<a href="' . esc_url( get_permalink() ) . '">';
								if ( has_post_thumbnail() ) :
									echo get_the_post_thumbnail( $post->ID, 'flatline-featured', array( 'class' => 'project-thumbnail', 'alt' => esc_attr( get_the_title() ) ) );
								endif;
								echo '<h3 class="project-title">' . esc_attr( get_the_title() ) . '</h3>';
							echo '</a>';
						echo '</article>';

					endwhile;

				echo '</div>';

			endif;

 			// Reset post data.
 			wp_reset_postdata();

		// Close the theme's widget wrapper.
		echo $after_widget;

	}

	/**
	 * Updates the widget control options for the particular instance of the widget.
	 *
	 * @since 1.0.0
	 */
	function update( $new_instance, $old_instance ) {

		$instance = $new_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['desc']  = stripslashes( $new_instance['desc'] );

		return $instance;
	}

	/**
	 * Displays the widget control options in the Widgets admin screen.
	 *
	 * @since 1.0.0
	 */
	function form( $instance ) {

		// Default value.
		$defaults = array(
			'title' => esc_html__( 'Recent Projects', 'flatline' ),
			'desc'  => ''
		);

		$instance = wp_parse_args( (array) $instance, $defaults );
	?>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>">
				<?php _e( 'Title', 'flatline' ); ?>
			</label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo esc_attr( $instance['title'] ); ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'desc' ); ?>">
				<?php _e( 'Description', 'flatline' ); ?>
			</label>
			<textarea class="widefat" name="<?php echo $this->get_field_name( 'desc' ); ?>" id="<?php echo $this->get_field_id( 'desc' ); ?>" cols="30" rows="6"><?php echo stripslashes( $instance['desc'] ); ?></textarea>
		</p>

		<p><em>Please note, to display projects you need to install Jetpack plugin.</em></p>

	<?php

	}

}