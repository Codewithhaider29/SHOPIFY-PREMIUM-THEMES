<?php
/**
 * Featured pages widget.
 *
 * Adapt from Spacious theme.
 *
 * @package    FlatLine
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2015, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */
class FlatLine_Featured_Pages_Widget extends WP_Widget {

	/**
	 * Sets up the widgets.
	 *
	 * @since 1.0.0
	 */
	function __construct() {

		// Set up the widget options.
		$widget_options = array(
			'classname'   => 'widget-flatline-featured-pages featured-pages-widget',
			'description' => __( 'Display some pages as services on front page.', 'flatline' )
		);

		// Create the widget.
		parent::__construct(
			'flatline-featured-pages',                     // $this->id_base
			__( 'Front Page: Featured Page', 'flatline' ), // $this->name
			$widget_options                                // $this->widget_options
		);
	}

	/**
	 * Outputs the widget based on the arguments input through the widget controls.
	 *
	 * @since 1.0.0
	 */
	function widget( $args, $instance ) {
		extract( $args );

		// Output the theme's $before_widget wrapper.
		echo $before_widget;

			// Page query.
			global $post;

			$page_array = array();
			for( $i=0; $i<3; $i++ ) {
				$var = 'page_id'.$i;
				$page_id = isset( $instance[$var] ) ? $instance[$var] : '';
				
				if ( ! empty( $page_id ) ) {
					array_push( $page_array, $page_id ); // Push the page id in the array
				}
			}

			$get_featured_pages = new WP_Query( array(
				'posts_per_page' => 3,
				'post_type'      => array( 'page' ),
				'post__in'       => $page_array,
				'orderby'        => 'post__in'
			) );

			if ( $get_featured_pages->have_posts() ) :

				echo '<div class="featured-pages">';

	 			while ( $get_featured_pages->have_posts() ) : $get_featured_pages->the_post();

	 				echo '<div class="featured-page">';
	 					echo $before_title . esc_attr( get_the_title() ) . $after_title;
	 					if ( has_post_thumbnail() ) {
	 						echo '<a href="' . esc_url( get_permalink() ) . '">' . get_the_post_thumbnail( $post->ID, 'flatline-featured-widget', array( 'class' => 'entry-thumbnail', 'alt' => esc_attr( get_the_title() ) ) ) . '</a>';
	 					}
	 					echo '<p>' . esc_html( get_the_excerpt() ) . '</p>';
	 					echo '<a class="more-link" href="' . esc_url( get_permalink() ) . '">' . __( 'Read More &raquo;', 'flatline' ) . '</a>';
	 				echo '</div>';

	 			endwhile;

	 			echo '</div>';

 			endif;

 			// Reset post data.
 			wp_reset_postdata();

		// Close the theme's widget wrapper.
		echo $after_widget;

	}

	/**
	 * Updates the widget control options for the particular instance of the widget.
	 *
	 * @since 1.0.0
	 */
	function update( $new_instance, $old_instance ) {

		$instance = $new_instance;

		for ( $i=0; $i<3; $i++ ) {
			$var = 'page_id'.$i;
			$instance[$var] = absint( $new_instance[$var] );
		}

		return $instance;
	}

	/**
	 * Displays the widget control options in the Widgets admin screen.
	 *
	 * @since 1.0.0
	 */
	function form( $instance ) {

		// Default value.
		for ( $i=0; $i<3; $i++ ) {
			$var = 'page_id'.$i;
			$defaults[$var] = '';
		}

		$instance = wp_parse_args( (array) $instance, $defaults );

		for ( $i=0; $i<3; $i++ ) {
			$var = 'page_id'.$i;
			$var = absint( $instance[ $var ] );
		}
	?>

		<?php for( $i=0; $i<3; $i++) { ?>
			<p>
				<label for="<?php echo $this->get_field_id( key( $defaults ) ); ?>">
					<?php _e( 'Page', 'flatline' ); ?>
				</label>
				<?php wp_dropdown_pages( array( 'show_option_none' => __( 'Select a page', 'flatline' ), 'name' => $this->get_field_name( key( $defaults ) ), 'selected' => $instance[key( $defaults )] ) ); ?>
			</p>
		<?php
		next( $defaults );// forwards the key of $defaults array
		}

	}

}