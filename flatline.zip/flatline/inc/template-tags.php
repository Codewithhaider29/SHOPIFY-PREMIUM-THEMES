<?php
/**
 * Custom template tags for this theme.
 * Eventually, some of the functionality here could be replaced by core features.
 * 
 * @package    FlatLine
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2015, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */

/**
 * Returns true if a blog has more than 1 category.
 *
 * @since  1.0.0
 * @return bool
 */
function flatline_categorized_blog() {
	if ( false === ( $all_the_cool_cats = get_transient( 'flatline_categories' ) ) ) {
		// Create an array of all the categories that are attached to posts.
		$all_the_cool_cats = get_categories( array(
			'fields'     => 'ids',
			'hide_empty' => 1,

			// We only need to know if there is more than one category.
			'number'     => 2,
		) );

		// Count the number of categories that are attached to the posts.
		$all_the_cool_cats = count( $all_the_cool_cats );

		set_transient( 'flatline_categories', $all_the_cool_cats );
	}

	if ( $all_the_cool_cats > 1 ) {
		// This blog has more than 1 category so flatline_categorized_blog should return true.
		return true;
	} else {
		// This blog has only 1 category so flatline_categorized_blog should return false.
		return false;
	}
}

/**
 * Flush out the transients used in flatline_categorized_blog.
 *
 * @since 1.0.0
 */
function flatline_category_transient_flusher() {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	// Like, beat it. Dig?
	delete_transient( 'flatline_categories' );
}
add_action( 'edit_category', 'flatline_category_transient_flusher' );
add_action( 'save_post',     'flatline_category_transient_flusher' );

if ( ! function_exists( 'flatline_site_branding' ) ) :
	/**
	 * Site branding for the site.
	 * 
	 * Display site title by default, but user can change it with their custom logo.
	 * 
	 * @since  1.0.0
	 */
	function flatline_site_branding() {

		// Check if logo available, then display it.
		if ( of_get_option( 'flatline_logo' ) ) :
			echo '<div id="logo" itemscope itemtype="http://schema.org/Brand">' . "\n";
				echo '<a href="' . esc_url( get_home_url() ) . '" itemprop="url" rel="home">' . "\n";
					echo '<img itemprop="logo" src="' . esc_url( of_get_option( 'flatline_logo' ) ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '" />' . "\n";
				echo '</a>' . "\n";
			echo '</div>' . "\n";

		// If not, then display the Site Title and Site Description.
		else :
			echo '<div id="logo">'. "\n";
				echo '<h1 class="site-title" ' . hybrid_get_attr( 'site-title' ) . '><a href="' . esc_url( get_home_url() ) . '" itemprop="url" rel="home"><span itemprop="headline">' . esc_attr( get_bloginfo( 'name' ) ) . '</span></a></h1>'. "\n";
				if ( of_get_option( 'flatline_site_desc', 'on' ) == 'on' ) :
					echo '<h2 class="site-description" ' . hybrid_get_attr( 'site-description' ) . '>' . esc_attr( get_bloginfo( 'description' ) ) . '</h2>';
				endif;
			echo '</div>'. "\n";
		endif;

	}
endif;

if ( ! function_exists( 'flatline_post_thumbnail' ) ) :
	/**
	 * Custom post thumbnail size.
	 * 
	 * @since  1.0.0
	 */
	function flatline_post_thumbnail() {

		$size = 'flatline-featured';

		if ( in_array( get_theme_mod( 'theme_layout' ), array( '1c' ) ) ) {
			$size = 'flatline-featured-big';
		}

		if ( has_post_thumbnail() ) {
			?>
			<a class="img-link" href="<?php the_permalink(); ?>">
				<?php the_post_thumbnail( $size, array( 'class' => 'entry-thumbnail', 'alt' => esc_attr( get_the_title() ) ) ); ?>
			</a>
			<?php
		}

	}
endif;

if ( ! function_exists( 'flatline_post_author' ) ) :
	/**
	 * Author post informations.
	 *
	 * @since  1.0.0
	 */
	function flatline_post_author() {

		// Bail if user don't want to display the author info via theme settings.
		if ( of_get_option( 'flatline_post_author', 'on' ) != 'on' ) {
			return;
		}

		// Bail if not on the single post.
		if ( ! is_singular( 'post' ) ) {
			return;
		}

		// Bail if user hasn't fill the Biographical Info field.
		if ( ! get_the_author_meta( 'description' ) ) {
			return;
		}

		// Get the author social information.
		$url      = get_the_author_meta( 'url' );
		$twitter  = get_the_author_meta( 'twitter' );
		$facebook = get_the_author_meta( 'facebook' );
		$gplus    = get_the_author_meta( 'gplus' );
		$linkedin = get_the_author_meta( 'linkedin' );
	?>

		<div class="author-bio-title">
			<?php _e( 'Post Author', 'flatline' ); ?>
		</div>

		<div class="author-bio clearfix" <?php hybrid_attr( 'entry-author' ) ?>>

			<?php echo get_avatar( is_email( get_the_author_meta( 'user_email' ) ), apply_filters( 'flatline_author_bio_avatar_size', 80 ), '', strip_tags( get_the_author() ) ); ?>

			<div class="description">
				<h3 class="author-title name">
					<a class="author-name url fn n" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" rel="author" itemprop="url"><span itemprop="name"><?php echo strip_tags( get_the_author() ); ?></span></a>
				</h3>
				<p class="bio" itemprop="description"><?php echo stripslashes( get_the_author_meta( 'description' ) ); ?></p>
			</div>
			
			<ul class="social-profiles">
				<?php if ( $url ) { ?>
					<li><a href="<?php echo esc_url( $url ); ?>" title="<?php esc_attr_e( 'Author Website', 'flatline' ); ?>"><span class="genericon genericon-wordpress"></span></a></li>
				<?php } ?>
				<?php if ( $twitter ) { ?>
					<li><a href="<?php echo esc_url( $twitter ); ?>" title="Twitter"><span class="genericon genericon-twitter"></span></a></li>
				<?php } ?>
				<?php if ( $facebook ) { ?>
					<li><a href="<?php echo esc_url( $facebook ); ?>" title="Facebook"><span class="genericon genericon-facebook"></span></a></li>
				<?php } ?>
				<?php if ( $gplus ) { ?>
					<li><a href="<?php echo esc_url( $gplus ); ?>" title="Google Plus"><span class="genericon genericon-googleplus"></span></a></li>
				<?php } ?>
				<?php if ( $linkedin ) { ?>
					<li><a href="<?php echo esc_url( $linkedin ); ?>" title="LinkedIn"><span class="genericon genericon-linkedin-alt"></span></a></li>
				<?php } ?>
			</ul>

		</div><!-- .author-bio -->

	<?php
	}
endif;

if ( ! function_exists( 'flatline_get_format_gallery' ) ) :
	/**
	 * Get the [gallery] shortcode from the post content and display it on index page. It require
	 * gallery ids [gallery ids=1,2,3,4] to display it as thumbnail slideshow. If no ids exist it
	 * just display it as standard [gallery] markup.
	 *
	 * If no [gallery] shortcode found in the post content, get the attached images to the post and 
	 * display it as slideshow.
	 * 
	 * @since  1.0.0
	 * @uses   get_post_gallery() to get the gallery in the post content.
	 * @uses   wp_get_attachment_image() to get the HTML image.
	 * @uses   get_children() to get the attached images if no [gallery] found in the post content.
	 * @return string
	 */
	function flatline_get_format_gallery() {
		global $post;

		// Set up a default, empty $html variable.
		$html = '';

		// Set up default image size.
		$size = 'flatline-featured';

		// Change the image size if using full-width layout.
		if ( in_array( get_theme_mod( 'theme_layout' ), array( '1c' ) ) ) {
			$size = 'flatline-featured-big';
		}

		// Check the [gallery] shortcode in post content.
		$gallery = get_post_gallery( $post->ID, false );

		// Check if the [gallery] exist.
		if ( $gallery ) {

			// Check if the gallery ids exist.
			if ( isset( $gallery['ids'] ) ) {

				// Get the gallery ids and convert it into array.
				$ids = explode( ',', $gallery['ids'] );

				// Display the gallery in a cool slideshow on index page.
				$html = '<div id="carousel-0" class="jcarousel">';
					$html .= '<ul>';
						foreach( $ids as $id ) {
							$html .= '<li>';
							$html .= wp_get_attachment_image( $id, $size, false, array( 'class' => 'entry-thumbnail' ) );
							$html .= '</li>';
						}
					$html .= '</ul>';

			} else {

				// If gallery ids not exist, display the standard gallery markup.
				$html = get_post_gallery( $post->ID );

			}

		// If no [gallery] in post content, get attached images to the post.
		} else {

			// Set up default arguments.
			$defaults = array( 
				'order'          => 'ASC',
				'post_type'      => 'attachment',
				'post_parent'    => $post->ID,
				'post_mime_type' => 'image',
				'numberposts'    => -1
			);

			// Retrieves attachments from the post.
			$attachments = get_children( apply_filters( 'flatline_gallery_format_args', $defaults ) );

			// Check if attachments exist.
			if ( $attachments ) {

				// Display the attachment images in a cool slideshow on index page.
				$html = '<div id="carousel-0" class="jcarousel">';
					$html .= '<ul>';
						foreach ( $attachments as $attachment ) {
							$html .= '<li>';
							$html .= wp_get_attachment_image( $attachment->ID, $size, false, array( 'class' => 'entry-thumbnail' ) );
							$html .= '</li>';
						}
					$html .= '</ul>';

			}

		}

		$html .= '<a href="#" class="jcarousel-control-prev"><span class="genericon genericon-leftarrow"></span></a>';
		$html .= '<a href="#" class="jcarousel-control-next"><span class="genericon genericon-rightarrow"></span></a>';
		$html .= '</div>';

		// Return the gallery images.
		return $html;

	}
endif;

if ( ! function_exists( 'flatline_related_posts' ) ) :
	/**
	 * Related posts.
	 *
	 * @since  1.0.0
	 */
	function flatline_related_posts() {
		global $post;

		// Bail if user don't want to display the related posts via theme settings.
		if ( of_get_option( 'flatline_related_posts', 'on' ) != 'on' ) {
			return;
		}

		// Get the taxonomy terms of the current page for the specified taxonomy.
		$terms = wp_get_post_terms( $post->ID, 'category', array( 'fields' => 'ids' ) );

		// Bail if the term empty.
		if ( empty( $terms ) ) {
			return;
		}
		
		// Posts query arguments.
		$query = array(
			'post__not_in' => array( $post->ID ),
			'tax_query'    => array(
				array(
					'taxonomy' => 'category',
					'field'    => 'id',
					'terms'    => $terms,
					'operator' => 'IN'
				)
			),
			'posts_per_page' => 4,
			'post_type'      => 'post',
		);

		// Allow dev to filter the query.
		$args = apply_filters( 'flatline_related_posts_args', $query );

		// The post query
		$related = new WP_Query( $args );

		if ( $related->have_posts() ) : ?>

			<div class="related-posts">
				<h3><?php _e( 'You might also like:', 'flatline' ); ?></h3>
				<ul class="clearfix">
					<?php while ( $related->have_posts() ) : $related->the_post(); ?>
						<li>
							<a href="<?php the_permalink(); ?>">
								<?php if ( of_get_option( 'flatline_related_posts_thumbnail', 'on' ) == 'on' && has_post_thumbnail() ) : ?>
									<?php the_post_thumbnail( 'flatline-related', array( 'alt' => esc_attr( get_the_title() ) ) ); ?>
								<?php endif; ?>
								<?php the_title( '<h2 class="entry-title">', '</h2>' ); ?>
								<?php if ( of_get_option( 'flatline_related_posts_date', 'on' ) == 'on' ) : ?>
									<time class="entry-date published" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() )?></time>
								<?php endif; ?>
							</a>
						</li>
					<?php endwhile; ?>
				</ul>
			</div>
		
		<?php endif;

		// Restore original Post Data.
		wp_reset_postdata();

	}
endif;

if ( ! function_exists( 'flatline_comment' ) ) :
	/**
	 * Template for comments and pingbacks.
	 *
	 * Used as a callback by wp_list_comments() for displaying the comments.
	 *
	 * @since  1.0.0
	 */
	function flatline_comment( $comment, $args, $depth ) {
		$GLOBALS['comment'] = $comment;
		switch ( $comment->comment_type ) :
			case 'pingback' :
			case 'trackback' :
			// Display trackbacks differently than normal comments.
		?>
		<li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>" <?php hybrid_attr( 'comment' ); ?>>
			<article id="comment-<?php comment_ID(); ?>" class="comment-container">
				<p <?php hybrid_attr( 'comment-content' ); ?>><?php _e( 'Pingback:', 'flatline' ); ?> <span <?php hybrid_attr( 'comment-author' ); ?>><span itemprop="name"><?php comment_author_link(); ?></span></span> <?php edit_comment_link( __( '(Edit)', 'flatline' ), '<span class="edit-link">', '</span>' ); ?></p>
			</article>
		<?php
				break;
			default :
			// Proceed with normal comments.
			global $post;
		?>
		<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>" <?php hybrid_attr( 'comment' ); ?>>
			<article id="comment-<?php comment_ID(); ?>" class="comment-container">

				<?php echo get_avatar( $comment, apply_filters( 'flatline_comment_avatar_size', 52 ) ); ?>

				<div class="comment-head">
					<span class="name" <?php hybrid_attr( 'comment-author' ); ?>><span itemprop="name"><?php echo get_comment_author_link(); ?></span></span>
					<?php
						printf( '<span class="date"><a href="%1$s" ' . hybrid_get_attr( 'comment-permalink' ) . '><time datetime="%2$s" ' . hybrid_get_attr( 'comment-published' ) . '>%3$s</time></a> %4$s</span>',
							esc_url( get_comment_link( $comment->comment_ID ) ),
							get_comment_time( 'c' ),
							/* translators: 1: date, 2: time */
							sprintf( __( '%1$s at %2$s', 'flatline' ), get_comment_date(), get_comment_time() ),
							sprintf( __( '%1$s&middot; Edit%2$s', 'flatline' ), '<a href="' . get_edit_comment_link() . '" title="' . esc_attr__( 'Edit Comment', 'flatline' ) . '">', '</a>' )
						);
					?>
				</div><!-- comment-head -->
				
				<div class="comment-content comment-entry comment" <?php hybrid_attr( 'comment-content' ); ?>>
					<?php if ( '0' == $comment->comment_approved ) : ?>
						<p class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.', 'flatline' ); ?></p>
					<?php endif; ?>
					<?php comment_text(); ?>
					<span class="reply">
						<?php comment_reply_link( array_merge( $args, array( 'reply_text' => __( 'Reply', 'flatline' ), 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
					</span><!-- .reply -->
				</div><!-- .comment-content -->

			</article><!-- #comment-## -->
		<?php
			break;
		endswitch; // end comment_type check
	}
endif;