<?php
/**
 * Enqueue scripts and styles.
 *
 * @package    FlatLine
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2015, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */

/**
 * Loads the theme styles & scripts.
 *
 * @since 1.0.0
 * @link  http://codex.wordpress.org/Function_Reference/wp_enqueue_script
 * @link  http://codex.wordpress.org/Function_Reference/wp_enqueue_style
 */
function flatline_enqueue() {

	// Load theme fonts.
	wp_enqueue_style( 'flatline-opensans', flatline_open_sans_font_url(), array(), null );
	wp_enqueue_style( 'flatline-oswald', flatline_oswald_font_url(), array(), null );

	// if WP_DEBUG and/or SCRIPT_DEBUG turned on, load the unminified styles & script.
	if ( ! is_child_theme() && WP_DEBUG || SCRIPT_DEBUG ) {

		// Load main stylesheet
		wp_enqueue_style( 'flatline-style', get_stylesheet_uri() );

		// Load custom js plugins.
		wp_enqueue_script( 'flatline-plugins', trailingslashit( get_template_directory_uri() ) . 'assets/js/plugins.min.js', array( 'jquery' ), null, true );

		// Load custom js methods.
		wp_enqueue_script( 'flatline-main', trailingslashit( get_template_directory_uri() ) . 'assets/js/main.js', array( 'jquery' ), null, true );

	} else {

		// Load main stylesheet
		wp_enqueue_style( 'flatline-style', trailingslashit( get_template_directory_uri() ) . 'style.min.css' );

		// Load custom js plugins.
		wp_enqueue_script( 'flatline-scripts', trailingslashit( get_template_directory_uri() ) . 'assets/js/flatline.min.js', array( 'jquery' ), null, true );

	}

	// Load custom js for mobile navigation.
	wp_enqueue_script( 'flatline-mobile-js', trailingslashit( get_template_directory_uri() ) . 'assets/js/navigation.js', array( 'jquery' ), null, true );

	// If child theme is active, load the stylesheet.
	if ( is_child_theme() ) {
		wp_enqueue_style( 'flatline-child-style', get_stylesheet_uri() );
	}

	// Load comment-reply script.
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	// Loads HTML5 Shiv
	wp_enqueue_script( 'flatline-html5', trailingslashit( get_template_directory_uri() ) . 'assets/js/html5shiv.min.js', array( 'jquery' ), null, false );
	wp_script_add_data( 'flatline-html5', 'conditional', 'lte IE 9' );

}
add_action( 'wp_enqueue_scripts', 'flatline_enqueue' );