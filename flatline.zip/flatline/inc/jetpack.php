<?php
/**
 * Jetpack Compatibility File
 * See: http://jetpack.me/
 *
 * @package    FlatLine
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2015, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */

/**
 * Jetpack setup
 * 
 * @since  1.0.0
 */
function flatline_jetpack_setup() {

	/**
	 * Add theme support for Infinite Scroll.
	 * See: http://jetpack.me/support/infinite-scroll/
	 */
	add_theme_support( 'infinite-scroll', array(
		'container'      => 'main',
		'footer_widgets' => array(
			'footer-one',
			'footer-two',
			'footer-three',
			'footer-four',
		),
		'footer'         => 'page',
	) );
	
	/**
	 * Add theme support for Responsive Videos.
	 */
	add_theme_support( 'jetpack-responsive-videos' );

	/**
	 * Add theme support for Testimonials content type.
	 */
	add_theme_support( 'jetpack-testimonial' );

}
add_action( 'after_setup_theme', 'flatline_jetpack_setup' );

/**
 * Remove sharedaddy from excerpt.
 *
 * @since  1.0.0
 */
function flatline_remove_sharedaddy() {
    remove_filter( 'the_excerpt', 'sharing_display', 19 );
}
add_action( 'loop_start', 'flatline_remove_sharedaddy' );

/**
 * Flush the Rewrite Rules for the testimonials CPT after the user has activated the theme.
 *
 * @since  1.0.0
 */
function flatline_flush_rewrite_rules() {
	flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'flatline_flush_rewrite_rules' );