<?php
/**
 * Theme Options.
 *
 * @package    FlatLine
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2015, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */

/**
 * A unique identifier is defined to store the options in the database and reference them from the theme.
 *
 * @since  1.0.0
 */
function optionsframework_option_name() {
	return 'flatline'; // Theme slug
}

/**
 * Defines an array of options that will be used to generate the settings page and be saved in the database.
 * When creating the 'id' fields, make sure to use all lowercase and no spaces.
 *
 * @since  1.0.0
 */
function optionsframework_options() {

	// Pull all the categories into an array
	$options_categories = array();
	$options_categories_obj = get_categories();
	$options_categories[''] = __( 'All Categories', 'flatline' );
	foreach ($options_categories_obj as $category) {
		$options_categories[$category->cat_ID] = $category->cat_name;
	}

	// Pull all tags into an array
	$options_tags = array();
	$options_tags_obj = get_tags();
	$options_tags[''] = __( 'All Tags', 'flatline' );
	foreach ( $options_tags_obj as $tag ) {
		$options_tags[$tag->term_id] = $tag->name;
	}

	// Pull all the pages into an array
	$options_pages = array();
	$options_pages_obj = get_pages( 'sort_column=post_parent,menu_order' );
	$options_pages[''] = __( 'Select a page:', 'flatline' );
	foreach ($options_pages_obj as $page) {
		$options_pages[$page->ID] = $page->post_title;
	}

	// Image path
	$imagepath =  get_template_directory_uri() . '/assets/img/';

	// Set empty $options.
	$options = array();

	/**
	 * Defines array of options.
	 */
	
	// ============================ //
	// ===== General Settings ===== //
	// ============================ //
	$options[] = array(
		'name' => __( 'General', 'flatline' ),
		'type' => 'heading'
	);

		$options['flatline_favicon'] = array(
			'name' => __( 'Favicon', 'flatline' ),
			'desc' => __( 'Your custom favicon. 32x32px recommended.', 'flatline' ),
			'id'   => 'flatline_favicon',
			'type' => 'upload'
		);

		$options['flatline_mobile_icon'] = array(
			'name' => __( 'Mobile Icon', 'flatline' ),
			'desc' => __( '144x144 recommended in PNG format. This icon will be used when users add your website as a shortcut on mobile devices like iPhone, iPad, Android etc.', 'flatline' ),
			'id'   => 'flatline_mobile_icon',
			'type' => 'upload'
		);

		$options[] = array(
			'name'  => __( 'FeedBurner URL', 'flatline' ),
			'desc'  => __( 'Enter your full FeedBurner URL. If you wish to use FeedBurner over the standard WordPress feed.', 'flatline' ),
			'id'    => 'flatline_feedburner_url',
			'placeholder' => 'http://feeds.feedburner.com/ThemeJunkie',
			'type'  => 'text'
		);

		$options['flatline_tracking'] = array(
			'name' => __( 'Tracking Code', 'flatline' ),
			'desc' => __( 'Paste your Google Analytics (or other) tracking code here. It will be inserted before the closing body tag of your theme.', 'flatline' ),
			'id'   => 'flatline_tracking',
			'type' => 'textarea'
		);

	// ============================ //
	// ===== Header Settings ===== //
	// ============================ //
	$options[] = array(
		'name' => __( 'Header', 'flatline' ),
		'type' => 'heading'
	);

		$options['flatline_logo'] = array(
			'name' => __( 'Logo', 'flatline' ),
			'desc' => __( 'Upload your custom logo, it will automatically replace the Site Title', 'flatline' ),
			'id'   => 'flatline_logo',
			'type' => 'upload'
		);

		$options['flatline_logo_retina'] = array(
			'name' => __( 'Retina Logo', 'flatline' ),
			'desc' => __( 'Upload your retina version of your logo. eg: logo@2x.png', 'flatline' ),
			'id'   => 'flatline_logo_retina',
			'type' => 'upload'
		);

		$options[] = array(
			'name' => __( 'Site Description', 'flatline' ),
			'desc' => __( 'Display the site description.', 'flatline' ),
			'id'   => 'flatline_site_desc',
			'std'  => 'on',
			'type' => 'onoff'
		);

	// ================================ //
	// ===== Single Post Settings ===== //
	// ================================ //
	$options[] = array(
		'name' => __( 'Single Post', 'flatline' ),
		'type' => 'heading'
	);

		$options[] = array(
			'name' => __( 'Featured Image', 'flatline' ),
			'desc' => __( 'Display the featured image.', 'flatline' ),
			'id'   => 'flatline_featured_image',
			'std'  => 'on',
			'type' => 'onoff'
		);

		$options[] = array(
			'name' => __( 'Date', 'flatline' ),
			'desc' => __( 'Display the post date.', 'flatline' ),
			'id'   => 'flatline_date',
			'std'  => 'on',
			'type' => 'onoff'
		);

		$options[] = array(
			'name' => __( 'Comment', 'flatline' ),
			'desc' => __( 'Display the post comment link.', 'flatline' ),
			'id'   => 'flatline_comment',
			'std'  => 'on',
			'type' => 'onoff'
		);

		$options[] = array(
			'name' => __( 'Categories', 'flatline' ),
			'desc' => __( 'Display the post categories.', 'flatline' ),
			'id'   => 'flatline_categories',
			'std'  => 'on',
			'type' => 'onoff'
		);

		$options[] = array(
			'name' => __( 'Tags', 'flatline' ),
			'desc' => __( 'Display the post tags.', 'flatline' ),
			'id'   => 'flatline_tags',
			'std'  => 'on',
			'type' => 'onoff'
		);

		$options[] = array(
			'name' => __( 'Post Navigation', 'flatline' ),
			'desc' => __( 'Display the post navigation.', 'flatline' ),
			'id'   => 'flatline_post_navigation',
			'std'  => 'on',
			'type' => 'onoff'
		);

		$options[] = array(
			'name' => __( 'Post Misc Settings', 'flatline' ),
			'id'   => '',
			'type' => 'seperator'
		);

			$options[] = array(
				'name' => __( 'Author Bio', 'flatline' ),
				'desc' => __( 'Display the author biographical info.', 'flatline' ),
				'id'   => 'flatline_author_bio',
				'std'  => 'on',
				'type' => 'onoff'
			);

		$options[] = array(
			'name' => __( 'Advertisement Settings', 'flatline' ),
			'id'   => '',
			'type' => 'seperator'
		);

			$options['flatline_ad_single_before'] = array(
				'name' => __( 'Before Content Advertisement', 'flatline' ),
				'desc' => __( 'Your ad will appear on single post before content.', 'flatline' ),
				'id'   => 'flatline_ad_single_before',
				'type' => 'textarea'
			);

			$options['flatline_ad_single_after'] = array(
				'name' => __( 'After Content Advertisement', 'flatline' ),
				'desc' => __( 'Your ad will appear on single post after content.', 'flatline' ),
				'id'   => 'flatline_ad_single_after',
				'type' => 'textarea'
			);

	// =========================== //
	// ===== Footer Settings ===== //
	// =========================== //
	$options[] = array(
		'name' => __( 'Footer', 'flatline' ),
		'type' => 'heading'
	);

		$options['flatline_footer_text'] = array(
			'name' => __( 'Footer Text', 'flatline' ),
			'desc' => __( 'You can customize the footer text here.', 'flatline' ),
			'id'   => 'flatline_footer_text',
			'std'  => '&copy; Copyright ' . date( 'Y' ) . ' <a href="' . esc_url( home_url() ) . '">' . esc_attr( get_bloginfo( 'name' ) ) . '</a> &middot; Designed by <a href="http://www.theme-junkie.com/">Theme Junkie</a>',
			'type' => 'editor'
		);

	// ================================== //
	// ===== Custom Code Settings ======= //
	// ================================== //
	$options[] = array(
		'name' => __( 'Custom Code', 'flatline' ),
		'type' => 'heading'
	);

		$options['flatline_script_head'] = array(
			'name' => __( 'Header code', 'flatline' ),
			'desc' => __( 'If you need to add custom scripts to your header (meta tag verification, google fonts url), you should enter them in the box. They will be added before &lt;/head&gt; tag', 'flatline' ),
			'id'   => 'flatline_script_head',
			'type' => 'textarea'
		);

		$options['flatline_script_footer'] = array(
			'name' => __( 'Footer code', 'flatline' ),
			'desc' => __( 'If you need to add custom scripts to your footer, you should enter them in the box. They will be added before &lt;/body&gt; tag', 'flatline' ),
			'id'   => 'flatline_script_footer',
			'type' => 'textarea'
		);
	
	// Allow dev to filter the theme options.
	return apply_filters( 'flatline_theme_options', $options );
}