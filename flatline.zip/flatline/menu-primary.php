<nav id="site-navigation" class="main-navigation" role="navigation" <?php hybrid_attr( 'menu' ); ?>>

	<div class="container">
		
		<button class="menu-toggle" aria-controls="menu" aria-expanded="false"><span class="genericon genericon-menu"></span> <?php _e( 'Menu', 'flatline' ); ?></button>
		<?php if ( has_nav_menu( 'primary' ) ) : // Check if there's a menu assigned to the 'primary' location. ?>
			<?php wp_nav_menu(
				array(
					'theme_location'  => 'primary',
					'container_class' => 'menu-primary',
					'menu_id'         => 'menu-primary-items',
					'menu_class'      => 'menu-primary-items',
					'fallback_cb'     => ''
				)
			); ?>
		<?php endif; // End check for menu. ?>

		<?php wp_nav_menu(
			array(
				'theme_location'  => 'social',
				'container_class' => 'menu-social',
				'menu_id'         => 'menu-social-items',
				'menu_class'      => 'menu-social-items',
				'depth'           => 1,
				'link_before'     => '<span class="screen-reader-text">',
				'link_after'      => '</span>',
				'fallback_cb'     => '',
			)
		); ?>

	</div>

</nav><!-- #site-navigation -->