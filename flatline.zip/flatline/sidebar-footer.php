<?php
// Return early if no widget found.
if ( ! is_active_sidebar( 'footer-one' ) || ! is_active_sidebar( 'footer-two' ) || ! is_active_sidebar( 'footer-three' ) || ! is_active_sidebar( 'footer-four' ) ) {
	return;
}
?>

<div id="tertiary" class="footer-widget-area widget-area" role="complementary" aria-label="<?php echo esc_attr_x( 'Footer Sidebar', 'Sidebar aria label', 'flatline' ); ?>" <?php hybrid_attr( 'sidebar', 'footer' ); ?>>
	<div class="container footer-widget-container">
			
		<?php if ( is_active_sidebar( 'footer-one' ) ) : ?>
			<div class="footer-widget">
				<?php dynamic_sidebar( 'footer-one' ); ?>
			</div><!-- .footer-widget -->
		<?php endif; ?>

		<?php if ( is_active_sidebar( 'footer-two' ) ) : ?>
			<div class="footer-widget">
				<?php dynamic_sidebar( 'footer-two' ); ?>
			</div><!-- .footer-widget -->
		<?php endif; ?>

		<?php if ( is_active_sidebar( 'footer-three' ) ) : ?>
			<div class="footer-widget">
				<?php dynamic_sidebar( 'footer-three' ); ?>
			</div><!-- .footer-widget -->
		<?php endif; ?>

		<?php if ( is_active_sidebar( 'footer-four' ) ) : ?>
			<div class="footer-widget last-widget">
				<?php dynamic_sidebar( 'footer-four' ); ?>
			</div><!-- .footer-widget -->
		<?php endif; ?>

	</div>
</div>