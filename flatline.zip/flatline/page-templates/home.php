<?php
/**
 * Template Name: Home template
 */
get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main" <?php hybrid_attr( 'content' ); ?>>
			
			<div class="home-content">
				<?php get_sidebar( 'home' ); ?>
			</div>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php get_footer(); ?>
