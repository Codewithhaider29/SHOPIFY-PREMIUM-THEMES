<?php if ( is_active_sidebar( 'home-slider' ) ) : ?>
	<div class="home-widgets-slider">
		<?php dynamic_sidebar( 'home-slider' ); ?>
	</div>
<?php endif; ?>

<?php if ( is_active_sidebar( 'home-top' ) ) : ?>
	<div class="home-widgets-top">
		<div class="container">
			<?php dynamic_sidebar( 'home-top' ); ?>
		</div>
	</div>
<?php endif; ?>

<?php if ( is_active_sidebar( 'home-middle' ) ) : ?>
	<div class="home-widgets-middle">
		<div class="container">
			<?php dynamic_sidebar( 'home-middle' ); ?>
		</div><!-- .container -->
	</div>
<?php endif; ?>

<?php if ( is_active_sidebar( 'home-bottom' ) ) : ?>
	<div class="home-widgets-bottom">
		<div class="container">
			<?php dynamic_sidebar( 'home-bottom' ); ?>
		</div><!-- .container -->
	</div>
<?php endif; ?>