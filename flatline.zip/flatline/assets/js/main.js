jQuery(function($) {

	/**
	 * Responsive video
	 */
	$('.hentry, .widget').fitVids();

	/**
	 * Carousel #0 / Featured Content
	 */
	$(document).imagesLoaded(function(){

		$('#carousel-0')
			.jcarousel({
				wrap: 'circular',
				animation: {
					duration: 500
				}
			})
			.jcarouselAutoscroll({
				autostart: true,
				interval: 5000
			})
		;

		$('.jcarousel-control-prev')
			.on('jcarouselcontrol:active', function() {
				$(this).removeClass('inactive');
			})
			.on('jcarouselcontrol:inactive', function() {
				$(this).addClass('inactive');
			})
			.jcarouselControl({
				target: '-=1'
			})
		;

		$('.jcarousel-control-next')
			.on('jcarouselcontrol:active', function() {
				$(this).removeClass('inactive');
			})
			.on('jcarouselcontrol:inactive', function() {
				$(this).addClass('inactive');
			})
			.jcarouselControl({
				target: '+=1'
			})
		;

	});

	/**
	 * Scroll Top
	 */
	$.scrollUp({
		scrollName: 'scrollUp',      // Element ID
		scrollDistance: 300,         // Distance from top/bottom before showing element (px)
		scrollFrom: 'top',           // 'top' or 'bottom'
		scrollSpeed: 300,            // Speed back to top (ms)
		animation: 'fade',           // Fade, slide, none
		animationSpeed: 400,         // Animation speed (ms)
		scrollText: '<span class="genericon genericon-collapse"></span>', // Text for element, can contain HTML
	});

});