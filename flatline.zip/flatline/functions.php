<?php
/**
 * Theme functions file
 *
 * Contains all of the Theme's setup functions, custom functions,
 * custom hooks and Theme settings.
 *
 * @package    FlatLine
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2015, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */

/**
 * Set the content width based on the theme's design and stylesheet.
 */
if ( ! isset( $content_width ) ) {
	$content_width = 751; /* pixels */
}

if ( ! function_exists( 'flatline_content_width' ) ) :
/**
 * Set new content width if user uses 1 column layout.
 *
 * @since  1.0.0
 */
function flatline_content_width() {
	global $content_width;

	if ( in_array( get_theme_mod( 'theme_layout' ), array( '1c' ) ) ) {
		$content_width = 1110;
	}
}
endif;
add_action( 'template_redirect', 'flatline_content_width' );

if ( ! function_exists( 'flatline_theme_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * @since  1.0.0
 */
function flatline_theme_setup() {

	// Make the theme available for translation.
	load_theme_textdomain( 'flatline', trailingslashit( get_template_directory() ) . 'languages' );

	// Add custom stylesheet file to the TinyMCE visual editor.
	add_editor_style( array( 'assets/css/editor-style.css', flatline_open_sans_font_url(), flatline_oswald_font_url() ) );

	// Add RSS feed links to <head> for posts and comments.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	// Enable support for Post Thumbnails.
	add_theme_support( 'post-thumbnails' );

	// Declare image sizes.
	add_image_size( 'flatline-widget-thumb', 60, 60, true );
	add_image_size( 'flatline-featured', 751, 500, true );
	add_image_size( 'flatline-featured-big', 1110, 550, true );
	add_image_size( 'flatline-featured-widget', 400, 250, true );
	add_image_size( 'flatline-testimonial-widget', 90, 90, true );

	// Register custom navigation menu.
	register_nav_menus(
		array(
			'primary' => __( 'Primary Menu', 'flatline' ),
			'social'  => __( 'Social Menu' , 'flatline' ),
		)
	);

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'comment-list', 'search-form', 'comment-form', 'gallery', 'caption'
	) );

	/*
	 * Enable support for Post Formats.
	 * See: http://codex.wordpress.org/Post_Formats
	 */
	add_theme_support( 'post-formats', array(
		'audio', 'gallery', 'image', 'video'
	) );

	// Setup the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'flatline_custom_background_args', array(
		'default-color' => 'f5f5f5',
		'default-image' => '',
	) ) );

	// Enable theme-layouts extensions.
	add_theme_support( 'theme-layouts',
		array(
			'1c'   => __( '1 Column Wide (Full Width)', 'flatline' ),
			'2c-l' => __( '2 Columns: Content / Sidebar', 'flatline' ),
			'2c-r' => __( '2 Columns: Sidebar / Content', 'flatline' )
		),
		array( 'customize' => false, 'default' => '2c-l' )
	);

	// This theme uses its own gallery styles.
	add_filter( 'use_default_gallery_style', '__return_false' );

	// Enable excerpt on Pages.
	add_post_type_support( 'page', 'excerpt' );

}
endif; // flatline_theme_setup
add_action( 'after_setup_theme', 'flatline_theme_setup' );

/**
 * Registers custom widgets.
 *
 * @since 1.0.0
 * @link  http://codex.wordpress.org/Function_Reference/register_widget
 */
function flatline_widgets_init() {

	// Register ad widget.
	require trailingslashit( get_template_directory() ) . 'inc/widgets/widget-ads.php';
	register_widget( 'FlatLine_Ads_Widget' );

	// Register feedburner widget.
	require trailingslashit( get_template_directory() ) . 'inc/widgets/widget-feedburner.php';
	register_widget( 'FlatLine_Feedburner_Widget' );

	// Register recent posts thumbnail widget.
	require trailingslashit( get_template_directory() ) . 'inc/widgets/widget-recent.php';
	register_widget( 'FlatLine_Recent_Widget' );

	// Register popular posts thumbnail widget.
	require trailingslashit( get_template_directory() ) . 'inc/widgets/widget-popular.php';
	register_widget( 'FlatLine_Popular_Widget' );

	// Register random posts thumbnail widget.
	require trailingslashit( get_template_directory() ) . 'inc/widgets/widget-random.php';
	register_widget( 'FlatLine_Random_Widget' );

	// Register most views posts thumbnail widget.
	require trailingslashit( get_template_directory() ) . 'inc/widgets/widget-views.php';
	register_widget( 'FlatLine_Views_Widget' );

	// Register twitter widget.
	require trailingslashit( get_template_directory() ) . 'inc/widgets/widget-twitter.php';
	register_widget( 'FlatLine_Twitter_Widget' );

	// Register video widget.
	require trailingslashit( get_template_directory() ) . 'inc/widgets/widget-video.php';
	register_widget( 'FlatLine_Video_Widget' );

	/**
	 * Front Page Widgets.
	 */

	// Register call to action widget.
	require trailingslashit( get_template_directory() ) . 'inc/widgets/widget-fp-call-action.php';
	register_widget( 'FlatLine_Call_Action_Widget' );

	// Register call to action widget.
	require trailingslashit( get_template_directory() ) . 'inc/widgets/widget-fp-featured-pages.php';
	register_widget( 'FlatLine_Featured_Pages_Widget' );

	// Register testimonials widget.
	require trailingslashit( get_template_directory() ) . 'inc/widgets/widget-fp-testimonials.php';
	register_widget( 'FlatLine_Testimonials_Widget' );

	// Register projects widget.
	require trailingslashit( get_template_directory() ) . 'inc/widgets/widget-fp-projects.php';
	register_widget( 'FlatLine_Projects_Widget' );


}
add_action( 'widgets_init', 'flatline_widgets_init' );

/**
 * Registers widget areas and custom widgets.
 *
 * @since 1.0.0
 * @link  http://codex.wordpress.org/Function_Reference/register_sidebar
 */
function flatline_sidebars_init() {

	register_sidebar(
		array(
			'name'          => __( 'Front Page Slider', 'flatline' ),
			'id'            => 'home-slider',
			'description'   => __( 'Use this widget area to display custom slider on your Front Page.', 'flatline' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);

	register_sidebar(
		array(
			'name'          => __( 'Front Page Top', 'flatline' ),
			'id'            => 'home-top',
			'description'   => __( 'Use this widget area to display widgets in the top of your Front Page (below slider).', 'flatline' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);

	register_sidebar(
		array(
			'name'          => __( 'Front Page Middle', 'flatline' ),
			'id'            => 'home-middle',
			'description'   => __( 'Use this widget area to display widgets in the middle of your Front Page with white background.', 'flatline' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);

	register_sidebar(
		array(
			'name'          => __( 'Front Page Bottom', 'flatline' ),
			'id'            => 'home-bottom',
			'description'   => __( 'Use this widget area to display widgets in the bottom of your Front Page.', 'flatline' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);

	register_sidebar(
		array(
			'name'          => __( 'Header Sidebar', 'flatline' ),
			'id'            => 'header',
			'description'   => __( 'Use this widget area to display widget in the header.', 'flatline' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);

	register_sidebar(
		array(
			'name'          => __( 'Primary Sidebar', 'flatline' ),
			'id'            => 'primary',
			'description'   => __( 'Main sidebar that appears on the right.', 'flatline' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);

	register_sidebar(
		array(
			'name'          => __( 'Footer One', 'flatline' ),
			'id'            => 'footer-one',
			'description'   => __( 'Use this widget area to display widgets in the first column of the footer.', 'flatline' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);

	register_sidebar(
		array(
			'name'          => __( 'Footer Two', 'flatline' ),
			'id'            => 'footer-two',
			'description'   => __( 'Use this widget area to display widgets in the second column of the footer.', 'flatline' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);

	register_sidebar(
		array(
			'name'          => __( 'Footer Three', 'flatline' ),
			'id'            => 'footer-three',
			'description'   => __( 'Use this widget area to display widgets in the third column of the footer.', 'flatline' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);

	register_sidebar(
		array(
			'name'          => __( 'Footer Four', 'flatline' ),
			'id'            => 'footer-four',
			'description'   => __( 'Use this widget area to display widgets in the fourth column of the footer.', 'flatline' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);

}
add_action( 'widgets_init', 'flatline_sidebars_init' );

/**
 * Register Open Sans Google font.
 *
 * @since  1.0.0
 * @return string
 */
function flatline_open_sans_font_url() {

	$opensans_font_url = '';
	/*
	 * Translators: If there are characters in your language that are not supported
	 * by Open Sans, translate this to 'off'. Do not translate into your own language.
	 */
	if ( 'off' !== _x( 'on', 'Open Sans font: on or off', 'flatline' ) ) {
		$opensans_font_url = add_query_arg( 'family', urlencode( 'Open Sans:300italic,400italic,600italic,700italic,700,300,600,400' ), "//fonts.googleapis.com/css" );
	}

	return $opensans_font_url;
}

/**
 * Register Oswald Google font.
 *
 * @since  1.0.0
 * @return string
 */
function flatline_oswald_font_url() {

	$oswald_font_url = '';
	/*
	 * Translators: If there are characters in your language that are not supported
	 * by Oswald, translate this to 'off'. Do not translate into your own language.
	 */
	if ( 'off' !== _x( 'on', 'Oswald font: on or off', 'flatline' ) ) {
		$oswald_font_url = add_query_arg( 'family', urlencode( 'Oswald:400,700,300' ), "//fonts.googleapis.com/css" );
	}

	return $oswald_font_url;
}

/**
 * Custom template tags for this theme.
 */
require trailingslashit( get_template_directory() ) . 'inc/template-tags.php';

/**
 * Enqueue scripts and styles.
 */
require trailingslashit( get_template_directory() ) . 'inc/scripts.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require trailingslashit( get_template_directory() ) . 'inc/extras.php';

/**
 * Customizer additions.
 */
require trailingslashit( get_template_directory() ) . 'inc/customizer.php';

/**
 * Require and recommended plugins list.
 */
require trailingslashit( get_template_directory() ) . 'inc/plugins.php';

/**
 * Load Jetpack compatibility file.
 */
require trailingslashit( get_template_directory() ) . 'inc/jetpack.php';

/**
 * Load Options Framework core.
 */
define( 'OPTIONS_FRAMEWORK_DIRECTORY', trailingslashit( get_template_directory_uri() ) . 'admin/' );
require trailingslashit( get_template_directory() ) . 'admin/options-framework.php';
require trailingslashit( get_template_directory() ) . 'admin/options.php';
require trailingslashit( get_template_directory() ) . 'admin/options-functions.php';

/**
 * We use some part of Hybrid Core to extends our themes.
 *
 * @link  http://themehybrid.com/hybrid-core Hybrid Core site.
 */
require trailingslashit( get_template_directory() ) . 'inc/hybrid/attr.php';
require trailingslashit( get_template_directory() ) . 'inc/hybrid/breadcrumb-trail.php';
require trailingslashit( get_template_directory() ) . 'inc/hybrid/loop-pagination.php';
require trailingslashit( get_template_directory() ) . 'inc/hybrid/theme-layouts.php';
require trailingslashit( get_template_directory() ) . 'inc/hybrid/entry-views.php';
require trailingslashit( get_template_directory() ) . 'inc/hybrid/hybrid-media-grabber.php';

/**
 * Demo importer
 */
require trailingslashit( get_template_directory() ) . 'inc/demo/demo-importer.php';
