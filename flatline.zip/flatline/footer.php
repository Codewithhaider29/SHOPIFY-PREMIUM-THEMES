		<?php if ( ! is_page_template( 'page-templates/home.php' ) && ! is_post_type_archive( 'jetpack-testimonial' ) ) : ?>
			</div><!-- .container -->
		<?php endif; ?>
	</div><!-- #content -->

	<?php get_sidebar( 'footer' ); ?>

	<footer id="colophon" class="site-footer" role="contentinfo" <?php hybrid_attr( 'footer' ); ?>>
		<div class="container site-footer-container">

			<div class="site-info">
				<?php echo stripslashes( of_get_option( 'flatline_footer_text', of_get_default( 'flatline_footer_text' ) ) ); ?>
			</div><!-- .site-info -->

		</div>
	</footer><!-- #colophon -->
	
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
