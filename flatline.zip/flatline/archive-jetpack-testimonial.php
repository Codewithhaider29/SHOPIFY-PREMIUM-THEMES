<?php get_header(); ?>

	<section id="primary" class="content-area">
		<main id="main" class="site-main" role="main" <?php hybrid_attr( 'content' ); ?>>

			<?php $jetpack_options = get_theme_mod( 'jetpack_testimonials' ); ?>

			<?php if ( '' != $jetpack_options['featured-image'] ) : ?>
				<div class="testimonial-page-thumbnail">
					<?php echo wp_get_attachment_image( (int)$jetpack_options['featured-image'], 'flatline-featured-big' ); ?>
				</div><!-- .thumbnail -->
			<?php endif; ?>

			<div class="container">

				<div class="testimonial-page-content">

					<h1 class="entry-title">
						<?php
						if ( ! empty( $jetpack_options['page-title'] ) )
							echo esc_html( $jetpack_options['page-title'] );
						else
							_e( 'Testimonials', 'flatline' );
						?>
					</h1>

					<?php if ( ! empty( $jetpack_options['page-content'] ) ) : ?>
						<div class="testimonial-page-desc">
							<?php echo convert_chars( convert_smilies( wptexturize( stripslashes( wp_filter_post_kses( addslashes( $jetpack_options['page-content'] ) ) ) ) ) ); ?>
						</div><!-- .thumbnail -->
					<?php endif; ?>
				</div>

				<?php if ( have_posts() ) : ?>

					<?php /* Start the Loop */ ?>
					<?php while ( have_posts() ) : the_post(); ?>

						<?php get_template_part( 'content', 'testimonial' ); ?>

					<?php endwhile; ?>

				<?php else : ?>

					<?php get_template_part( 'content', 'none' ); ?>

				<?php endif; ?>

			</div>

		</main><!-- #main -->
	</section><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>