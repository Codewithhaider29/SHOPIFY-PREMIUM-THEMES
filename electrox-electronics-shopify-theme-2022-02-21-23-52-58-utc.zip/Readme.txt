Within the main folder [Electrox-v1] there will be following folder and files.

Documentation
Install_01.zip
Install_02.zip
Install_03.zip
Install_04.zip
Readme.txt
log.txt


A that file that you need to install is : Install.zip

------------------------------------------------------------------------------------------------------------------------------------

http://themessupport.com/documentation/doc/electrox/


Kindly refer our documentation for installing the theme and doing customization. If you need any assistance, plz contact us through support@wedesignthemes.com


Thank You.
DesignThemes.










