Thank you for purchase our theme. 
For more instruction, please read the document in folder /guides

-------------------------
We also provide Website development service by Shopify. Our hourly rate is 10USD/hour. You can hire me if you
can do your website by yourself.

Thank again,
ShopiLaunch Theme - ShopiLaunch Team