Please unpack the whole package after downloading it from Themeforest.
On that extracted themeforest-bakins-shopify-theme, You can find files like
Documentation,
bakins.zip ,
Log.txt and Readme.txt.

You need to install the file "bakins.zip".


Online documentation link :  
https://themessupport.com/buddha-shop/bakins/