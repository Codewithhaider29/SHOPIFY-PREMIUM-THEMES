<?php get_header(); ?>

	<main class="wrapper-posts col-xs-12 col-sm-8 col-md-9 col-lg-9">

		<?php while ( have_posts() ) : the_post(); ?>

			<article id="post-<?php the_ID(); ?>" <?php post_class( 'wrapper-post wrapper-text text-dark' ); ?>>

				<?php the_title( '<h1 class="post-title text-center understroke">', '</h1>' ); ?>

				<div class="entry-attachment">

					<div class="attachment">
						<?php
							/**
							 * Filter the default Leda image attachment size.
							 */
							$image_size = apply_filters( 'fashionchic_attachment_size', 'full' );

							echo wp_get_attachment_image( get_the_ID(), $image_size );
						?>

					</div><!-- .entry-attachment -->

					<div class="post-text">
						<?php the_content(); ?>
					</div>

				</div>

			</article><!-- #post-## -->

		<?php endwhile; // end of the loop. ?>

	</main>=

<?php get_sidebar(); ?>
<?php get_footer(); ?>
