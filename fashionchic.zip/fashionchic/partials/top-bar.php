<div class="site-top hidden-xs wide container-flex text-dark">
	<div class="container island-2">

		<!-- Social Icons -->
		<?php if ( has_nav_menu ( 'social' ) ) : ?>
			<div class="site-top-widgets col-sm-8 col-lg-9">
				<?php wp_nav_menu(
					array(
						'theme_location'  => 'social',
						'depth'           => 1,
						'link_before'     => '<span class="sr-only">',
						'link_after'      => '</span>',
						'menu_class'      => 'social-icons list-inline nomargin',
						'container'       => false
					)
				); ?>
			</div>
		<?php endif; ?>

		<!-- Search -->
		<div class="site-top-search col-sm-4 col-lg-3 text-right">
			<div class="widget widget-search">
				<form method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
					<input class="search-field t6" type="search" name="s" id="s" autocomplete="off" value="<?php echo esc_attr( get_search_query() ); ?>"><i class="fa fa-search search-btn"><span class="sr-only"><?php esc_html_e( 'Search', 'fashionchic' ); ?></span></i>
				</form>
			</div>
		</div>

	</div>
</div>
