<article id="post-<?php the_ID(); ?>" <?php post_class( 'wrapper-post wrapper-text text-dark' ); ?>>

	<?php the_title( sprintf( '<h2 class="post-title text-center understroke"><a class="post-title-link text-accent-hover" href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>

	<ul class="post-meta meta list-inline small text-uppercase sf text-center">
		<li class="nopadding">
			<time class="post-date published" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
		</li>
		<?php if ( 'post' == get_post_type() ) : ?>
			<?php
				$categories = get_the_category();
				if ( $categories && fashionchic_categorized_blog() ) :
			?>
				<?php foreach( $categories as $category ) : ?>
					<li class="post-tag nopadding">
						<a class="tag-link text-accent" href="<?php echo esc_url( get_category_link( $category->term_id ) ); ?>"><?php echo esc_html( $category->name ); ?></a>
					</li>
				<?php endforeach; ?>
			<?php endif; // End if categories ?>
		<?php endif; ?>
	</ul>

	<div class="post-text">

		<?php if ( has_post_thumbnail() ) : ?>
			<figure class="media-full">
				<a class="thumbnail-link" href="<?php the_permalink(); ?>">
					<?php the_post_thumbnail( 'large', array( 'class' => 'entry-thumbnail', 'alt' => esc_attr( get_the_title() ) ) ); ?>
				</a>
			</figure>
		<?php endif; ?>

		<?php the_excerpt(); ?>

	</div>

	<div class="post-share text-center">

		<!-- Read more -->
		<a href="<?php the_permalink(); ?>" class="btn btn-more"><?php _e( 'Read More', 'fashionchic' ); ?></a>

		<!-- Like -->
		<div class="btn btn-like">
			<div class="likebutton text-muted left">
				<?php echo fashionchic_do_likes(); ?>
			</div>
		</div>

	</div>

</article><!-- #post-## -->
