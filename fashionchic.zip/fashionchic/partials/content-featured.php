<?php
// Get the data set in customizer
$enable  = get_theme_mod( 'fashionchic-featured-enable', 1 );
$tag     = get_theme_mod( 'fashionchic-featured-tag' );
$num     = get_theme_mod( 'fashionchic-featured-num', 6 );
$orderby = get_theme_mod( 'fashionchic-featured-orderby', 'date' );

// Show on home page
if ( !is_home() ) {
	return;
}

// Disable the posts slider by user selected in the customizer
if ( !$enable ) {
	return;
}

// Posts query arguments.
$args = array(
	'posts_per_page' => $num,
	'post_type'      => 'post',
	'orderby'        => $orderby
);

// Include the tag.
if ( $tag ) {
	$args['tag_id'] = absint( $tag );
}

// Allow dev to filter the query.
$args = apply_filters( 'fashionchic_featured_posts_args', $args );

// The post query
$featured = new WP_Query( $args );

if ( $featured->have_posts() ) : ?>
	<div class="wrapper-slider hp-only">
		<div class="slide-frame wide container-flex">
			<div class="slider slider-size">
				<ul class="rslides slides-container text-center">

					<?php while ( $featured->have_posts() ) : $featured->the_post(); ?>

						<?php $image = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' ); ?>

						<li style="background-image: url( '<?php echo esc_url( $image[0] ); ?>' ); background-size: cover;" class="slide slide-1 vertical-align horizontal-align">
							<div class="slide-content text-light">
								<?php if ( 'post' == get_post_type() ) : ?>
									<?php
										/* translators: used between list items, there is a space after the comma */
										$categories_list = get_the_category_list( __( ', ', 'fashionchic' ) );
										if ( $categories_list && fashionchic_categorized_blog() ) :
									?>
									<small class="small sf text-uppercase">
										<?php echo $categories_list; ?>
									</small>
									<?php endif; // End if categories ?>
								<?php endif; ?>
								<h3 class="slide-text nomargin"><?php the_title(); ?></h3>
								<p class="clearfix nomargin pad-top">
									<a href="<?php the_permalink(); ?>" class="slide-link btn btn-cta hf text-uppercase"><?php esc_html_e( 'Read More', 'fashionchic' ); ?></a>
									</p>
							</div>
						</li>

					<?php endwhile; ?>

				</ul>
			</div>
		</div>
	</div>
<?php endif; wp_reset_postdata(); ?>
