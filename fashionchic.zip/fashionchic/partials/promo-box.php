<?php
// Get the data set in customizer
// Promo box 1
$box_1_img = get_theme_mod( 'fashionchic-promobox-1-img' );
$box_1_url = get_theme_mod( 'fashionchic-promobox-1-url' );
$box_1_text = get_theme_mod( 'fashionchic-promobox-1-text' );

// Promo box 2
$box_2_img = get_theme_mod( 'fashionchic-promobox-2-img' );
$box_2_url = get_theme_mod( 'fashionchic-promobox-2-url' );
$box_2_text = get_theme_mod( 'fashionchic-promobox-2-text' );

// Promo box 3
$box_3_img = get_theme_mod( 'fashionchic-promobox-3-img' );
$box_3_url = get_theme_mod( 'fashionchic-promobox-3-url' );
$box_3_text = get_theme_mod( 'fashionchic-promobox-3-text' );

// Display on home page
if ( !is_home() ) {
	return;
}

if ( $box_1_img || $box_2_img || $box_3_img ) :
?>

	<div class="wrapper-featured hp-only pad-top-double text-dark">
		<div class="row">
			<div class="container">

				<?php if ( $box_1_img ) : ?>
					<?php $img = wp_get_attachment_image_src( (int)$box_1_img, 'full' ) ?>
					<div class="col-sm-4">
						<a href="<?php echo esc_url( $box_1_url ); ?>" class="featured-box-link">
							<div style="background: transparent url( '<?php echo $img[0]; ?>' ) no-repeat top center; background-size: cover" class="featured-box horizontal-align vertical-align hover-fade">
								<h4 class="t3 featured-box-title"><?php echo esc_attr( $box_1_text ); ?></h4>
							</div>
						</a>
					</div>
				<?php endif; ?>

				<?php if ( $box_2_img ) : ?>
					<?php $img = wp_get_attachment_image_src( (int)$box_2_img, 'full' ) ?>
					<div class="col-sm-4">
						<a href="<?php echo esc_url( $box_2_url ); ?>" class="featured-box-link">
							<div style="background: transparent url( '<?php echo $img[0]; ?>' ) no-repeat top center; background-size: cover" class="featured-box horizontal-align vertical-align hover-fade">
								<h4 class="t3 featured-box-title"><?php echo esc_attr( $box_2_text ); ?></h4>
							</div>
						</a>
					</div>
				<?php endif; ?>

				<?php if ( $box_3_img ) : ?>
					<?php $img = wp_get_attachment_image_src( (int)$box_3_img, 'full' ) ?>
					<div class="col-sm-4">
						<a href="<?php echo esc_url( $box_3_url ); ?>" class="featured-box-link">
							<div style="background: transparent url( '<?php echo $img[0]; ?>' ) no-repeat top center; background-size: cover" class="featured-box horizontal-align vertical-align hover-fade">
								<h4 class="t3 featured-box-title"><?php echo esc_attr( $box_3_text ); ?></h4>
							</div>
						</a>
					</div>
				<?php endif; ?>

			</div>
		</div>
	</div>

<?php endif; ?>
