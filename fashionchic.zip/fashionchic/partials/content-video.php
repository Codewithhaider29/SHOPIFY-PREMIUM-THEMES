<article id="post-<?php the_ID(); ?>" <?php post_class( 'wrapper-post wrapper-video text-dark' ); ?>>

	<div class="post-text">

		<?php $video = hybrid_media_grabber( array( 'type' => 'video', 'split_media' => true ) ); ?>
		<?php if ( $video ) :  ?>
			<div class="media-embed hover-fade pad-bottom"><?php echo $video; ?></div>
		<?php endif; ?>

		<ul class="post-meta meta list-inline small text-uppercase sf text-center">
			<li class="nopadding">
				<time class="post-date published" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
			</li>
			<?php if ( 'post' == get_post_type() ) : ?>
				<?php
					$categories = get_the_category();
					if ( $categories && fashionchic_categorized_blog() ) :
				?>
					<?php foreach( $categories as $category ) : ?>
						<li class="post-tag nopadding">
							<a class="tag-link text-accent" href="<?php echo esc_url( get_category_link( $category->term_id ) ); ?>"><?php echo esc_html( $category->name ); ?></a>
						</li>
					<?php endforeach; ?>
				<?php endif; // End if categories ?>
			<?php endif; ?>
		</ul>

	</div>

	<div class="post-share text-center">

		<!-- Read more -->
		<a href="<?php the_permalink(); ?>" class="btn btn-more"><?php _e( 'Read More', 'fashionchic' ); ?></a>

		<!-- Like -->
		<div class="btn btn-like">
			<div class="likebutton text-muted left">
				<?php echo fashionchic_do_likes(); ?>
			</div>
		</div>

	</div>

</article><!-- #post-## -->
