<article id="post-<?php the_ID(); ?>" <?php post_class( 'wrapper-post wrapper-text text-dark' ); ?>>

	<?php the_title( '<h2 class="post-title text-center understroke">', '</h2>' ); ?>

	<ul class="post-meta meta list-inline small text-uppercase sf text-center">
		<li class="nopadding">
			<time class="post-date published" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
		</li>
		<?php if ( 'post' == get_post_type() ) : ?>
			<?php
				$categories = get_the_category();
				if ( $categories && fashionchic_categorized_blog() ) :
			?>
				<?php foreach( $categories as $category ) : ?>
					<li class="post-tag nopadding">
						<a class="tag-link text-accent" href="<?php echo esc_url( get_category_link( $category->term_id ) ); ?>"><?php echo esc_html( $category->name ); ?></a>
					</li>
				<?php endforeach; ?>
			<?php endif; // End if categories ?>
		<?php endif; ?>
	</ul>

	<div class="post-text">

		<?php if ( has_post_format( 'video' ) ) : ?>
			<div class="media-full">
				<?php echo hybrid_media_grabber( array( 'type' => 'video', 'split_media' => true ) ); ?>
			</div>
		<?php elseif ( has_post_format( 'audio' ) ) : ?>
			<div class="media-full">
				<?php echo hybrid_media_grabber( array( 'type' => 'audio', 'split_media' => true ) ); ?>
			</div>
		<?php elseif ( ! has_post_format( 'quote' ) ) : ?>
			<?php if ( has_post_thumbnail() ) : ?>
				<figure class="media-full">
					<?php the_post_thumbnail( 'large', array( 'class' => 'entry-thumbnail', 'alt' => esc_attr( get_the_title() ) ) ); ?>
				</figure>
			<?php endif; ?>
		<?php endif; ?>

		<?php the_content(); ?>
		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'fashionchic' ),
				'after'  => '</div>',
			) );
		?>

	</div>

	<?php fashionchic_entry_share(); ?>

	<?php get_template_part( 'pagination' ); // Loads the pagination.php template  ?>

	<?php fashionchic_post_author_box(); // Display the author box. ?>

	<?php
		// If comments are open or we have at least one comment, load up the comment template
		if ( comments_open() || '0' != get_comments_number() ) :
			comments_template();
		endif;
	?>

</article><!-- #post-## -->
