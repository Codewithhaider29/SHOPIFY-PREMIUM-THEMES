<article id="post-<?php the_ID(); ?>" <?php post_class( 'wrapper-post wrapper-text text-dark' ); ?>>

	<?php the_title( '<h1 class="post-title text-center understroke">', '</h1>' ); ?>

	<div class="post-text">
		<?php the_content(); ?>
		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'fashionchic' ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->

	<?php edit_post_link( __( 'Edit', 'fashionchic' ), '<footer class="entry-footer"><span class="edit-link">', '</span></footer>' ); ?>

</article><!-- #post-## -->
