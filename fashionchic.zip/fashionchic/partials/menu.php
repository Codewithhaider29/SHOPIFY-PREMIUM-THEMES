<?php
// Check if there's a menu assigned to the 'primary' location.
if ( has_nav_menu( 'primary' ) ) : ?>

	<div class="site-navigation clearfix wide container-flex text-dark">
		<nav class="site-nav t5 sf hidden-xs">
			<?php wp_nav_menu(
				array(
					'theme_location'  => 'primary',
					'container_class' => 'container',
					'menu_id'         => 'menu-primary-items',
					'menu_class'      => 'nav-links list-unstyled list-inline nomargin text-center text-uppercase',
					'walker'          => new Fashionchic_Bootstrap_Walker
				)
			); ?>
		</nav>

		<nav class="site-nav-mobile visible-xs-block">
			<a href="#" class="js-menu-toggle menu-toggle menu-toggle-open col-xs-1">
				<i class="fa fa-bars icon-nav-toggle"></i><span class="sr-only"><?php esc_html_e( 'Navigation', 'fashionchic' ); ?></span>
			</a>
			<div id="menu" style="display: none" class="mobile-nav text-dark">
				<div class="mobile-nav-wrapper">
					<?php wp_nav_menu(
						array(
							'theme_location'  => 'primary',
							'container'       => false,
							'menu_id'         => 'menu-primary-items',
							'menu_class'      => 'nav-links t4 list-unstyled',
							'walker'          => new Fashionchic_Bootstrap_Walker
						)
					); ?>
				</div>
				<a href="#" class="js-menu-toggle menu-toggle menu-toggle-close col-xs-1">
					<i class="fa fa-close icon-nav-toggle"></i><span class="sr-only"><?php esc_html_e( 'Close Navigation', 'fashionchic' ); ?></span>
				</a>
			</div>
		</nav>
	</div>

<?php endif; ?>
