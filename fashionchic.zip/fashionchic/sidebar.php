<?php
// Return early if no widget found.
if ( ! is_active_sidebar( 'primary' ) ) {
	return;
}
?>

<aside class="wrapper-aside col-xs-12 col-sm-4 col-md-3 col-lg-3 text-dark">
	<?php dynamic_sidebar( 'primary' ); ?>
</aside><!-- #secondary -->
