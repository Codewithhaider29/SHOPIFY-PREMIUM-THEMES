<?php get_header(); ?>

	<main class="wrapper-posts col-xs-12 col-sm-8 col-md-9 col-lg-9">

		<section class="error-404 not-found">

			<div class="page-content">
				<p><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'fashionchic' ); ?></p>
				<ul>
					<li><a href="javascript: history.go(-1);"><?php esc_html_e( 'Go to Previous Page', 'fashionchic' ) ?></a></li>
					<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Go to Home Page', 'fashionchic' ) ?></a></li>
				</ul>
			</div><!-- .page-content -->

		</section><!-- .error-404 -->

	</main>

<?php get_sidebar(); ?>
<?php get_footer(); ?>
