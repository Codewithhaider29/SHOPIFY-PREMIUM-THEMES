=== FashionChic ===
Contributors: Theme Junkie
Requires at least: WordPress 4.5
Tested up to: WordPress 4.7.5
Version: 1.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Fashion Chic is a beautiful lifestyle WordPress theme blog, with a stylish fashion look and feel.

* Responsive layout.
* 5 Custom Widgets
* Featured Posts
* Promo Box
* Social Links
* Instagram Feed
* Post Formats
* Jetpack.me compatibility for Responsive Videos, Social Sharing, Related Posts.
* The GPL v2.0 or later license. :) Use it to make something cool.

== Useful Links ==

- Documentation: http://docs.theme-junkie.com/fashionchic
- Support      : http://www.theme-junkie.com/support
- Twitter      : https://twitter.com/theme_junkie

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Copyright ==

FashionChic WordPress Theme, Copyright 2017 https://www.theme-junkie.com/
FashionChic is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

== Credits ==

Font Awesome icon font, Copyright http://fontawesome.io
License: Font - SIL OFL 1.1, CSS - MIT License
Source: http://fontawesome.io

HTML5 Shiv v3.7.0, Copyright 2014 Alexander Farkas
Licenses: MIT/GPL2
Source: https://github.com/aFarkas/html5shiv

FitVids v1.1, Copyright 2013, Chris Coyier - http://css-tricks.com + Dave Rupert - http://daverupert.com
Licenses: WTFPL
Source: https://github.com/davatron5000/FitVids.js/

Underscores, (C) 2012-2015 Automattic, Inc.
Licenses: GPL v2
Source: http://underscores.me/

TGM-Plugin-Activation, Copyright (c) 2011, Thomas Griffin
Licenses: GPL v2
Source: https://github.com/TGMPA/TGM-Plugin-Activation

== Changelog ==

1.0.2 - May 23, 2017
* Customizer code refactor
	Remove
		admin/
		inc/mods.php
		inc/styles
	Added
		inc/customizer.php
		inc/customizer/
	Updated
		functions.php
		style.css
		style.min.css
		footer.php
		inc/template-tags.php
		inc/polylang.php
		page.php
		partials/content-featured.php
		partials/promo-box.php
		inc/scripts.php

---

1.0.1 - Jan 05, 2017
* Added one-click demo importer
	inc/demo/
	inc/plugins.php
	functions.php

1.0.0 - Oct 20, 2016
* Initial release
