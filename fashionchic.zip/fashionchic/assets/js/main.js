( function( $ ) {

	// Document ready
	$( function() {

		// Responsive video
		$( '.entry, .widget, .media-embed' ).fitVids();

		// Toggle menu
		var e = $( ".js-menu-toggle" );
		$( e ).click( function() {
			$( "#menu" ).toggle(), $( ".menu-toggle-open" ).toggle()
		} )

		// Slides
		$( ".rslides" ).responsiveSlides( {
			auto: true, // Boolean: Animate automatically, true or false
			speed: 500, // Integer: Speed of the transition, in milliseconds
			timeout: 5000, // Integer: Time between slide transitions, in milliseconds
			pager: true, // Boolean: Show pager, true or false
			nav: false, // Boolean: Show navigation, true or false
			random: false, // Boolean: Randomize the order of the slides, true or false
			pause: false, // Boolean: Pause on hover, true or false
			pauseControls: true, // Boolean: Pause when hovering controls, true or false
			prevText: "Previous", // String: Text for the "previous" button
			nextText: "Next", // String: Text for the "next" button
			maxwidth: "", // Integer: Max-width of the slideshow, in pixels
			navContainer: "", // Selector: Where controls should be appended to, default is after the 'ul'
			manualControls: "", // Selector: Declare custom pager navigation
			namespace: "rslides", // String: Change the default namespace used
			before: function() {}, // Function: Before callback
			after: function() {} // Function: After callback
		} );

		// Back to top
		var n = $( ".back-top" );
		$( n ).hide(), $( function() {
			$( window ).scroll( function() {
				$( this ).scrollTop() > 100 ? $( n ).fadeIn() : $( n ).fadeOut()
			} ), $( n ).click( function() {
				return $( "body,html" ).animate( {
					scrollTop: 0
				}, 800 ), !1
			} )
		} );

		// Adds custom class to the comment form
		$( '#respond' ).addClass( 'comment-respond widget widget-box' );
		$( '#reply-title' ).addClass( 'comment-reply-title h3 understroke text-center pad-bottom' );
		$( '.comment-form .form-submit' ).addClass( 'island-2' );

		// Posts like
		$( '.entry-like a' ).on( 'click',
			function() {
				var link = $( this );
				if ( link.hasClass( 'active' ) ) return false;

				var id = $( this ).attr( 'id' );

				$.post( fashionchic.ajaxurl, {
					action: 'fashionchic-likes',
					likes_id: id
				}, function( data ) {
					link.html( data ).addClass( 'active' ).attr( 'title', fashionchic.rated );
				} );

				return false;
			} );

	} );

}( jQuery ) );
