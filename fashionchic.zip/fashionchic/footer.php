				</div><!-- .container -->
			</div><!-- .row -->
		</div><!-- .wrapper-main -->
	</div><!-- .wrapper-content -->

	<div class="wrapper-footer">
		<footer class="site-footer wide container-flex">

			<?php
				$api   = get_theme_mod( 'fashionchic-instagram-token' );
				$uname = get_theme_mod( 'fashionchic-instagram-username' );
				$uid   = get_theme_mod( 'fashionchic-instagram-userid' );
				$limit = get_theme_mod( 'fashionchic-instagram-limit' );
			?>

			<?php if ( $api ) : ?>
				<div class="footer-widget clearfix text-light">
					<div class="widget-footer widget-instagram-footer">
						<div class="widget-footer-title container text-center small island-1">
							<a href="https://www.instagram.com/<?php echo esc_attr( $uname ); ?>/" title="Follow misspato" class="hover-fade"><span class="sf text-uppercase"><?php esc_html_e( 'Follow', 'fashionchic' ); ?></span><span class="hf widget-title text-accent">@<?php echo esc_attr( $uname ); ?></span></a>
						</div>
						<div id="instagram"></div>
					</div>
				</div>
				<script>
					( function( $ ) {
						$( function() {
							$( "#instagram" ).jqinstapics({
								"user_id": "<?php echo esc_attr( $uid ); ?>",
								"access_token": "<?php echo esc_attr( $api ); ?>",
								"count": <?php echo (int) $limit; ?>,
								"size": "standard_resolution",
								"class": "widget-thumb"
							});
						} );
					}( jQuery ) );
				</script>
			<?php endif; ?>

			<?php if ( has_nav_menu ( 'social' ) ) : ?>
				<div class="footer-widget text-center clearfix text-light">
					<div class="container island-1">
						<?php wp_nav_menu(
							array(
								'theme_location'  => 'social',
								'depth'           => 1,
								'link_before'     => '<span class="small text-uppercase sf">',
								'link_after'      => '</span>',
								'menu_class'      => 'social-icons social-icons-footer list-inline nomargin',
								'container'       => false
							)
						); ?>
					</div>
				</div>
			<?php endif; ?>

			<div class="footer-copyright clearfix text-dark">
				<div class="container text-center island-4">
					<?php fashionchic_footer_text(); ?>
				</div>
			</div>

		</footer>
	</div>

</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
