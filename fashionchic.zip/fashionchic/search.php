<?php get_header(); ?>

	<main class="wrapper-posts col-xs-12 col-sm-8 col-md-9 col-lg-9">

		<?php if ( have_posts() ) : ?>

			<header class="page-header">
				<h2 class="page-title"><?php printf( __( 'Search Results for: %s', 'fashionchic' ), '<span>' . get_search_query() . '</span>' ); ?></h2>
			</header><!-- .page-header -->

			<?php /* Start the Loop */ ?>
			<?php while ( have_posts() ) : the_post(); ?>

				<?php get_template_part( 'partials/content', get_post_format() ); ?>

			<?php endwhile; ?>

			<?php get_template_part( 'pagination' ); // Loads the pagination.php template  ?>

		<?php else : ?>

			<?php get_template_part( 'partials/content', 'none' ); ?>

		<?php endif; ?>

	</main>

<?php get_sidebar(); ?>
<?php get_footer(); ?>
