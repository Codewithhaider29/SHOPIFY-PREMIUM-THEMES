<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">

<?php wp_head(); ?>
</head>

<body id="top" <?php body_class(); ?>>

<div class="back-top text-dark">
	<a href="#top" class="vertical-align horizontal-align">
		<i class="fa fa-2x fa-angle-up text-accent"></i>
		<span class="sr-only"><?php esc_html_e( 'Back to top', 'fashionchic' ); ?></span>
	</a>
</div>

<div id="page" class="site wrapper">
	<div class="wrapper-content">
		<div class="wrapper-main">

			<header id="masthead" class="site-header">

				<?php get_template_part( 'partials/top', 'bar' ); // Loads the 'partials/top-bar.php' template. ?>

				<div class="site-branding clearfix wide container-flex text-dark">
					<?php fashionchic_site_branding(); ?>
				</div>

				<?php get_template_part( 'partials/menu' ); // Loads the 'partials/menu.php' template. ?>

			</header><!-- #masthead -->

			<?php get_template_part( 'partials/content', 'featured' ); // Loads the 'partials/content-featured.php' template. ?>

			<?php get_template_part( 'partials/promo', 'box' ); // Loads the 'partials/promo-box.php' template. ?>

			<div class="row">
				<div class="container">
