<?php if ( is_singular( 'post' ) ) : // If viewing a single post page. ?>

	<div class="wrapper-pagination text-dark">
		<div class="pagination-links">
			<div class="pagination-previous left small text-uppercase sf">
				<?php echo get_previous_post_link( '%link', __( 'Previous', 'fashionchic' ) ); ?>
			</div>
			<div class="pagination-next right small text-uppercase sf">
				<?php echo get_next_post_link( '%link', __( 'Next', 'fashionchic' ) ); ?>
			</div>
		</div>
	</div>

<?php elseif ( is_home() || is_archive() || is_search() ) : // If viewing the blog, an archive, or search results. ?>

	<div class="wrapper-pagination text-dark">
		<div class="pagination-links small text-uppercase sf">
			<?php the_posts_pagination( array(
				'prev_text' => __( 'Newer Posts', 'fashionchic' ),
				'next_text' => __( 'Older Posts', 'fashionchic' )
			) ); ?>
		</div>
	</div>

<?php endif; ?>
