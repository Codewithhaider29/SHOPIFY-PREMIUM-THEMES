<?php
/**
 * Polylang Compatibility File
 *
 * @package    FashionChic
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2016, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */

/**
 * Register footer text strings
 */
$footer_text = get_theme_mod( 'fashionchic-footer-text' ); // Get the data set in customizer
pll_register_string( 'fashionchic-footer-text', $footer_text, 'FashionChic' ); // Register string
