<?php
/**
 * Silver Theme Customizer
 */

// Loads custom control
require trailingslashit( get_template_directory() ) . 'inc/customizer/controls/custom-text.php';

// Loads the customizer settings
require trailingslashit( get_template_directory() ) . 'inc/customizer/featured-posts.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/promo.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/instagram.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/misc.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/colors.php';

/**
 * Custom customizer functions.
 */
function fashionchic_customize_functions( $wp_customize ) {

	// Register new panel: Design
	$wp_customize->add_panel( 'fashionchic_design', array(
		'title'       => esc_html__( 'Design', 'fashionchic' ),
		'description' => esc_html__( 'This panel is used for customizing the design of your site.', 'fashionchic' ),
		'priority'    => 125,
	) );

	// Register new panel: Theme Options
	$wp_customize->add_panel( 'fashionchic_options', array(
		'title'       => esc_html__( 'Theme Options', 'fashionchic' ),
		'description' => esc_html__( 'This panel is used for customizing the Silver theme.', 'fashionchic' ),
		'priority'    => 130,
	) );

	// Live preview of Site Title
	$wp_customize->get_setting( 'blogname' )->transport = 'postMessage';

	// Enable selective refresh to the Site Title
	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'blogname', array(
			'selector'            => '.site-title a',
			'settings'         => array( 'blogname' ),
			'render_callback'  => function() {
				return get_bloginfo( 'name', 'display' );
			}
		) );
	}

	// Move the Colors section.
	$wp_customize->get_section( 'colors' )->panel    = 'fashionchic_design';
	$wp_customize->get_section( 'colors' )->priority = 1;

	// Move the Background Image section.
	$wp_customize->get_section( 'background_image' )->panel    = 'fashionchic_design';
	$wp_customize->get_section( 'background_image' )->priority = 7;

	// Move the Static Front Page section.
	$wp_customize->get_section( 'static_front_page' )->panel    = 'fashionchic_design';
	$wp_customize->get_section( 'static_front_page' )->priority = 9;

	// Move the Additional CSS section.
	$wp_customize->get_section( 'custom_css' )->panel    = 'fashionchic_design';
	$wp_customize->get_section( 'custom_css' )->priority = 11;

	// Move background color to background image section.
	$wp_customize->get_section( 'background_image' )->title = esc_html__( 'Background', 'fashionchic' );
	$wp_customize->get_control( 'background_color' )->section = 'background_image';

}
add_action( 'customize_register', 'fashionchic_customize_functions', 99 );

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function fashionchic_customize_preview_js() {
	wp_enqueue_script( 'fashionchic-customizer', get_template_directory_uri() . '/assets/js/customizer/customizer.js', array( 'customize-preview', 'jquery' ) );
}
add_action( 'customize_preview_init', 'fashionchic_customize_preview_js' );

/**
 * Custom styles.
 */
function fashionchic_custom_css() {

	// Set up empty variable.
	$css = '';

	// Top bar
	$top_bar = get_theme_mod( 'fashionchic-topbar-bg-color', '#ffdfdd' );
	if ( $top_bar != '#ffdfdd' ) {
		$css .= '.site-top { background-color: ' . sanitize_hex_color( $top_bar ) . '; }';
	}

	// Header
	$header = get_theme_mod( 'fashionchic-header-bg-color', '#ffffff' );
	if ( $header != '#ffffff' ) {
		$css .= '.site-branding { background-color: ' . sanitize_hex_color( $header ) . '; }';
	}

	// Menu
	$menu = get_theme_mod( 'fashionchic-menu-bg-color', '#ffffff' );
	if ( $menu != '#ffffff' ) {
		$css .= '.site-navigation { background-color: ' . sanitize_hex_color( $menu ) . '; }';
	}

	// Instagram
	$instagram = get_theme_mod( 'fashionchic-instagram-bg-color', '#000000' );
	if ( $instagram != '#000000' ) {
		$css .= '.site-footer .footer-widget { background-color: ' . sanitize_hex_color( $instagram ) . '; }';
	}

	// Footer
	$footer = get_theme_mod( 'fashionchic-footer-bg-color', '#efefef' );
	if ( $footer != '#efefef' ) {
		$css .= '.site-footer .footer-copyright { background-color: ' . sanitize_hex_color( $footer ) . '; }';
	}

	// Quote
	$quote = get_theme_mod( 'fashionchic-quote-bg-color', '#ffdfdd' );
	if ( $quote != '#ffdfdd' ) {
		$css .= '.is-index .quote-text { background-color: ' . sanitize_hex_color( $quote ) . '; } .is-index .wrapper-quote-text { border-color: ' . sanitize_hex_color( $quote ) . '; }';
	}

	// Text
	$text = get_theme_mod( 'fashionchic-text-color', '#000000' );
	if ( $text != '#000000' ) {
		$css .= '.text-dark, .text-dark a:focus, .text-dark a:hover, .text-dark input[type="search"].search-field { color: ' . sanitize_hex_color( $text ) . '; }';
	}

	// Link
	$link = get_theme_mod( 'fashionchic-link-color', '#ff7e7e' );
	if ( $link != '#ff7e7e' ) {
		$css .= 'a.text-accent, .text-dark .post-text a, .widget a, .widget-footer .text-accent, .back-top i { color: ' . sanitize_hex_color( $link ) . '; }';
	}

	// Promo Box
	$promobox = get_theme_mod( 'fashionchic-promobox-bd-color', '#ffdfdd' );
	if ( $promobox != '#ffdfdd' ) {
		$css .= '.featured-box { border-color: ' . sanitize_hex_color( $promobox ) . '; }';
	}

	// Widget
	$widget = get_theme_mod( 'fashionchic-widget-bd-color', '#efefef' );
	if ( $widget != '#efefef' ) {
		$css .= '.wrapper-aside .widget, .widget-box { border-color: ' . sanitize_hex_color( $widget ) . '; }';
	}

	// Featured posts title color
	$featured_title = get_theme_mod( 'fashionchic-featured-title-color', '#ffffff' );
	if ( $featured_title != '#ffffff' ) {
		$css .= '.slide-text { color: ' . sanitize_hex_color( $featured_title ) . '; }';
	}

	// Featured posts category color
	$featured_category = get_theme_mod( 'fashionchic-featured-category-color', '#ffffff' );
	if ( $featured_category != '#ffffff' ) {
		$css .= '.slide-content small a { color: ' . sanitize_hex_color( $featured_category ) . '; }';
	}

	// Featured posts button text color
	$featured_button = get_theme_mod( 'fashionchic-featured-button-color', '#000000' );
	if ( $featured_button != '#000000' ) {
		$css .= '.slide-content .btn.btn-cta { color: ' . sanitize_hex_color( $featured_button ) . '; }';
	}

	// Featured posts button background color
	$featured_button_bg = get_theme_mod( 'fashionchic-featured-button-bg-color', '#ffffff' );
	if ( $featured_button_bg != '#ffffff' ) {
		$css .= '.slide-content .btn.btn-cta { background-color: ' . sanitize_hex_color( $featured_button_bg ) . '; }';
	}

	// Print the custom style
	wp_add_inline_style( 'fashionchic-style', $css );

}
add_action( 'wp_enqueue_scripts', 'fashionchic_custom_css' );

/**
 * Display theme documentation on customizer page.
 */
function fashionchic_documentation_link() {

	// Enqueue the script
	wp_enqueue_script( 'fashionchic-doc', get_template_directory_uri() . '/assets/js/customizer/doc.js', array(), '1.0.0', true );

	// Localize the script
	wp_localize_script( 'fashionchic-doc', 'prefixL10n',
		array(
			'prefixURL'   => esc_url( 'http://docs.theme-junkie.com/fashionchic/' ),
			'prefixLabel' => esc_html__( 'Documentation', 'fashionchic' ),
		)
	);

}
add_action( 'customize_controls_enqueue_scripts', 'fashionchic_documentation_link' );

/**
 * Custom RSS feed url.
 */
function fashionchic_custom_rss_url( $output, $feed ) {

	// Get the custom rss feed url
	$url = get_theme_mod( 'fashionchic-custom-rss' );

	// Do not redirect comments feed
	if ( strpos( $output, 'comments' ) ) {
		return $output;
	}

	// Check the settings.
	if ( ! empty( $url ) ) {
		$output = esc_url( $url );
	}

	return $output;
}
add_filter( 'feed_link', 'fashionchic_custom_rss_url', 10, 2 );

/**
 * Retrieve tags list.
 */
function fashionchic_tags_list() {

	// Set up empty array.
	$tags = array();

	// Retrieve available tags.
	$tags_obj = get_tags();

	// Set default/empty tag.
	$tags[''] = esc_html__( 'Select a tag &hellip;', 'fashionchic' );

	// Display the tags.
	foreach ( $tags_obj as $tag ) {
		$tags[$tag->term_id] = esc_attr( $tag->name );
	}

	return $tags;

}

/**
 * Sanitize the checkbox.
 *
 * @param boolean $input.
 * @return boolean (true|false).
 */
function fashionchic_sanitize_checkbox( $input ) {
	if ( 1 == $input ) {
		return true;
	} else {
		return false;
	}
}

/**
 * Sanitize the Footer Credits
 */
function fashionchic_sanitize_textarea( $text ) {
	if ( current_user_can( 'unfiltered_html' ) ) {
		$text = $text;
	} else {
		$text = wp_kses_post( $text );
	}
	return $text;
}

/**
 * Sanitize the featured posts order value.
 */
function fashionchic_sanitize_featured_orderby( $order ) {
	if ( ! in_array( $order, array( 'date', 'rand' ) ) ) {
		$order = 'date';
	}
	return $order;
}
