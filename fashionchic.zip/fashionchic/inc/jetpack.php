<?php
/**
 * Jetpack Compatibility File
 * See: http://jetpack.me/
 *
 * @package    FashionChic
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2016, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */

/**
 * Jetpack setup
 *
 * @since  1.0.0
 */
function fashionchic_jetpack_setup() {

	/**
	 * Add theme support for Responsive Videos.
	 */
	add_theme_support( 'jetpack-responsive-videos' );

}
add_action( 'after_setup_theme', 'fashionchic_jetpack_setup' );
