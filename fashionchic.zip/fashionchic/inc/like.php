<?php
/**
 * Modified from ZillaLikes
 * http://www.themezilla.com/plugins/zillalikes/
 *
 * @package    FashionChic
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2015, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */

/**
 * add post meta '_tj_likes'
 */
function fashionchic_setup_likes( $post_id ) {
	if ( ! is_numeric( $post_id ) ) return;

	add_post_meta( $post_id, '_tj_likes', '0', true );
}
add_action( 'publish_post', 'fashionchic_setup_likes' );

/**
 * AJAX callback, to get the refreshed like count
 */
function fashionchic_ajax_callback( $post_id ) {

	if( isset( $_POST['likes_id'] ) ) {
		// Click event. Get and Update Count
		$post_id = str_replace( 'tj-likes-', '', $_POST['likes_id'] );
		echo fashionchic_like_this( $post_id, 'update' );
	} else {
		// AJAXing data in. Get Count
		$post_id = str_replace( 'tj-likes-', '', $_POST['post_id'] );
		echo fashionchic_like_this( $post_id, 'get' );
	}

	exit;
}
add_action('wp_ajax_fashionchic-likes', 'fashionchic_ajax_callback' );
add_action('wp_ajax_nopriv_fashionchic-likes', 'fashionchic_ajax_callback' );

/**
 * get the like count
 */
function fashionchic_like_this( $post_id, $action = 'get' ) {

	if( ! is_numeric( $post_id ) ) return;

	switch( $action ) {

		case 'get':
			$likes = get_post_meta( $post_id, '_tj_likes', true );
			if( ! $likes ){
				$likes = 0;
				add_post_meta( $post_id, '_tj_likes', $likes, true );
			}

			return sprintf( '<span class="left"><i class="fa fa-heart icon"></i>%1$s</span> <span class="like-number left">%2$s</span>',
					esc_html__( 'Like', 'fashionchic' ),
					'('. esc_html( $likes ) .')'
				);
		break;

		case 'update':
			$likes = get_post_meta( $post_id, '_tj_likes', true );
			if( isset( $_COOKIE['tj_likes_'. $post_id] ) ) return $likes;

			$likes++;
			update_post_meta( $post_id, '_tj_likes', $likes );
			setcookie( 'tj_likes_'. $post_id, $post_id, time()*20, '/' );

			return sprintf( '<span class="left"><i class="fa fa-heart icon"></i>%1$s</span> <span class="like-number left">%2$s</span>',
					esc_html__( 'Like', 'fashionchic' ),
					'('. esc_html( $likes ) .')'
				);
		break;

	}
}

/**
 * Template Tag for Like counter
 */
function fashionchic_do_likes() {

	// get the like count
	$output = fashionchic_like_this( get_the_ID() );

	$class = 'entry-like';
	$active_class = 'none';
	$title = esc_html__( 'Like this', 'fashionchic' );

	// check cookie, if user already like
	if( isset( $_COOKIE['tj_likes_'. get_the_ID()] ) ) {
		$active_class = 'active';
		$title = esc_html__( 'You already like this', 'fashionchic' );
	}

	return '<span class="' . esc_attr( $class ) .'"><a href="#" class="' . esc_attr( $active_class ) . '" id="tj-likes-'. get_the_ID() .'" title="'. esc_attr( $title ) . '">' . $output . '</a></span>';
}
