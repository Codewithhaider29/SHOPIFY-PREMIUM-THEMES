<?php
/**
 * TGM Plugin Lists
 *
 * @package    FashionChic
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2016, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */

// Include the TGM_Plugin_Activation class.
require trailingslashit( get_template_directory() ) . 'inc/extensions/class-tgm-plugin-activation.php';

/**
 * Register required and recommended plugins.
 *
 * @since  1.0.0
 */
function fashionchic_register_plugins() {

	$plugins = array(

		array(
			'name'     => 'Contact Form Builder for WordPress – Conversion Tools by HubSpot',
			'slug'     => 'leadin',
			'source'   => trailingslashit( get_template_directory() ) . 'inc/plugins/leadin.zip',
			'required' => false,
		),

		array(
			'name'     => 'One Click Demo Import',
			'slug'     => 'one-click-demo-import',
			'required' => false,
		),

		array(
			'name'     => 'TJ Shortcodes',
			'slug'     => 'theme-junkie-shortcodes',
			'required' => false,
		),

		array(
			'name'     => 'TJ Custom CSS',
			'slug'     => 'theme-junkie-custom-css',
			'required' => false,
		)

	);

	$config = array(
		'id'           => 'tgmpa',
		'default_path' => '',
		'menu'         => 'tgmpa-install-plugins',
		'has_notices'  => true,
		'dismissable'  => true,
		'dismiss_msg'  => '',
		'is_automatic' => false,
		'message'      => '',
	);

	tgmpa( $plugins, $config );

}
add_action( 'tgmpa_register', 'fashionchic_register_plugins' );
