<?php
/**
 * Promo Box Customizer
 */

/**
 * Register the customizer.
 */
function fashionchic_promo_box_customize_register( $wp_customize ) {

	// Register new section: Promo Box
	$wp_customize->add_section( 'fashionchic_promo_box' , array(
		'title'       => esc_html__( 'Promo Box', 'fashionchic' ),
		'panel'       => 'fashionchic_options',
		'priority'    => 3
	) );

	// Register Promo Box 1 setting
	$wp_customize->add_setting( 'fashionchic-promo-box-1', array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr'
	) );
	$wp_customize->add_control( new Fashionchic_Custom_Text( $wp_customize, 'fashionchic-promo-box-1', array(
		'label'             => esc_html__( 'PROMO BOX 1', 'fashionchic' ),
		'section'           => 'fashionchic_promo_box',
		'priority'          => 1
	) ) );

		$wp_customize->add_setting( 'fashionchic-promobox-1-img', array(
			'default'           => '',
			'sanitize_callback' => 'absint'
		) );
		$wp_customize->add_control( new WP_Customize_Media_Control( $wp_customize, 'fashionchic-promobox-1-img', array(
			'label'             => esc_html__( 'Image', 'fashionchic' ),
			'section'           => 'fashionchic_promo_box',
			'priority'          => 2,
			'mime_type'         => 'image',
		) ) );

		$wp_customize->add_setting( 'fashionchic-promobox-1-url', array(
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
		) );
		$wp_customize->add_control( 'fashionchic-promobox-1-url', array(
			'label'             => esc_html__( 'URL', 'fashionchic' ),
			'section'           => 'fashionchic_promo_box',
			'priority'          => 3,
			'type'              => 'url'
		) );

		$wp_customize->add_setting( 'fashionchic-promobox-1-text', array(
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
		) );
		$wp_customize->add_control( 'fashionchic-promobox-1-text', array(
			'label'             => esc_html__( 'Text', 'fashionchic' ),
			'section'           => 'fashionchic_promo_box',
			'priority'          => 4,
			'type'              => 'text'
		) );

	// Register Promo Box 2 setting
	$wp_customize->add_setting( 'fashionchic-promo-box-2', array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr'
	) );
	$wp_customize->add_control( new Fashionchic_Custom_Text( $wp_customize, 'fashionchic-promo-box-2', array(
		'label'             => esc_html__( 'PROMO BOX 2', 'fashionchic' ),
		'section'           => 'fashionchic_promo_box',
		'priority'          => 6
	) ) );

		$wp_customize->add_setting( 'fashionchic-promobox-2-img', array(
			'default'           => '',
			'sanitize_callback' => 'absint'
		) );
		$wp_customize->add_control( new WP_Customize_Media_Control( $wp_customize, 'fashionchic-promobox-2-img', array(
			'label'             => esc_html__( 'Image', 'fashionchic' ),
			'section'           => 'fashionchic_promo_box',
			'priority'          => 7,
			'mime_type'         => 'image',
		) ) );

		$wp_customize->add_setting( 'fashionchic-promobox-2-url', array(
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
		) );
		$wp_customize->add_control( 'fashionchic-promobox-2-url', array(
			'label'             => esc_html__( 'URL', 'fashionchic' ),
			'section'           => 'fashionchic_promo_box',
			'priority'          => 8,
			'type'              => 'url'
		) );

		$wp_customize->add_setting( 'fashionchic-promobox-2-text', array(
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
		) );
		$wp_customize->add_control( 'fashionchic-promobox-2-text', array(
			'label'             => esc_html__( 'Text', 'fashionchic' ),
			'section'           => 'fashionchic_promo_box',
			'priority'          => 9,
			'type'              => 'text'
		) );

	// Register Promo Box 3 setting
	$wp_customize->add_setting( 'fashionchic-promo-box-3', array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr'
	) );
	$wp_customize->add_control( new Fashionchic_Custom_Text( $wp_customize, 'fashionchic-promo-box-3', array(
		'label'             => esc_html__( 'PROMO BOX 3', 'fashionchic' ),
		'section'           => 'fashionchic_promo_box',
		'priority'          => 11
	) ) );

		$wp_customize->add_setting( 'fashionchic-promobox-3-img', array(
			'default'           => '',
			'sanitize_callback' => 'absint'
		) );
		$wp_customize->add_control( new WP_Customize_Media_Control( $wp_customize, 'fashionchic-promobox-3-img', array(
			'label'             => esc_html__( 'Image', 'fashionchic' ),
			'section'           => 'fashionchic_promo_box',
			'priority'          => 12,
			'mime_type'         => 'image',
		) ) );

		$wp_customize->add_setting( 'fashionchic-promobox-3-url', array(
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
		) );
		$wp_customize->add_control( 'fashionchic-promobox-3-url', array(
			'label'             => esc_html__( 'URL', 'fashionchic' ),
			'section'           => 'fashionchic_promo_box',
			'priority'          => 13,
			'type'              => 'url'
		) );

		$wp_customize->add_setting( 'fashionchic-promobox-3-text', array(
			'default'           => '',
			'sanitize_callback' => 'esc_attr',
		) );
		$wp_customize->add_control( 'fashionchic-promobox-3-text', array(
			'label'             => esc_html__( 'Text', 'fashionchic' ),
			'section'           => 'fashionchic_promo_box',
			'priority'          => 14,
			'type'              => 'text'
		) );

}
add_action( 'customize_register', 'fashionchic_promo_box_customize_register' );
