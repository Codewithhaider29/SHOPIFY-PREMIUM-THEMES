<?php
/**
 * Misc Customizer
 */

/**
 * Register the customizer.
 */
function fashionchic_misc_customize_register( $wp_customize ) {

	// Register new section: Misc
	$wp_customize->add_section( 'fashionchic_misc' , array(
		'title'       => esc_html__( 'Misc', 'fashionchic' ),
		'description' => esc_html__( 'These options is used for customizing general elements.', 'fashionchic' ),
		'panel'       => 'fashionchic_options',
		'priority'    => 11
	) );

	// Register Custom RSS setting
	$wp_customize->add_setting( 'fashionchic-custom-rss', array(
		'default'           => '',
		'sanitize_callback' => 'esc_url_raw',
	) );
	$wp_customize->add_control( 'fashionchic-custom-rss', array(
		'label'             => esc_html__( 'Custom RSS', 'fashionchic' ),
		'description'       => esc_html__( 'Custom RSS URL such as Feedburner.', 'fashionchic' ),
		'section'           => 'fashionchic_misc',
		'priority'          => 1,
		'type'              => 'url'
	) );

	// Register page comment setting
	$wp_customize->add_setting( 'fashionchic-page-comment', array(
		'default'           => 1,
		'sanitize_callback' => 'fashionchic_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'fashionchic-page-comment', array(
		'label'             => esc_html__( 'Show page comment', 'fashionchic' ),
		'section'           => 'fashionchic_misc',
		'priority'          => 3,
		'type'              => 'checkbox'
	) );

	// Register Footer Credits setting
	$wp_customize->add_setting( 'fashionchic-footer-text', array(
		'sanitize_callback' => 'fashionchic_sanitize_textarea',
		'default'           => '&copy; Copyright ' . date( 'Y' ) . ' <a href="' . esc_url( home_url() ) . '">' . esc_attr( get_bloginfo( 'name' ) ) . '</a> &middot; Designed by <a href="http://www.theme-junkie.com/">Theme Junkie</a>'
	) );
	$wp_customize->add_control( 'fashionchic-footer-text', array(
		'label'             => esc_html__( 'Footer Text', 'fashionchic' ),
		'section'           => 'fashionchic_misc',
		'priority'          => 5,
		'type'              => 'textarea'
	) );

}
add_action( 'customize_register', 'fashionchic_misc_customize_register' );
