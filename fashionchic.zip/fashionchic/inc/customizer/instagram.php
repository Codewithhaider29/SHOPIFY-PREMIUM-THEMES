<?php
/**
 * Instagram Customizer
 */

/**
 * Register the customizer.
 */
function fashionchic_instagram_customize_register( $wp_customize ) {

	// Register new section: Instagram
	$wp_customize->add_section( 'fashionchic_instagram' , array(
		'title'       => esc_html__( 'Instagram', 'fashionchic' ),
		'description' => esc_html__( 'These options is used for customizing the instagram area at the bottom of your site.', 'fashionchic' ),
		'panel'       => 'fashionchic_options',
		'priority'    => 9
	) );

	// Register instagram token setting
	$wp_customize->add_setting( 'fashionchic-instagram-token', array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	) );
	$wp_customize->add_control( 'fashionchic-instagram-token', array(
		'label'             => esc_html__( 'API Key', 'fashionchic' ),
		'section'           => 'fashionchic_instagram',
		'priority'          => 1,
		'type'              => 'text'
	) );

	// Register instagram username setting
	$wp_customize->add_setting( 'fashionchic-instagram-username', array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	) );
	$wp_customize->add_control( 'fashionchic-instagram-username', array(
		'label'             => esc_html__( 'Username', 'fashionchic' ),
		'section'           => 'fashionchic_instagram',
		'priority'          => 3,
		'type'              => 'text'
	) );

	// Register instagram user id setting
	$wp_customize->add_setting( 'fashionchic-instagram-userid', array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr',
	) );
	$wp_customize->add_control( 'fashionchic-instagram-userid', array(
		'label'             => esc_html__( 'User ID', 'fashionchic' ),
		'section'           => 'fashionchic_instagram',
		'priority'          => 5,
		'type'              => 'text'
	) );

	// Register instagram number of photos to show setting
	$wp_customize->add_setting( 'fashionchic-instagram-limit', array(
		'default'           => 9,
		'sanitize_callback' => 'absint',
	) );
	$wp_customize->add_control( 'fashionchic-instagram-limit', array(
		'label'             => esc_html__( 'User ID', 'fashionchic' ),
		'section'           => 'fashionchic_instagram',
		'priority'          => 7,
		'type'              => 'number',
		'input_attrs'       => array(
			'min'  => 0,
			'step' => 1
		)
	) );

}
add_action( 'customize_register', 'fashionchic_instagram_customize_register' );
