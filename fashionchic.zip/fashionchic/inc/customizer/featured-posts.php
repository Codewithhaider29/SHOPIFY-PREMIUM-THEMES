<?php
/**
 * Featured Posts Customizer
 */

/**
 * Register the customizer.
 */
function fashionchic_featured_posts_customize_register( $wp_customize ) {

	// Register new section: Featured Posts
	$wp_customize->add_section( 'fashionchic_featured_posts' , array(
		'title'       => esc_html__( 'Featured Posts', 'fashionchic' ),
		'description' => esc_html__( 'Featured posts is a posts slider on home page.', 'fashionchic' ),
		'panel'       => 'fashionchic_options',
		'priority'    => 1
	) );

	// Register enable fashionchic setting
	$wp_customize->add_setting( 'fashionchic-featured-enable', array(
		'default'           => 1,
		'sanitize_callback' => 'fashionchic_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'fashionchic-featured-enable', array(
		'label'             => esc_html__( 'Show featured posts', 'fashionchic' ),
		'section'           => 'fashionchic_featured_posts',
		'priority'          => 1,
		'type'              => 'checkbox'
	) );

	// Register tag setting
	$wp_customize->add_setting( 'fashionchic-featured-tag', array(
		'default'           => '',
		'sanitize_callback' => 'absint',
	) );
	$wp_customize->add_control( 'fashionchic-featured-tag', array(
		'label'             => esc_html__( 'Select a tag', 'fashionchic' ),
		'section'           => 'fashionchic_featured_posts',
		'priority'          => 3,
		'type'              => 'select',
		'choices'           => fashionchic_tags_list()
	) );

	// Register number of posts setting
	$wp_customize->add_setting( 'fashionchic-featured-num', array(
		'default'           => 6,
		'sanitize_callback' => 'absint',
	) );
	$wp_customize->add_control( 'fashionchic-featured-num', array(
		'label'             => esc_html__( 'Number of posts', 'fashionchic' ),
		'section'           => 'fashionchic_featured_posts',
		'priority'          => 5,
		'type'              => 'number',
		'input_attrs'       => array(
			'min'  => 0,
			'step' => 1
		)
	) );

	// Register posts order setting
	$wp_customize->add_setting( 'fashionchic-featured-orderby', array(
		'default'           => 'date',
		'sanitize_callback' => 'fashionchic_sanitize_featured_orderby',
	) );
	$wp_customize->add_control( 'fashionchic-featured-orderby', array(
		'label'             => esc_html__( 'Order by', 'fashionchic' ),
		'section'           => 'fashionchic_featured_posts',
		'priority'          => 7,
		'type'              => 'radio',
		'choices'           => array(
			'date'  => esc_html__( 'Date', 'fashionchic' ),
			'rand'  => esc_html__( 'Random', 'fashionchic' )
		)
	) );

	// Register featured posts colors setting
	$wp_customize->add_setting( 'fashionchic-colors', array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr'
	) );
	$wp_customize->add_control( new Fashionchic_Custom_Text( $wp_customize, 'fashionchic-colors', array(
		'label'             => esc_html__( 'COLORS', 'fashionchic' ),
		'section'           => 'fashionchic_featured_posts',
		'priority'          => 9
	) ) );

	// Register featured title color setting
	$wp_customize->add_setting( 'fashionchic-featured-title-color', array(
		'default'           => '#ffffff',
		'sanitize_callback' => 'sanitize_hex_color'
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'fashionchic-featured-title-color', array(
		'label'             => esc_html__( 'Title color', 'fashionchic' ),
		'section'           => 'fashionchic_featured_posts',
		'priority'          => 10
	) ) );

	// Register featured category color setting
	$wp_customize->add_setting( 'fashionchic-featured-category-color', array(
		'default'           => '#ffffff',
		'sanitize_callback' => 'sanitize_hex_color'
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'fashionchic-featured-category-color', array(
		'label'             => esc_html__( 'Category color', 'fashionchic' ),
		'section'           => 'fashionchic_featured_posts',
		'priority'          => 11
	) ) );

	// Register featured button background color setting
	$wp_customize->add_setting( 'fashionchic-featured-button-bg-color', array(
		'default'           => '#ffffff',
		'sanitize_callback' => 'sanitize_hex_color'
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'fashionchic-featured-button-bg-color', array(
		'label'             => esc_html__( 'Button Background Color', 'fashionchic' ),
		'section'           => 'fashionchic_featured_posts',
		'priority'          => 12
	) ) );

	// Register featured button background color setting
	$wp_customize->add_setting( 'fashionchic-featured-button-color', array(
		'default'           => '#000000',
		'sanitize_callback' => 'sanitize_hex_color'
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'fashionchic-featured-button-color', array(
		'label'             => esc_html__( 'Button Color', 'fashionchic' ),
		'section'           => 'fashionchic_featured_posts',
		'priority'          => 13
	) ) );

}
add_action( 'customize_register', 'fashionchic_featured_posts_customize_register' );
