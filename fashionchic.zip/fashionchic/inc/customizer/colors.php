<?php
/**
 * Colors Customizer
 */

/**
 * Register the customizer.
 */
function fashionchic_colors_customize_register( $wp_customize ) {

	// Register background color
	$wp_customize->add_setting( 'fashionchic-background-colors', array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr'
	) );
	$wp_customize->add_control( new Fashionchic_Custom_Text( $wp_customize, 'fashionchic-background-colors', array(
		'label'             => esc_html__( 'Background Colors', 'fashionchic' ),
		'section'           => 'colors',
		'priority'          => 1
	) ) );

		// Register top bar background color setting
		$wp_customize->add_setting( 'fashionchic-topbar-bg-color', array(
			'default'           => '#ffdfdd',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage'
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'fashionchic-topbar-bg-color', array(
			'label'             => esc_html__( 'Top bar', 'fashionchic' ),
			'section'           => 'colors',
			'priority'          => 2
		) ) );

		// Register header background color setting
		$wp_customize->add_setting( 'fashionchic-header-bg-color', array(
			'default'           => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage'
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'fashionchic-header-bg-color', array(
			'label'             => esc_html__( 'Header', 'fashionchic' ),
			'section'           => 'colors',
			'priority'          => 3
		) ) );

		// Register menu background color setting
		$wp_customize->add_setting( 'fashionchic-menu-bg-color', array(
			'default'           => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage'
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'fashionchic-menu-bg-color', array(
			'label'             => esc_html__( 'Menu', 'fashionchic' ),
			'section'           => 'colors',
			'priority'          => 4
		) ) );

		// Register instagram background color setting
		$wp_customize->add_setting( 'fashionchic-instagram-bg-color', array(
			'default'           => '#000000',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage'
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'fashionchic-instagram-bg-color', array(
			'label'             => esc_html__( 'Instagram', 'fashionchic' ),
			'section'           => 'colors',
			'priority'          => 5
		) ) );

		// Register footer background color setting
		$wp_customize->add_setting( 'fashionchic-footer-bg-color', array(
			'default'           => '#efefef',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage'
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'fashionchic-footer-bg-color', array(
			'label'             => esc_html__( 'Footer', 'fashionchic' ),
			'section'           => 'colors',
			'priority'          => 6
		) ) );

		// Register quote format background color setting
		$wp_customize->add_setting( 'fashionchic-quote-bg-color', array(
			'default'           => '#ffdfdd',
			'sanitize_callback' => 'sanitize_hex_color'
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'fashionchic-quote-bg-color', array(
			'label'             => esc_html__( 'Quote Format', 'fashionchic' ),
			'section'           => 'colors',
			'priority'          => 7
		) ) );

	// Register text color
	$wp_customize->add_setting( 'fashionchic-text-colors', array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr'
	) );
	$wp_customize->add_control( new Fashionchic_Custom_Text( $wp_customize, 'fashionchic-text-colors', array(
		'label'             => esc_html__( 'Text Colors', 'fashionchic' ),
		'section'           => 'colors',
		'priority'          => 8
	) ) );

		// Register text color setting
		$wp_customize->add_setting( 'fashionchic-text-color', array(
			'default'           => '#000000',
			'sanitize_callback' => 'sanitize_hex_color'
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'fashionchic-text-color', array(
			'label'             => esc_html__( 'Text color', 'fashionchic' ),
			'section'           => 'colors',
			'priority'          => 9
		) ) );

		// Register link color setting
		$wp_customize->add_setting( 'fashionchic-link-color', array(
			'default'           => '#ff7e7e',
			'sanitize_callback' => 'sanitize_hex_color'
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'fashionchic-link-color', array(
			'label'             => esc_html__( 'Link color', 'fashionchic' ),
			'section'           => 'colors',
			'priority'          => 10
		) ) );

	// Register text color
	$wp_customize->add_setting( 'fashionchic-border-colors', array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr'
	) );
	$wp_customize->add_control( new Fashionchic_Custom_Text( $wp_customize, 'fashionchic-border-colors', array(
		'label'             => esc_html__( 'Border Colors', 'fashionchic' ),
		'section'           => 'colors',
		'priority'          => 11
	) ) );

		// Register text color setting
		$wp_customize->add_setting( 'fashionchic-promobox-bd-color', array(
			'default'           => '#ffdfdd',
			'sanitize_callback' => 'sanitize_hex_color'
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'fashionchic-promobox-bd-color', array(
			'label'             => esc_html__( 'Promo box', 'fashionchic' ),
			'section'           => 'colors',
			'priority'          => 12
		) ) );

		// Register text color setting
		$wp_customize->add_setting( 'fashionchic-widget-bd-color', array(
			'default'           => '#efefef',
			'sanitize_callback' => 'sanitize_hex_color'
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'fashionchic-widget-bd-color', array(
			'label'             => esc_html__( 'Widget', 'fashionchic' ),
			'section'           => 'colors',
			'priority'          => 13
		) ) );

}
add_action( 'customize_register', 'fashionchic_colors_customize_register' );
