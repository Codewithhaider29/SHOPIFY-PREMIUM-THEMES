<?php
/**
 * Custom template tags for this theme.
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package    FashionChic
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2016, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */

if ( ! function_exists( 'fashionchic_site_branding' ) ) :
/**
 * Site branding for the site.
 *
 * Display site title by default, but user can change it with their custom logo.
 * They can upload it on Customizer page.
 *
 * @since  1.0.0
 */
function fashionchic_site_branding() {

	// Get the log.
	$logo_id  = get_theme_mod( 'custom_logo' );
	$logo_url = wp_get_attachment_image_src( $logo_id , 'full' );

	// Check if logo available, then display it.
	if ( $logo_id ) : ?>

		<div class="site-logo container col-xs-11 col-sm-12 text-center island-2">
			<a class="logo block island-1 pad-top" href="<?php echo home_url( '/' ); ?>" rel="home">
				<img class="logo-img hover-fade" src="<?php echo esc_url( $logo_url[0] ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" />
			</a>
			<div class="tagline small sf text-uppercase hidden-xs pad-bottom"><?php bloginfo( 'description' ); ?></div>
		</div>

	<?php
	// If not, then display the Site Title.
	else : ?>
		<div class="site-logo container col-xs-11 col-sm-12 text-center island-2">
			<h1 class="site-title"><a class="logo block island-1 pad-top" href="<?php echo home_url( '/' ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
			<div class="tagline small sf text-uppercase hidden-xs pad-bottom"><?php bloginfo( 'description' ); ?></div>
		</div>

	<?php
	endif;

}
endif;

if ( ! function_exists( 'fashionchic_categorized_blog' ) ) :
/**
 * Returns true if a blog has more than 1 category.
 *
 * @since  1.0.0
 * @return bool
 */
function fashionchic_categorized_blog() {
	if ( false === ( $all_the_cool_cats = get_transient( 'fashionchic_categories' ) ) ) {
		// Create an array of all the categories that are attached to posts.
		$all_the_cool_cats = get_categories( array(
			'fields'     => 'ids',
			'hide_empty' => 1,

			// We only need to know if there is more than one category.
			'number'     => 2,
		) );

		// Count the number of categories that are attached to the posts.
		$all_the_cool_cats = count( $all_the_cool_cats );

		set_transient( 'fashionchic_categories', $all_the_cool_cats );
	}

	if ( $all_the_cool_cats > 1 ) {
		// This blog has more than 1 category so fashionchic_categorized_blog should return true.
		return true;
	} else {
		// This blog has only 1 category so fashionchic_categorized_blog should return false.
		return false;
	}
}
endif;

if ( ! function_exists( 'fashionchic_category_transient_flusher' ) ) :
/**
 * Flush out the transients used in fashionchic_categorized_blog.
 *
 * @since 1.0.0
 */
function fashionchic_category_transient_flusher() {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	// Like, beat it. Dig?
	delete_transient( 'fashionchic_categories' );
}
endif;
add_action( 'edit_category', 'fashionchic_category_transient_flusher' );
add_action( 'save_post',     'fashionchic_category_transient_flusher' );

if ( ! function_exists( 'fashionchic_entry_share' ) ) :
/**
 * Social share.
 *
 * @since 1.0.0
 */
function fashionchic_entry_share() {
	?>
		<div class="page-share text-center island">
			<div class="share-sites vertical-align horizontal-align text-dark">
				<a href="https://twitter.com/intent/tweet?text=<?php echo urlencode( esc_attr( get_the_title( get_the_ID() ) ) ); ?>&amp;url=<?php echo urlencode( get_permalink( get_the_ID() ) ); ?>" target="_blank"><i class="fa fa-twitter icon share-btn"></i><span class="sr-only">Twitter</span></a>
				<a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode( get_permalink( get_the_ID() ) ); ?>" target="_blank"><i class="fa fa-facebook icon share-btn"></i><span class="sr-only">Facebook</span></a>
				<a href="https://plus.google.com/share?url=<?php echo urlencode( get_permalink( get_the_ID() ) ); ?>" target="_blank"><i class="fa fa-google-plus icon share-btn"></i><span class="sr-only">Google+</span></a>
				<a href="https://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo urlencode( get_permalink( get_the_ID() ) ); ?>&amp;title=<?php echo urlencode( esc_attr( get_the_title( get_the_ID() ) ) ); ?>" target="_blank"><i class="fa fa-linkedin icon share-btn"></i><span class="sr-only">LinkedIn</span></a>
				<a href="https://pinterest.com/pin/create/button/?url=<?php echo urlencode( get_permalink( get_the_ID() ) ); ?>&amp;media=<?php echo urlencode( wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) ) ); ?>" target="_blank"><i class="fa fa-pinterest icon share-btn"></i><span class="sr-only">Pinterest</span></a>
				<a href="mailto:?subject=<?php echo esc_url( urlencode( '[' . get_bloginfo( 'name' ) . '] ' . get_the_title( get_the_ID() ) ) ); ?>&amp;body=<?php echo esc_url( urlencode( get_permalink( get_the_ID() ) ) ); ?>"><i class="fa fa-envelope icon share-btn"></i><span class="sr-only">Email</span></a>
			</div>
		</div>
	<?php
}
endif;

if ( ! function_exists( 'fashionchic_post_author_box' ) ) :
/**
 * Author post informations.
 *
 * @since  1.0.0
 */
function fashionchic_post_author_box() {

	// Bail if not on the single post.
	if ( ! is_single() ) {
		return;
	}

	// Bail if user hasn't fill the Biographical Info field.
	if ( ! get_the_author_meta( 'description' ) ) {
		return;
	}

	// Get the author social information.
	$twitter   = get_the_author_meta( 'twitter' );
	$facebook  = get_the_author_meta( 'facebook' );
	$gplus     = get_the_author_meta( 'gplus' );
	$instagram = get_the_author_meta( 'instagram' );
	$pinterest = get_the_author_meta( 'pinterest' );
	$linkedin  = get_the_author_meta( 'linkedin' );
?>

	<div class="author-bio clearfix">
		<?php echo get_avatar( is_email( get_the_author_meta( 'user_email' ) ), apply_filters( 'fashionchic_author_bio_avatar_size', 80 ), '', strip_tags( get_the_author() ) ); ?>
		<div class="description">

			<h3 class="author-title name">
				<a class="author-name url fn n" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" rel="author"><span itemprop="name"><?php echo strip_tags( get_the_author() ); ?></span></a>
			</h3>

			<p class="bio" itemprop="description"><?php echo stripslashes( get_the_author_meta( 'description' ) ); ?></p>

		</div>

		<?php if ( $twitter || $facebook || $gplus || $instagram || $pinterest || $linkedin ) : ?>
			<div class="social-links">
				<?php if ( $twitter ) { ?>
					<a href="//twitter.com/<?php echo esc_attr( $twitter ) ?>"><i class="fa fa-twitter"></i></a>
				<?php } ?>
				<?php if ( $facebook ) { ?>
					<a href="<?php echo esc_url( $facebook ); ?>"><i class="fa fa-facebook"></i></a>
				<?php } ?>
				<?php if ( $gplus ) { ?>
					<a href="<?php echo esc_url( $gplus ); ?>"><i class="fa fa-google-plus"></i></a>
				<?php } ?>
				<?php if ( $instagram ) { ?>
					<a href="<?php echo esc_url( $instagram ); ?>"><i class="fa fa-instagram"></i></a>
				<?php } ?>
				<?php if ( $pinterest ) { ?>
					<a href="<?php echo esc_url( $pinterest ); ?>"><i class="fa fa-pinterest"></i></a>
				<?php } ?>
				<?php if ( $linkedin ) { ?>
					<a href="<?php echo esc_url( $linkedin ); ?>"><i class="fa fa-linkedin"></i></a>
				<?php } ?>
			</div>
		<?php endif; ?>
	</div><!-- .author-bio -->

<?php
}
endif;

if ( ! function_exists( 'fashionchic_comment' ) ) :
/**
 * Template for comments and pingbacks.
 *
 * Used as a callback by wp_list_comments() for displaying the comments.
 *
 * @since  1.0.0
 */
function fashionchic_comment( $comment, $args, $depth ) {
	$GLOBALS['comment'] = $comment;
	switch ( $comment->comment_type ) :
		case 'pingback' :
		case 'trackback' :
		// Display trackbacks differently than normal comments.
	?>
	<li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">
		<article id="comment-<?php comment_ID(); ?>" class="comment-body">
			<p><?php _e( 'Pingback:', 'fashionchic' ); ?> <span><?php comment_author_link(); ?></span> <?php edit_comment_link( __( '(Edit)', 'fashionchic' ), '<span class="edit-link">', '</span>' ); ?></p>
		</article>
	<?php
			break;
		default :
		// Proceed with normal comments.
	?>
	<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
		<article id="comment-<?php comment_ID(); ?>" class="comment-body">

			<footer class="comment-meta">
				<div class="comment-author vcard">
					<?php echo get_avatar( $comment, apply_filters( 'fashionchic_comment_avatar_size', 42 ) ); ?>
					<?php
						printf( '<b class="fn">%1$s</b><span class="says">%2$s</span>',
							get_comment_author_link(),
							esc_html__( ' says:', 'fashionchic' )
						);
					?>
				</div><!-- .comment-author -->

				<div class="comment-metadata meta small text-uppercase sf pad-bottom">
					<?php
						$edit_comment_link = '';
							if ( get_edit_comment_link() )
								$edit_comment_link = sprintf( __( '&middot; %1$sEdit%2$s', 'fashionchic' ), '<a href="' . get_edit_comment_link() . '" title="' . esc_attr__( 'Edit Comment', 'fashionchic' ) . '">', '</a>' );

						printf( '<span class="date"><a href="%1$s"><time datetime="%2$s">%3$s</time></a> %4$s</span>',
							esc_url( get_comment_link( $comment->comment_ID ) ),
							get_comment_time( 'c' ),
							/* translators: 1: date, 2: time */
							sprintf( __( '%1$s at %2$s', 'fashionchic' ), get_comment_date(), get_comment_time() ),
							$edit_comment_link
						);
					?>
				</div><!-- .comment-metadata -->
			</footer><!-- .comment-meta -->

			<div class="comment-content">
				<?php if ( '0' == $comment->comment_approved ) : ?>
					<p class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'fashionchic' ); ?></p>
				<?php endif; ?>
				<?php comment_text(); ?>
				<span class="reply">
					<?php comment_reply_link( array_merge( $args, array( 'reply_text' => __( '<i class="fa fa-reply"></i> Reply', 'fashionchic' ), 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
				</span><!-- .reply -->
			</div><!-- .comment-content -->

		</article><!-- #comment-## -->
	<?php
		break;
	endswitch; // end comment_type check
}
endif;

if ( ! function_exists( 'fashionchic_get_post_format_link_url' ) ) :
/**
 * Forked from hybrid_get_the_post_format_url.
 * Filters 'get_the_post_format_url' to make for a more robust and back-compatible function.  If WP did
 * not find a URL, check the post content for one.  If nothing is found, return the post permalink.
 * Used in Post Format Link
 *
 * @since 1.0.0
 */
function fashionchic_get_post_format_link_url( $url = '', $post = null ) {

	if ( empty( $url ) ) {

		$post = is_null( $post ) ? get_post() : $post;

		/* Catch links that are not wrapped in an '<a>' tag. */
		$content_url = preg_match( '/<a\s[^>]*?href=[\'"](.+?)[\'"]/is', make_clickable( $post->post_content ), $matches );

		$content_url = ! empty( $matches[1] ) ? esc_url_raw( $matches[1] ) : '';

		$url = ! empty( $content_url ) ? $content_url : get_permalink( get_the_ID() );
	}

	if ( $url ) {
	?>
		<h2 class="post-title text-center">
			<?php if ( get_the_title() && ( __( '(Untitled)', 'fashionchic' ) != get_the_title() ) ) { ?>
				<?php the_title(); ?>
			<?php } else { ?>
				<?php echo esc_attr( $url ); ?>
			<?php }	?>
		</h2>
		<div class="link-url pad-bottom">
			<a class="small sf text-uppercase" href="<?php echo esc_url( $url ); ?>"><?php echo esc_url( $url ); ?></a>
		</div>
	<?php
	}

}
endif;

if ( ! function_exists( 'fashionchic_footer_text' ) ) :
/**
 * Footer Text
 *
 * @since  1.0.0
 */
function fashionchic_footer_text() {

	// Get the customizer data
	$default = '&copy; Copyright ' . date( 'Y' ) . ' <a href="' . esc_url( home_url() ) . '">' . esc_attr( get_bloginfo( 'name' ) ) . '</a> &middot; Designed by <a href="http://www.theme-junkie.com/">Theme Junkie</a>';
	$footer_text = get_theme_mod( 'fashionchic-footer-text', $default );

	// Polylang integration
	if ( is_polylang_activated() ) {
		$footer_text = pll__( get_theme_mod( 'fashionchic-footer-text', $default ) );
	}

	// Display the data
	echo '<div class="copyright micro">' . wp_kses_post( $footer_text ) . '</div>';

}
endif;
