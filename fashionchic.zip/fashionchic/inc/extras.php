<?php
/**
 * Custom functions that act independently of the theme templates
 *
 * Eventually, some of the functionality here could be replaced by core features
 *
 * @package    FashionChic
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2016, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */

/**
 * Add a pingback url auto-discovery header for singularly identifiable articles.
 */
function fashionchic_pingback_header() {
	if ( is_singular() && pings_open() ) {
		echo '<link rel="pingback" href="', bloginfo( 'pingback_url' ), '">';
	}
}
add_action( 'wp_head', 'fashionchic_pingback_header' );

/**
 * Adds custom classes to the array of body classes.
 *
 * @since  1.0.0
 * @param  array $classes Classes for the body element.
 * @return array
 */
function fashionchic_body_classes( $classes ) {

	// Adds a class of multi-author to blogs with more than 1 published author.
	if ( is_multi_author() ) {
		$classes[] = 'multi-author';
	}

	// Adds a classes for home page
	if ( is_home() ) {
		$classes[] = 'is-index is-home';
	}

	// Adds a class for archive page
	if ( is_archive() || is_search() ) {
		$classes[] = 'is-index';
	}

	// Adds a classes for single post/page
	if ( is_singular() ) {
		$classes[] = 'is-page is-nothome is-post is-text';
	}

	return $classes;
}
add_filter( 'body_class', 'fashionchic_body_classes' );

/**
 * Adds custom classes to the array of post classes.
 *
 * @since  1.0.0
 * @param  array $classes Classes for the post element.
 * @return array
 */
function fashionchic_post_classes( $classes ) {

	// Adds a class if a post hasn't a thumbnail.
	if ( ! has_post_thumbnail() ) {
		$classes[] = 'no-post-thumbnail';
	}

	// Replace hentry class with entry.
	$classes[] = 'entry';

	return $classes;
}
add_filter( 'post_class', 'fashionchic_post_classes' );

/**
 * Remove 'hentry' from post_class()
 */
function fashionchic_remove_hentry( $class ) {
	$class = array_diff( $class, array( 'hentry' ) );
	return $class;
}
add_filter( 'post_class', 'fashionchic_remove_hentry' );

/**
 * Change the excerpt more string.
 *
 * @since  1.0.0
 * @param  string  $more
 * @return string
 */
function fashionchic_excerpt_more( $more ) {
	return '&hellip;';
}
add_filter( 'excerpt_more', 'fashionchic_excerpt_more' );

/**
 * Add post type 'post' support for the Simple Page Sidebars plugin.
 *
 * @since  1.0.0
 */
function fashionchic_page_sidebar_plugin() {
	if ( class_exists( 'Simple_Page_Sidebars' ) ) {
		add_post_type_support( 'post', 'simple-page-sidebars' );
	}
}
add_action( 'init', 'fashionchic_page_sidebar_plugin' );

/**
 * Register custom contact info fields.
 *
 * @since  1.0.0
 * @param  array $contactmethods
 * @return array
 */
function fashionchic_contact_info_fields( $contactmethods ) {
	$contactmethods['twitter']     = __( 'Twitter URL', 'fashionchic' );
	$contactmethods['facebook']    = __( 'Facebook URL', 'fashionchic' );
	$contactmethods['gplus']       = __( 'Google Plus URL', 'fashionchic' );
	$contactmethods['instagram']   = __( 'Instagram URL', 'fashionchic' );
	$contactmethods['pinterest']   = __( 'Pinterest URL', 'fashionchic' );
	$contactmethods['linkedin']    = __( 'Linkedin URL', 'fashionchic' );

	// Remove default contacts
	unset( $contactmethods['aim'] );
	unset( $contactmethods['jabber'] );
	unset( $contactmethods['yim'] );

	return $contactmethods;
}
add_filter( 'user_contactmethods', 'fashionchic_contact_info_fields' );

/**
 * Extend archive title
 *
 * @since  1.0.0
 */
function fashionchic_extend_archive_title( $title ) {
	if ( is_category() ) {
		$title = single_cat_title( '', false );
	} elseif ( is_tag() ) {
		$title = single_tag_title( '', false );
	} elseif ( is_author() ) {
		$title = get_the_author();
	}
	return $title;
}
add_filter( 'get_the_archive_title', 'fashionchic_extend_archive_title' );

/**
 * Customize tag cloud widget
 *
 * @since  1.0.0
 */
function fashionchic_customize_tag_cloud( $args ) {
	$args['largest']  = 12;
	$args['smallest'] = 12;
	$args['unit']     = 'px';
	$args['number']   = 20;
	return $args;
}
add_filter( 'widget_tag_cloud_args', 'fashionchic_customize_tag_cloud' );

/**
 * Comment form fields
 */
function fashionchic_comment_form_fields( $fields ) {

	$commenter = wp_get_current_commenter();
	$req = get_option( 'require_name_email' );
	$aria_req = ( $req ? " aria-required='true'" : '' );

	$fields['author'] = '<p class="comment-form-author"><label class="t4 text-uppercase block" for="author">' . esc_html__( 'Name', 'fashionchic' ) . ( $req ? '<span class="required">*</span>' : '' ) . '</label>' . '<input id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" size="30"' . $aria_req . ' /></p>';

	$fields['email'] = '<p class="comment-form-email"><label class="t4 text-uppercase block" for="email">' . esc_html__( 'Email', 'fashionchic' ) . ( $req ? '<span class="required">*</span>' : '' ) . '</label>' . '<input id="email" name="email" type="text" value="' . esc_attr( $commenter['comment_author_email'] ) . '" size="30"' . $aria_req . ' /></p>';

	$fields['url'] = '<p class="comment-form-url"><label class="t4 text-uppercase block" for="url">' . esc_html__( 'Website', 'fashionchic' ) . '</label>' . '<input id="url" name="url" type="text" value="' . esc_attr( $commenter['comment_author_url'] ) . '" size="30" /></p>';

	return $fields;

}
add_filter( 'comment_form_default_fields', 'fashionchic_comment_form_fields' );
