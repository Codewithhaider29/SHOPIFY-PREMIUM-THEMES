Within the main folder [themeforest-eliana-shopify-theme.zip] there will be following folder and files.

Documentation
Readme.txt
Log.txt
eliana.zip

-------------------------------------------------------------------
https://themessupport.com/wedesigntech/shopify/eliana/


Kindly refer our documentation for installing the theme and doing customization. 
If you need any assistance, plz contact us through support@wedesignthemes.com


Thank You.
BuddhaThemes.










