Thank you for purchase our theme. 
For more instruction, please read the document in folder /guides
