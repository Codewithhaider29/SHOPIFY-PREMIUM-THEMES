<div class="search-form">
	<form action="<?php echo home_url(); ?>" id="searchform" method="get">
		<input name="s" type="text" value="<?php _e('Search', 'junkie'); ?>" onclick="this.value='';" />
	</form>
</div><!-- .search-form -->