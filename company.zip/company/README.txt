Company WordPress Theme 1.0
http://www.theme-junkie.com/themes/company/

INSTALL: 

1. Log in to the WordPress Administration Panel.
2. Select the Appearance panel, then Themes.
3. Select Install Themes.
4. Click the Upload button to upload the company.zip file that you have previously downloaded to your machine.
5. Activate the theme.

If you are looking for theme support, please visit http://www.theme-junkie.com/forum/

Thanks,
Theme Junkie Team
Http://www.theme-junkie.com