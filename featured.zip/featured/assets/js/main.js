( function( $ ) {

	// Document ready
	$( function() {

		/**
		 * Responsive video
		 */
		$( '.hentry, .widget' ).fitVids();

		/**
		 * Mobile menu
		 */
		$( '#menu-primary-items' ).slicknav( {
			label: featured.menu_label,
			prependTo: '.menu-primary-container',
			allowParentLinks: true
		} );

		/**
		 * Search Toggle
		 */
		var $search = $( '.search-area' );
		$search.on( 'click', '.search-toggle', function( event ) {
			event.preventDefault();
			$search.toggleClass( 'search-open' );
		} );

		/**
		 * Masonry layout for archive page
		 */

		// Set up variable
		var columns,
		    gutter = 30,
		    windowWidth = $( 'body' ).width(),
		    $wrapper = $( '.masonry-wrapper' );

		// Re-set columns based on window width
		if ( windowWidth <= 500 ) {
			columns = 1;
		} else if ( windowWidth <= 1024 ) {
			columns = 2;
		} else {
			columns = 3;

			if ( featured.masonry_2_columns ) {
				columns = 2;
			}
		}

		// Get the column width
		var itemWidth = ( $wrapper.width() - gutter * ( columns - 1 ) ) / columns;

		// Inject the column width
		$( '.masonry-wrapper .entry' ).css( {
			width: itemWidth
		} );

		// Perform the masonry!
		$wrapper.imagesLoaded( function() {
			$wrapper.masonry( {
				itemSelector: '.masonry-wrapper .entry',
				columnWidth: itemWidth,
				gutter: gutter,
				isFitWidth: true
			} );
		} );

		/**
		 * Widget Tabs
		 */
		$( '.tabs-container .tab-content' ).hide();
		$( '.tabs-container .tab-content:first' ).show();
		$( '.tabs-nav li:first' ).addClass( 'active' );

		$( '.tabs-nav li a' ).on( 'click', function( event ) {
			event.preventDefault();
			$( '.tabs-nav li' ).removeClass( 'active' );
			$( this ).parent().addClass( 'active' );
			var currentTab = $( this ).attr( 'href' );
			$( '.tabs-container .tab-content' ).hide();
			$( currentTab ).show();
		} );

		/**
		 * Featured posts
		 */
		$( '.featured-carousel' ).owlCarousel( {
			navText: false,
			responsive: {
				0: {
					items: 1
				},
				760: {
					items: 2
				},
				1024: {
					items: 3
				}
			}
		} );

		/**
		 * Posts like
		 */
		$( '.entry-like a' ).on( 'click',
			function() {
				var link = $( this );
				if ( link.hasClass( 'active' ) ) return false;

				var id = $( this ).attr( 'id' );

				$.post( featured.ajaxurl, {
					action: 'featured-likes',
					likes_id: id
				}, function( data ) {
					link.html( data ).addClass( 'active' ).attr( 'title', featured.rated );
				} );

				return false;
			} );

	} );

}( jQuery ) );
