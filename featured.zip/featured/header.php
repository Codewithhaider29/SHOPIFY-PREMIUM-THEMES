<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">

<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<div id="page" class="site">

	<div class="wide-container">

		<header id="masthead" class="site-header">
			<div class="container">

				<div class="top">

					<?php if ( has_nav_menu ( 'social' ) ) : ?>
						<?php wp_nav_menu(
							array(
								'theme_location'  => 'social',
								'depth'           => 1,
								'link_before'     => '<span class="screen-reader-text">',
								'link_after'      => '</span>',
								'container_class' => 'social-links',
							)
						); ?>
					<?php endif; ?>

					<?php featured_site_branding(); ?>

					<div class="search-area">
						<button class="search-toggle"><i class="fa fa-search"></i></button>
						<div class="search-form">
							<?php get_search_form(); ?>
						</div>
					</div>

				</div>

			</div>
		</header><!-- #masthead -->


		<?php if ( has_nav_menu ( 'primary' ) ) : ?>
			<nav class="main-navigation" id="site-navigation">
				<div class="container">
					<?php wp_nav_menu(
						array(
							'theme_location'  => 'primary',
							'container_class' => 'menu-primary-container',
							'menu_id'         => 'menu-primary-items',
							'menu_class'      => 'menu-primary-items',
							'walker'          => new Featured_Custom_Nav_Walker
						)
					); ?>
					<?php
						$newsletter = get_theme_mod( 'featured_newsletter_link' );
						if ( $newsletter ) :
					?>
						<a href="<?php echo esc_url( $newsletter ); ?>" class="newsletter-link"><i class="fa fa-envelope-o" aria-hidden="true"></i><?php esc_html_e( 'Subscribe', 'featured' ); ?></a>
					<?php endif; ?>
				</div>
			</nav>
		<?php endif; ?>

		<?php if ( !is_singular() ) : ?>
			<div class="page-header">
				<div class="container">
					<?php
						the_archive_title( '<h1 class="page-title">', '</h1>' );
						the_archive_description( '<div class="page-description">', '</div>' );
					?>
				</div>
			</div><!-- .page-header -->
		<?php endif; ?>

		<?php get_template_part( 'partials/content', 'featured' ); ?>

		<div id="content" class="site-content">
			<div class="container">
