<?php
/**
 * Template Name: Home template
 */
get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

			<?php
				$paged = ( get_query_var( 'page' ) ) ? get_query_var( 'page' ) : 1;
				$args = array(
					'post_type'           => 'post',
					'ignore_sticky_posts' => 1,
					'paged'               => $paged
				);

				// Allow dev to filter the query.
				$query = apply_filters( 'featured_home_default_args', $args );

				$wp_query = new WP_Query( $query );
			?>

			<?php if ( $wp_query->have_posts() ) : ?>

				<div class="masonry-wrapper">

					<?php while ( $wp_query->have_posts() ) : $wp_query->the_post(); ?>

						<article id="post-<?php the_ID(); ?>" <?php post_class( 'archive' ); ?>>

							<div class="post-thumbnail thumbnail">
								<?php if ( has_post_thumbnail() ) : ?>
									<a class="thumbnail-link" href="<?php the_permalink(); ?>">
										<?php the_post_thumbnail( 'archive-thumbnail-masonry' ); ?>
									</a>
								<?php endif; ?>

								<?php
									$category = get_the_category( get_the_ID() );
									if ( $category ) :
								?>
									<span class="cat-links">
										<a href="<?php echo esc_url( get_category_link( $category[0]->term_id ) ); ?>"><?php echo esc_attr( $category[0]->name ); ?></a>
									</span>
								<?php endif; // End if category ?>
							</div>

							<div class="post-detail">

								<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>

								<div class="entry-meta">
									<?php featured_entry_meta(); ?>
								</div>

								<div class="entry-summary">
									<?php the_excerpt(); ?>
								</div>

								<span class="more-link-wrapper">
									<a href="<?php the_permalink(); ?>" class="more-link"><?php esc_html_e( 'Read More', 'featured' ); ?></a>
								</span>

							</div>

						</article><!-- #post-## -->


					<?php endwhile; ?>

				</div>

				<?php get_template_part( 'pagination' ); // Loads the pagination.php template  ?>

			<?php else : ?>

				<?php get_template_part( 'partials/content', 'none' ); ?>

			<?php endif; wp_reset_postdata(); ?>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>
