<article id="post-<?php the_ID(); ?>" <?php post_class( 'archive' ); ?>>

	<div class="post-thumbnail thumbnail">
		<?php featured_archive_thumbnail(); ?>

		<?php
			$category = get_the_category( get_the_ID() );
			if ( $category ) :
		?>
			<span class="cat-links">
				<a href="<?php echo esc_url( get_category_link( $category[0]->term_id ) ); ?>"><?php echo esc_attr( $category[0]->name ); ?></a>
			</span>
		<?php endif; // End if category ?>
	</div>

	<div class="post-detail">

		<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>

		<span class="entry-author vcard">
			<?php printf( esc_html__( 'by %s', 'featured' ), '<a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a>' ); ?>
		</span>

		<div class="entry-summary">
			<?php the_excerpt(); ?>
		</div>

		<span class="more-link-wrapper">
			<a href="<?php the_permalink(); ?>" class="more-link"><?php esc_html_e( 'Read More', 'featured' ); ?></a>
		</span>

	</div>

</article><!-- #post-## -->
