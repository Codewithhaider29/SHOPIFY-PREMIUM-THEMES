<?php
// Get the customizer data
$home    = get_theme_mod( 'featured_show_on_home', 1 );
$archive = get_theme_mod( 'featured_show_on_archive', 1 );
$number  = get_theme_mod( 'featured_featured_posts_number', 6 );

// Empty variable
$page = '';

// Show on home page
if ( $home ) {
	$page = ( is_home() || is_front_page() || is_page_template( 'page-templates/home.php' ) || is_page_template( 'page-templates/home-builder.php' ) ) ? true : false;
}

// Show on archive page
if ( $archive ) {
	$page .= ( is_archive() ) ? true : false;
}

// Get the tag id
$name = get_theme_mod( 'featured_featured_posts_tag', 'featured' );
if ( $name ) {
	$term = get_term_by( 'name', $name, 'post_tag' );
}

// Main post query
$query = array(
	'post_type'           => 'post',
	'posts_per_page'      => absint( $number ),
	'ignore_sticky_posts' => 1
);

// Get the sticky post ids
$sticky = get_option( 'sticky_posts' );

// Adds the custom arguments to the main query
if ( $term ) {
	$query['tag_id'] = $term->term_id;
} else {
	$query['post__in'] = $sticky;
}

// Allow dev to filter the query.
$query = apply_filters( 'featured_featured_posts_args', $query );

$featured = new WP_Query( $query );
?>

<?php if ( $featured->have_posts() && $page ) : ?>

	<div class="featured featured-carousel owl-carousel owl-theme">

		<?php while ( $featured->have_posts() ) : $featured->the_post(); ?>

			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

				<div class="post-thumbnail thumbnail">
					<?php if ( has_post_thumbnail() ) : ?>
						<a class="thumbnail-link" href="<?php the_permalink(); ?>">
							<?php the_post_thumbnail( 'featured-thumbnail', array( 'class' => 'entry-thumbnail', 'alt' => esc_attr( get_the_title() ) ) ); ?>
							<span class="overlay"></span>
						</a>
					<?php endif; ?>

					<?php
						$category = get_the_category( get_the_ID() );
						if ( $category ) :
					?>
						<span class="cat-links">
							<a href="<?php echo esc_url( get_category_link( $category[0]->term_id ) ); ?>"><?php echo esc_attr( $category[0]->name ); ?></a>
						</span>
					<?php endif; // End if category ?>

				</div>

				<div class="featured-content">

					<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>

					<div class="featured-meta entry-meta">
						<?php featured_entry_meta(); ?>
					</div>

				</div>

			</article>

		<?php endwhile; ?>

	</div>

<?php endif; wp_reset_postdata(); ?>
