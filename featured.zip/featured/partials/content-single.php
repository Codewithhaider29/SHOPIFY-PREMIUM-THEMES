<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<header class="entry-header">

		<div class="entry-navigation">
			<?php
				$category = get_the_category( get_the_ID() );
				if ( $category ) :
			?>
				<span class="cat-links">
					<a href="<?php echo esc_url( get_category_link( $category[0]->term_id ) ); ?>"><?php echo esc_attr( $category[0]->name ); ?></a>
				</span>
			<?php endif; // End if category ?>

			<?php
				$breadcrumbs = get_theme_mod( 'featured_breadcrumbs_post', 1 );
				if ( $breadcrumbs ) {
					echo breadcrumb_trail( array( 'show_browse' => false ) );
				}
			?>

		</div>

		<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>

	</header>

	<div class="entry-meta-single">
		<span class="entry-author">
			<?php printf( esc_html__( 'by %s', 'featured' ), '<a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '" itemprop="url"><span itemprop="name">' . esc_html( get_the_author() ) . '</span></a>' ) ?>
		</span>
		<time class="entry-date published" datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
		<?php if ( ! post_password_required() && ( comments_open() || '0' != get_comments_number() ) ) : ?>
			<span class="entry-comment">
				<?php comments_popup_link( __( '0 Comment', 'featured' ), __( '1 Comment', 'featured' ), __( '% Comments', 'featured' ) ); ?>
			</span>
		<?php endif; ?>
		<?php echo featured_do_likes(); ?>
		<span class="entry-view"><?php echo entry_views_get( array( 'after' => esc_html__( ' Views', 'featured' ) ) ); ?></span>
	</div>

	<?php featured_entry_share(); ?>

	<?php featured_post_thumbnail(); ?>

	<div class="entry-content">

		<?php the_content(); ?>
		<?php
			wp_link_pages( array(
				'before'           => '<div class="page-links">',
				'after'            => '</div>',
				'next_or_number'   => 'next',
				'nextpagelink'     => esc_html__( 'Next', 'featured' ),
				'previouspagelink' => esc_html__( 'Previous', 'featured' )
			) );
		?>

	</div>

	<footer class="entry-footer">

		<?php
			$tags = get_the_tags();
			if ( $tags ) :
		?>
			<span class="tag-links">
				<?php foreach( $tags as $tag ) : ?>
					<a href="<?php echo esc_url( get_tag_link( $tag->term_id ) ); ?>"><?php echo esc_attr( '#' . $tag->name ); ?></a>
				<?php endforeach; ?>
			</span>
		<?php endif; ?>

	</footer>

</article><!-- #post-## -->
