<?php
// Get the customizer data.
$layout = get_theme_mod( 'featured_archive_layouts', '2c-l' );

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

			<?php if ( have_posts() ) : ?>

				<?php if (
					$layout == '1c-m' ||
					$layout == '2c-l-m' ||
					$layout == '2c-r-m'
				) {
					echo '<div class="masonry-wrapper">';
				} ?>

					<?php while ( have_posts() ) : the_post(); ?>

						<?php if (
							$layout == '1c-g' ||
							$layout == '1c-g-n' ||
							$layout == '2c-l-g' ||
							$layout == '2c-r-g' ||
							$layout == '1c-m' ||
							$layout == '2c-l-m' ||
							$layout == '2c-r-m'
						) : ?>
							<?php get_template_part( 'partials/content', 'grid' ); ?>
						<?php else : ?>
							<?php get_template_part( 'partials/content' ); ?>
						<?php endif; ?>

					<?php endwhile; ?>

				<?php if (
					$layout == '1c-m' ||
					$layout == '2c-l-m' ||
					$layout == '2c-r-m'
				) {
					echo '</div>';
				} ?>

				<?php get_template_part( 'pagination' ); // Loads the pagination.php template  ?>

			<?php else : ?>

				<?php get_template_part( 'partials/content', 'none' ); ?>

			<?php endif; ?>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>
