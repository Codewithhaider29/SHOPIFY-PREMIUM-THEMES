<?php
/**
 * Enqueue scripts and styles.
 *
 * @package    Featured
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2017, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */

/**
 * Loads the theme styles & scripts.
 *
 * @since 1.0.0
 * @link  http://codex.wordpress.org/Function_Reference/wp_enqueue_script
 * @link  http://codex.wordpress.org/Function_Reference/wp_enqueue_style
 */
function featured_enqueue() {

	// Load plugins stylesheet
	wp_enqueue_style( 'featured-plugins-style', trailingslashit( get_template_directory_uri() ) . 'assets/css/plugins.min.css' );

	// Fonts
	wp_enqueue_style( 'featured-fonts', featured_fonts_url() );

	// if WP_DEBUG and/or SCRIPT_DEBUG turned on, load the unminified styles & script.
	if ( ! is_child_theme() && WP_DEBUG || SCRIPT_DEBUG ) {

		// Load main stylesheet
		wp_enqueue_style( 'featured-style', get_stylesheet_uri() );

		// Load custom js plugins.
		wp_enqueue_script( 'featured-plugins', trailingslashit( get_template_directory_uri() ) . 'assets/js/plugins.min.js', array( 'jquery', 'masonry' ), null, true );

		// Load custom js methods.
		wp_enqueue_script( 'featured-main', trailingslashit( get_template_directory_uri() ) . 'assets/js/main.js', array( 'jquery', 'masonry' ), null, true );

		$script_handle = 'featured-main';

	} else {

		// Load main stylesheet
		wp_enqueue_style( 'featured-style', trailingslashit( get_template_directory_uri() ) . 'style.min.css' );

		// Load custom js plugins.
		wp_enqueue_script( 'featured-scripts', trailingslashit( get_template_directory_uri() ) . 'assets/js/featured.min.js', array( 'jquery', 'masonry' ), null, true );

		$script_handle = 'featured-scripts';

	}

	// Get the class
	$classes = get_body_class();

	// Pass var to js
	wp_localize_script( $script_handle, 'featured',
		array(
			'site_url'          => trailingslashit( get_template_directory_uri() ),
			'ajaxurl'           => admin_url( 'admin-ajax.php' ),
			'rated'             => esc_html__( 'You already like this', 'featured' ),
			'menu_label'        => esc_html__( 'Menu', 'featured' ),
			'masonry_2_columns' => ( in_array( 'layout-2c-l-m', $classes ) ) || ( in_array( 'layout-2c-r-m', $classes ) ) ? true : false,
		)
	);

	// If child theme is active, load the stylesheet.
	if ( is_child_theme() ) {
		wp_enqueue_style( 'featured-child-style', get_stylesheet_uri() );
	}

	// Load comment-reply script.
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	// Loads HTML5 Shiv
	wp_enqueue_script( 'featured-html5', trailingslashit( get_template_directory_uri() ) . 'assets/js/html5shiv.min.js', array( 'jquery' ), null, false );
	wp_script_add_data( 'featured-html5', 'conditional', 'lte IE 9' );

}
add_action( 'wp_enqueue_scripts', 'featured_enqueue' );

/**
 * Enable sticky menu
 */
function featured_sticky_menu() {

	// Get the customizer data
	$enable = get_theme_mod( 'featured_sticky_menu', 1 );

	if ( $enable ) {
		?>
		<script type="text/javascript">
			( function( $ ) {
				$( function() {
					$( '.main-navigation' ).scrollToFixed( {
						minWidth: 768
					} );
				} );
			}( jQuery ) );
		</script>
		<?php
	}

}
add_action( 'wp_footer', 'featured_sticky_menu', 10 );

/**
 * Enable sticky sidebar
 */
function featured_sticky_sidebar() {

	// Get the customizer data
	$enable = get_theme_mod( 'featured_sticky_sidebar', 1 );

	if ( $enable ) {
		?>
		<script type="text/javascript">
			( function( $ ) {
				$( function() {
					$( '.widget-area' ).theiaStickySidebar( {
						additionalMarginTop: 30
					} );
				} );
			}( jQuery ) );
		</script>
		<?php
	}

}
add_action( 'wp_footer', 'featured_sticky_sidebar', 15 );
