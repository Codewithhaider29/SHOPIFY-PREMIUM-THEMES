<?php
/**
 * Fonts Customizer
 */

/**
 * Register the customizer.
 */
function featured_fonts_customize_register( $wp_customize ) {

	// Register new section: Fonts
	$wp_customize->add_section( 'featured_fonts' , array(
		'title'       => esc_html__( 'Fonts', 'featured' ),
		'description' => esc_html__( 'These options is used for customizing the fonts. The Google Fonts can be found here: https://fonts.google.com/.', 'featured' ),
		'panel'       => 'featured_design',
		'priority'    => 3
	) );

	// Register heading custom text.
	$wp_customize->add_setting( 'featured_heading_font_title', array(
		'sanitize_callback' => 'esc_attr'
	) );
	$wp_customize->add_control( new Featured_Custom_Text( $wp_customize, 'featured_heading_font_title', array(
		'label'             => esc_html__( 'Heading', 'featured' ),
		'section'           => 'featured_fonts',
		'priority'          => 2
	) ) );

	// Register heading font setting.
	$wp_customize->add_setting( 'featured_heading_font', array(
		'default'           => 'Playfair+Display:400,700,900',
		'sanitize_callback' => 'wp_kses_post',
	) );
	$wp_customize->add_control( 'featured_heading_font', array(
		'description'       => esc_html__( 'Font name/style/sets', 'featured' ),
		'section'           => 'featured_fonts',
		'priority'          => 3,
		'type'              => 'text'
	) );

	// Register heading font family setting.
	$wp_customize->add_setting( 'featured_heading_font_family', array(
		'default'           => '\'Playfair Display\', serif',
		'sanitize_callback' => 'wp_kses_post',
	) );
	$wp_customize->add_control( 'featured_heading_font_family', array(
		'description'       => esc_html__( 'Font family', 'featured' ),
		'section'           => 'featured_fonts',
		'priority'          => 4,
		'type'              => 'text'
	) );

	// Register body custom text.
	$wp_customize->add_setting( 'featured_body_font_title', array(
		'sanitize_callback' => 'esc_attr'
	) );
	$wp_customize->add_control( new Featured_Custom_Text( $wp_customize, 'featured_body_font_title', array(
		'label'             => esc_html__( 'Body', 'featured' ),
		'section'           => 'featured_fonts',
		'priority'          => 5
	) ) );

	// Register body font setting.
	$wp_customize->add_setting( 'featured_body_font', array(
		'default'           => '',
		'sanitize_callback' => 'wp_kses_post',
	) );
	$wp_customize->add_control( 'featured_body_font', array(
		'description'       => esc_html__( 'Font name/style/sets', 'featured' ),
		'section'           => 'featured_fonts',
		'priority'          => 6,
		'type'              => 'text'
	) );

	// Register body font family setting.
	$wp_customize->add_setting( 'featured_body_font_family', array(
		'default'           => 'Georgia, Palatino, \'Palatino Linotype\', Times, \'Times New Roman\', serif',
		'sanitize_callback' => 'wp_kses_post',
	) );
	$wp_customize->add_control( 'featured_body_font_family', array(
		'description'       => esc_html__( 'Font family', 'featured' ),
		'section'           => 'featured_fonts',
		'priority'          => 7,
		'type'              => 'text'
	) );

	// Register secondary custom text.
	$wp_customize->add_setting( 'featured_secondary_font_title', array(
		'sanitize_callback' => 'esc_attr'
	) );
	$wp_customize->add_control( new Featured_Custom_Text( $wp_customize, 'featured_secondary_font_title', array(
		'label'             => esc_html__( 'Secondary', 'featured' ),
		'section'           => 'featured_fonts',
		'priority'          => 8
	) ) );

	// Register secondary font setting.
	$wp_customize->add_setting( 'featured_secondary_font', array(
		'default'           => 'Montserrat:400,700',
		'sanitize_callback' => 'wp_kses_post',
	) );
	$wp_customize->add_control( 'featured_secondary_font', array(
		'description'       => esc_html__( 'Font name/style/sets', 'featured' ),
		'section'           => 'featured_fonts',
		'priority'          => 9,
		'type'              => 'text'
	) );

	// Register secondary font family setting.
	$wp_customize->add_setting( 'featured_secondary_font_family', array(
		'default'           => '\'Montserrat\', sans-serif',
		'sanitize_callback' => 'wp_kses_post',
	) );
	$wp_customize->add_control( 'featured_secondary_font_family', array(
		'description'       => esc_html__( 'Font family', 'featured' ),
		'section'           => 'featured_fonts',
		'priority'          => 10,
		'type'              => 'text'
	) );

}
add_action( 'customize_register', 'featured_fonts_customize_register' );
