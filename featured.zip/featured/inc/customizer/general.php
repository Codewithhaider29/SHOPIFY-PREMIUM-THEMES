<?php
/**
 * General Customizer
 */

/**
 * Register the customizer.
 */
function featured_general_customize_register( $wp_customize ) {

	// Register new section: General
	$wp_customize->add_section( 'featured_general' , array(
		'title'    => esc_html__( 'General', 'featured' ),
		'panel'    => 'featured_options',
		'priority' => 1
	) );

	// Register container setting
	$wp_customize->add_setting( 'featured_container_style', array(
		'default'           => 'fullwidth',
		'sanitize_callback' => 'featured_sanitize_container_style',
	) );
	$wp_customize->add_control( 'featured_container_style', array(
		'label'             => esc_html__( 'Container', 'featured' ),
		'section'           => 'featured_general',
		'priority'          => 1,
		'type'              => 'radio',
		'choices'           => array(
			'fullwidth' => esc_html__( 'Full Width', 'featured' ),
			'boxed'     => esc_html__( 'Boxed', 'featured' ),
			'framed'    => esc_html__( 'Framed', 'featured' )
		)
	) );

	// Register pagination setting
	$wp_customize->add_setting( 'featured_posts_pagination', array(
		'default'           => 'number',
		'sanitize_callback' => 'featured_sanitize_posts_pagination',
	) );
	$wp_customize->add_control( 'featured_posts_pagination', array(
		'label'             => esc_html__( 'Pagination type', 'featured' ),
		'section'           => 'featured_general',
		'priority'          => 3,
		'type'              => 'radio',
		'choices'           => array(
			'number'      => esc_html__( 'Number', 'featured' ),
			'traditional' => esc_html__( 'Older / Newer', 'featured' )
		)
	) );

	// Register newsletter link setting
	$wp_customize->add_setting( 'featured_newsletter_link', array(
		'default'           => '',
		'sanitize_callback' => 'esc_url_raw',
	) );
	$wp_customize->add_control( 'featured_newsletter_link', array(
		'label'             => esc_html__( 'Newsletter URL', 'featured' ),
		'description'       => esc_html__( 'A subscribe text will appear at the top of your site.', 'featured' ),
		'section'           => 'featured_general',
		'priority'          => 5,
		'type'              => 'url'
	) );

	// Register sticky menu setting
	$wp_customize->add_setting( 'featured_sticky_menu', array(
		'default'           => 1,
		'sanitize_callback' => 'featured_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'featured_sticky_menu', array(
		'label'             => esc_html__( 'Enable sticky menu', 'featured' ),
		'section'           => 'featured_general',
		'priority'          => 7,
		'type'              => 'checkbox'
	) );

	// Register sticky sidebar setting
	$wp_customize->add_setting( 'featured_sticky_sidebar', array(
		'default'           => 1,
		'sanitize_callback' => 'featured_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'featured_sticky_sidebar', array(
		'label'             => esc_html__( 'Enable sticky sidebar', 'featured' ),
		'section'           => 'featured_general',
		'priority'          => 9,
		'type'              => 'checkbox'
	) );

}
add_action( 'customize_register', 'featured_general_customize_register' );
