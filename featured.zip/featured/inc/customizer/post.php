<?php
/**
 * Post Customizer
 */

/**
 * Register the customizer.
 */
function featured_post_customize_register( $wp_customize ) {

	// Register new section: Post
	$wp_customize->add_section( 'featured_post' , array(
		'title'       => esc_html__( 'Post', 'featured' ),
		'description' => esc_html__( 'These options is used for customizing the single post.', 'featured' ),
		'panel'       => 'featured_options',
		'priority'    => 5
	) );

	// Register Post comment manager setting
	$wp_customize->add_setting( 'featured_post_comment', array(
		'default'           => 1,
		'sanitize_callback' => 'featured_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'featured_post_comment', array(
		'label'             => esc_html__( 'Enable comment on Posts', 'featured' ),
		'section'           => 'featured_post',
		'priority'          => 1,
		'type'              => 'checkbox'
	) );

	// Register Author Box setting
	$wp_customize->add_setting( 'featured_author_box', array(
		'default'           => 1,
		'sanitize_callback' => 'featured_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'featured_author_box', array(
		'label'             => esc_html__( 'Show author box', 'featured' ),
		'section'           => 'featured_post',
		'priority'          => 3,
		'type'              => 'checkbox'
	) );

	// Register Next & Prev post setting
	$wp_customize->add_setting( 'featured_next_prev_post', array(
		'default'           => 1,
		'sanitize_callback' => 'featured_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'featured_next_prev_post', array(
		'label'             => esc_html__( 'Show next & prev post', 'featured' ),
		'section'           => 'featured_post',
		'priority'          => 5,
		'type'              => 'checkbox'
	) );

	// Register Post Share setting
	$wp_customize->add_setting( 'featured_post_share', array(
		'default'           => 1,
		'sanitize_callback' => 'featured_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'featured_post_share', array(
		'label'             => esc_html__( 'Show share buttons', 'featured' ),
		'section'           => 'featured_post',
		'priority'          => 7,
		'type'              => 'checkbox'
	) );

	// Register Related Posts setting
	$wp_customize->add_setting( 'featured_related_posts', array(
		'default'           => 1,
		'sanitize_callback' => 'featured_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'featured_related_posts', array(
		'label'             => esc_html__( 'Show related posts', 'featured' ),
		'section'           => 'featured_post',
		'priority'          => 9,
		'type'              => 'checkbox'
	) );

	// Register breadcrumbs setting
	$wp_customize->add_setting( 'featured_breadcrumbs_post', array(
		'default'           => 1,
		'sanitize_callback' => 'featured_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'featured_breadcrumbs_post', array(
		'label'             => esc_html__( 'Show breadcrumbs', 'featured' ),
		'section'           => 'featured_post',
		'priority'          => 11,
		'type'              => 'checkbox'
	) );

}
add_action( 'customize_register', 'featured_post_customize_register' );
