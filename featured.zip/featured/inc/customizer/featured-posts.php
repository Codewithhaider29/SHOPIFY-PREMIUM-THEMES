<?php
/**
 * Featured Posts Customizer
 */

/**
 * Register the customizer.
 */
function featured_featured_posts_customize_register( $wp_customize ) {

	// Register new section: Featured Posts
	$wp_customize->add_section( 'featured_featured_posts' , array(
		'title'       => esc_html__( 'Featured Posts', 'featured' ),
		'description'    => sprintf( __( 'Use a <a href="%1$s">tag</a> to feature your posts. If no posts match the tag, <a href="%2$s">sticky posts</a> will be displayed instead.', 'featured' ),
				esc_url( add_query_arg( 'tag', _x( 'featured', 'featured content default tag slug', 'featured' ), admin_url( 'edit.php' ) ) ),
				admin_url( 'edit.php?show_sticky=1' )
			),
		'panel'       => 'featured_options',
		'priority'    => 9
	) );

	// Register enable featured posts on home page setting
	$wp_customize->add_setting( 'featured_show_on_home', array(
		'default'           => 1,
		'sanitize_callback' => 'featured_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'featured_show_on_home', array(
		'label'             => esc_html__( 'Show featured posts on home page', 'featured' ),
		'section'           => 'featured_featured_posts',
		'priority'          => 1,
		'type'              => 'checkbox'
	) );

	// Register enable featured posts on archive setting
	$wp_customize->add_setting( 'featured_show_on_archive', array(
		'default'           => 1,
		'sanitize_callback' => 'featured_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'featured_show_on_archive', array(
		'label'             => esc_html__( 'Show featured posts on archive page', 'featured' ),
		'section'           => 'featured_featured_posts',
		'priority'          => 3,
		'type'              => 'checkbox'
	) );

	// Register tag name setting
	$wp_customize->add_setting( 'featured_featured_posts_tag', array(
		'default'           => 'featured',
		'sanitize_callback' => 'esc_attr',
	) );
	$wp_customize->add_control( 'featured_featured_posts_tag', array(
		'label'             => esc_html__( 'Tag name', 'featured' ),
		'section'           => 'featured_featured_posts',
		'priority'          => 5,
		'type'              => 'text'
	) );

	// Register number of posts setting
	$wp_customize->add_setting( 'featured_featured_posts_number', array(
		'default'           => 6,
		'sanitize_callback' => 'absint',
	) );
	$wp_customize->add_control( 'featured_featured_posts_number', array(
		'label'             => esc_html__( 'Number of posts', 'featured' ),
		'section'           => 'featured_featured_posts',
		'priority'          => 7,
		'type'              => 'number',
		'input_attrs'       => array(
			'min'  => 0,
			'step' => 1
		)
	) );

}
add_action( 'customize_register', 'featured_featured_posts_customize_register' );
