<?php
/**
 * Page Customizer
 */

/**
 * Register the customizer.
 */
function featured_page_customize_register( $wp_customize ) {

	// Register new section: Page
	$wp_customize->add_section( 'featured_page' , array(
		'title'    => esc_html__( 'Page', 'featured' ),
		'panel'    => 'featured_options',
		'priority' => 7
	) );

	// Register Page comment manager setting
	$wp_customize->add_setting( 'featured_page_comment', array(
		'default'           => 1,
		'sanitize_callback' => 'featured_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'featured_page_comment', array(
		'label'             => esc_html__( 'Enable comment on Pages', 'featured' ),
		'section'           => 'featured_page',
		'priority'          => 1,
		'type'              => 'checkbox'
	) );

	// Register Page title setting
	$wp_customize->add_setting( 'featured_page_title', array(
		'default'           => 1,
		'sanitize_callback' => 'featured_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'featured_page_title', array(
		'label'             => esc_html__( 'Show page title', 'featured' ),
		'section'           => 'featured_page',
		'priority'          => 3,
		'type'              => 'checkbox'
	) );

	// Register Page featured image setting
	$wp_customize->add_setting( 'featured_page_featured_image', array(
		'default'           => 0,
		'sanitize_callback' => 'featured_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'featured_page_featured_image', array(
		'label'             => esc_html__( 'Show page featured image', 'featured' ),
		'section'           => 'featured_page',
		'priority'          => 5,
		'type'              => 'checkbox'
	) );

}
add_action( 'customize_register', 'featured_page_customize_register' );
