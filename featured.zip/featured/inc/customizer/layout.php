<?php
/**
 * Archive Layouts Customizer
 */

/**
 * Register the customizer.
 */
function featured_archive_layouts_customize_register( $wp_customize ) {

	// Register archive layout setting
	$wp_customize->add_setting( 'featured_archive_layouts', array(
		'default'           => '2c-l',
		'sanitize_callback' => 'featured_sanitize_archive_layouts',
	) );
	$wp_customize->add_control( 'featured_archive_layouts', array(
		'label'             => esc_html__( 'Archive Layouts', 'featured' ),
		'section'           => 'layout',
		'priority'          => 5,
		'type'              => 'radio',
		'choices'           => array(
			'1c'     => esc_html__( 'List Full Width', 'featured' ),
			'1c-n'   => esc_html__( 'List Full Width Narrow', 'featured' ),
			'2c-l'   => esc_html__( 'List Right Sidebar (Default)', 'featured' ),
			'2c-r'   => esc_html__( 'List Left Sidebar', 'featured' ),
			'1c-g'   => esc_html__( 'Grid 3 Columns No Sidebar', 'featured' ),
			'1c-g-n' => esc_html__( 'Grid 2 Columns No Sidebar', 'featured' ),
			'2c-l-g' => esc_html__( 'Grid Right Sidebar', 'featured' ),
			'2c-r-g' => esc_html__( 'Grid Left Sidebar', 'featured' ),
			'1c-m'   => esc_html__( 'Masonry 3 Columns No Sidebar', 'featured' ),
			'2c-l-m' => esc_html__( 'Masonry Right Sidebar', 'featured' ),
			'2c-r-m' => esc_html__( 'Masonry Left Sidebar', 'featured' ),
		)
	) );

}
add_action( 'customize_register', 'featured_archive_layouts_customize_register' );
