<?php
/**
 * Colors Customizer
 */

/**
 * Register the customizer.
 */
function featured_colors_customize_register( $wp_customize ) {

	// Register accent color setting
	$wp_customize->add_setting( 'featured_accent_color', array(
		'default'           => '#e60000',
		'sanitize_callback' => 'sanitize_hex_color'
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'featured_accent_color', array(
		'label'             => esc_html__( 'Accent Color', 'featured' ),
		'section'           => 'colors',
		'priority'          => 1
	) ) );

}
add_action( 'customize_register', 'featured_colors_customize_register' );
