<?php
/**
 * Footer Customizer
 */

/**
 * Register the customizer.
 */
function featured_footer_customize_register( $wp_customize ) {

	// Register new section: Footer
	$wp_customize->add_section( 'featured_footer' , array(
		'title'    => esc_html__( 'Footer', 'featured' ),
		'panel'    => 'featured_options',
		'priority' => 11
	) );

	// Register accent color setting
	$wp_customize->add_setting( 'featured_footer_bg', array(
		'default'           => '#f5f5f5',
		'sanitize_callback' => 'sanitize_hex_color',
		'transport'         => 'postMessage'
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'featured_footer_bg', array(
		'label'             => esc_html__( 'Background Color', 'featured' ),
		'section'           => 'featured_footer',
		'priority'          => 1
	) ) );

	// Register footer widget column setting
	$wp_customize->add_setting( 'featured_footer_widget_column', array(
		'default'           => '6',
		'sanitize_callback' => 'featured_sanitize_footer_widget_column',
	) );
	$wp_customize->add_control( 'featured_footer_widget_column', array(
		'label'             => esc_html__( 'Footer Widget Column', 'featured' ),
		'section'           => 'featured_footer',
		'priority'          => 3,
		'type'              => 'radio',
		'choices'           => array(
			'3' => esc_html__( '3 Columns', 'featured' ),
			'4' => esc_html__( '4 Columns', 'featured' ),
			'6' => esc_html__( '6 Columns', 'featured' )
		)
	) );

	// Register Footer Credits setting
	$wp_customize->add_setting( 'featured_footer_credits', array(
		'sanitize_callback' => 'featured_sanitize_textarea',
		'default'           => '&copy; Copyright ' . date( 'Y' ) . ' <a href="' . esc_url( home_url() ) . '">' . esc_attr( get_bloginfo( 'name' ) ) . '</a> &middot; Designed and Developed by <a href="http://www.theme-junkie.com/">Theme Junkie</a>',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'featured_footer_credits', array(
		'label'             => esc_html__( 'Footer Text', 'featured' ),
		'section'           => 'featured_footer',
		'priority'          => 5,
		'type'              => 'textarea'
	) );
	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'featured_footer_credits', array(
			'selector'         => '.copyright',
			'settings'         => array( 'featured_footer_credits' ),
			'render_callback'  => function() {
				return featured_sanitize_textarea( get_theme_mod( 'featured_footer_credits' ) );
			}
		) );
	}

}
add_action( 'customize_register', 'featured_footer_customize_register' );
