<?php
/**
 * Block three
 *
 * @package    Featured
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2017, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */
class Featured_Block_Three_Builder extends WP_Widget {

	/**
	 * Sets up the widgets.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {

		// Set up the widget options.
		$widget_options = array(
			'classname'   => 'featured_block_three',
			'description' => esc_html__( 'Block three', 'featured' )
		);

		// Create the widget.
		parent::__construct(
			'featured-block-three',                  // $this->id_base
			esc_html__( 'Block Three', 'featured' ), // $this->name
			$widget_options                          // $this->widget_options
		);

		$this->alt_option_name = 'featured_block_three';
	}

	/**
	 * Outputs the widget based on the arguments input through the widget controls.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current Recent Posts widget instance.
	 */
	public function widget( $args, $instance ) {
		if ( ! isset( $args['widget_id'] ) ) {
			$args['widget_id'] = $this->id;
		}

		// Set up default value
		$title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : '';
		$tag   = ( ! empty( $instance['tag'] ) ) ? $instance['tag'] : '';
		$num   = ( ! empty( $instance['number'] ) ) ? intval( $instance['number'] ) : 5;
		if ( ! $num ) {
			$num = 5;
		}

		// Output the theme's $before_widget wrapper.
		echo $args['before_widget'];

			// If the title not empty, display it.
			if ( $instance['title'] ) {
				echo '<div class="widget-title builder-title"><span>' . $instance['title'] . '</span></div>';
			}

			// Posts query arguments.
			$query_args = array(
				'posts_per_page' => $num,
				'post_type'      => 'post',
			);

			// Get the tag name
			if ( $tag ) {
				$term = get_term_by( 'name', $tag, 'post_tag' );

				// Adds the tag to the main query
				if ( $term ) {
					$query_args['tag_id'] = $term->term_id;
				}
			}

			// The post query
			$blockthree = new WP_Query( $query_args );

			if ( $blockthree->have_posts() ) : ?>

				<div class="block-three featured-builder">

					<?php while ( $blockthree->have_posts() ) : $blockthree->the_post(); ?>

						<?php get_template_part( 'partials/content' ); ?>

					<?php endwhile; ?>

				</div>

			<?php endif;

		// Close the theme's widget wrapper.
		echo $args['after_widget'];

	}

	/**
	 * Updates the widget control options for the particular instance of the widget.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Updated settings to save.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance           = $old_instance;
		$instance['title']  = sanitize_text_field( $new_instance['title'] );
		$instance['tag']    = sanitize_text_field( $new_instance['tag'] );
		$instance['number'] = (int) $new_instance['number'];
		return $instance;
	}

	/**
	 * Displays the widget control options in the Widgets admin screen.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		$title = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
		$tag   = isset( $instance['tag'] ) ? esc_attr( $instance['tag'] ) : '';
		$num   = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
	?>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>">
				<?php esc_html_e( 'Title', 'featured' ); ?>
			</label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $title; ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'tag' ); ?>">
				<?php esc_html_e( 'Tag name', 'featured' ); ?>
			</label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'tag' ); ?>" name="<?php echo $this->get_field_name( 'tag' ); ?>" value="<?php echo $tag; ?>" />
			<small><?php esc_html_e( 'If you leave it empty, you will see latest posts instead.', 'featured' ) ?></small>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'number' ); ?>"><?php esc_html_e( 'Number of posts to show:', 'featured' ); ?></label>
			<input class="tiny-text" id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" type="number" step="1" min="1" value="<?php echo $num; ?>" size="3" />
		</p>

	<?php

	}

}
