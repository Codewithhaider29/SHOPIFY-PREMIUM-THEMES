<?php
/**
 * Block four
 *
 * @package    Featured
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2017, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */
class Featured_Block_Four_Builder extends WP_Widget {

	/**
	 * Sets up the widgets.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {

		// Set up the widget options.
		$widget_options = array(
			'classname'   => 'featured_block_four',
			'description' => esc_html__( 'Block four', 'featured' )
		);

		// Create the widget.
		parent::__construct(
			'featured-block-four',                   // $this->id_base
			esc_html__( 'Block Four', 'featured' ), // $this->name
			$widget_options                         // $this->widget_options
		);

		$this->alt_option_name = 'featured_block_four';
	}

	/**
	 * Outputs the widget based on the arguments input through the widget controls.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current Recent Posts widget instance.
	 */
	public function widget( $args, $instance ) {
		if ( ! isset( $args['widget_id'] ) ) {
			$args['widget_id'] = $this->id;
		}

		// Set up default value
		$title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : '';
		$tag   = ( ! empty( $instance['tag'] ) ) ? $instance['tag'] : '';

		// Output the theme's $before_widget wrapper.
		echo $args['before_widget'];

			// If the title not empty, display it.
			if ( $instance['title'] ) {
				echo '<div class="widget-title builder-title"><span>' . $instance['title'] . '</span></div>';
			}

			// Posts query arguments.
			$query_args = array(
				'posts_per_page' => 5,
				'post_type'      => 'post',
			);

			// Get the tag name
			if ( $tag ) {
				$term = get_term_by( 'name', $tag, 'post_tag' );

				// Adds the tag to the main query
				if ( $term ) {
					$query_args['tag_id'] = $term->term_id;
				}
			}

			// The post query
			$blockfour = new WP_Query( $query_args );

			if ( $blockfour->have_posts() ) : ?>

				<div class="block-four featured-builder">

					<?php while ( $blockfour->have_posts() ) : $blockfour->the_post(); ?>

						<?php if ( 0 === $blockfour->current_post ) : ?>

							<?php get_template_part( 'partials/content' ); ?>

						<?php else : ?>

							<?php if ( 1 === $blockfour->current_post ) :?>
								<div class="bottom-post">
							<?php endif; ?>

								<article id="post-<?php the_ID(); ?>" <?php post_class( 'small-post' ); ?>>

									<?php if ( has_post_thumbnail() ) : ?>
										<a class="thumbnail-link" href="<?php the_permalink(); ?>">
											<?php the_post_thumbnail( 'thumbnail', array( 'class' => 'entry-thumbnail', 'alt' => esc_attr( get_the_title() ) ) ); ?>
										</a>
									<?php endif; ?>

									<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>

									<span class="entry-author vcard">
										<?php printf( esc_html__( 'by %s', 'featured' ), '<a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a>' ); ?>
									</span>
								</article>

							<?php if ( $blockfour->post_count === $blockfour->current_post + 1 ) : ?>
								</div>
							<?php endif; ?>

						<?php endif; ?>

					<?php endwhile; ?>

				</div>

			<?php endif; wp_reset_postdata();

		// Close the theme's widget wrapper.
		echo $args['after_widget'];

	}

	/**
	 * Updates the widget control options for the particular instance of the widget.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Updated settings to save.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance           = $old_instance;
		$instance['title']  = sanitize_text_field( $new_instance['title'] );
		$instance['tag']    = sanitize_text_field( $new_instance['tag'] );
		return $instance;
	}

	/**
	 * Displays the widget control options in the Widgets admin screen.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		$title = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
		$tag   = isset( $instance['tag'] ) ? esc_attr( $instance['tag'] ) : '';
	?>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>">
				<?php esc_html_e( 'Title', 'featured' ); ?>
			</label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $title; ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'tag' ); ?>">
				<?php esc_html_e( 'Tag name', 'featured' ); ?>
			</label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'tag' ); ?>" name="<?php echo $this->get_field_name( 'tag' ); ?>" value="<?php echo $tag; ?>" />
			<small><?php esc_html_e( 'If you leave it empty, you will see latest posts instead.', 'featured' ) ?></small>
		</p>

	<?php

	}

}
