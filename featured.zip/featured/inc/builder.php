<?php
/**
 * Siteorigin Panels Compatibility File
 *
 * @package    Featured
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2017, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */

/**
 * Registers custom builder.
 *
 * @since 1.0.0
 * @link  http://codex.wordpress.org/Function_Reference/register_widget
 */
function featured_builders_init() {

	// Block 1
	require trailingslashit( get_template_directory() ) . 'inc/builder/block-one.php';
	register_widget( 'Featured_Block_One_Builder' );

	// Block 2
	require trailingslashit( get_template_directory() ) . 'inc/builder/block-two.php';
	register_widget( 'Featured_Block_Two_Builder' );

	// Block 3
	require trailingslashit( get_template_directory() ) . 'inc/builder/block-three.php';
	register_widget( 'Featured_Block_Three_Builder' );

	// Block 4
	require trailingslashit( get_template_directory() ) . 'inc/builder/block-four.php';
	register_widget( 'Featured_Block_Four_Builder' );

	// Block 5
	require trailingslashit( get_template_directory() ) . 'inc/builder/block-five.php';
	register_widget( 'Featured_Block_Five_Builder' );

}
add_action( 'widgets_init', 'featured_builders_init' );

/**
 * Set the groups for all Featured Widgets
 *
 * @since 1.0.0
 */
function featured_panels_add_widget_groups( $widgets ){
	$widgets['Featured_Block_One_Builder']['groups'] = array( 'featured' );
	$widgets['Featured_Block_Two_Builder']['groups'] = array( 'featured' );
	$widgets['Featured_Block_Three_Builder']['groups'] = array( 'featured' );
	$widgets['Featured_Block_Four_Builder']['groups'] = array( 'featured' );
	$widgets['Featured_Block_Five_Builder']['groups'] = array( 'featured' );
	return $widgets;
}
add_filter( 'siteorigin_panels_widgets', 'featured_panels_add_widget_groups' );

/**
 * Add new panel
 *
 * @since 1.0.0
 */
function featured_panels_add_widgets_dialog_tabs( $tabs ) {

	$tabs[] = array(
		'title'  => esc_html__( 'Featured Theme Widgets', 'featured' ),
		'filter' => array(
			'installed' => true,
			'groups'    => array( 'featured' )
		)
	);

	return $tabs;
}
add_filter( 'siteorigin_panels_widget_dialog_tabs', 'featured_panels_add_widgets_dialog_tabs' );

