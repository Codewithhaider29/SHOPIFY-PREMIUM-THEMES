<?php
/**
 * Featured Theme Customizer
 */

// Loads custom control
require trailingslashit( get_template_directory() ) . 'inc/customizer/controls/custom-text.php';

// Loads the customizer settings
require trailingslashit( get_template_directory() ) . 'inc/customizer/general.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/post.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/page.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/featured-posts.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/footer.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/layout.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/fonts.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/colors.php';

/**
 * Custom customizer functions.
 */
function featured_customize_functions( $wp_customize ) {

	// Register new panel: Design
	$wp_customize->add_panel( 'featured_design', array(
		'title'       => esc_html__( 'Design', 'featured' ),
		'description' => esc_html__( 'This panel is used for customizing the design of your site.', 'featured' ),
		'priority'    => 125,
	) );

	// Register new panel: Theme Options
	$wp_customize->add_panel( 'featured_options', array(
		'title'       => esc_html__( 'Theme Options', 'featured' ),
		'description' => esc_html__( 'This panel is used for customizing the Featured theme.', 'featured' ),
		'priority'    => 130,
	) );

	// Live preview of Site Title
	$wp_customize->get_setting( 'blogname' )->transport = 'postMessage';

	// Enable selective refresh to the Site Title
	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'blogname', array(
			'selector'            => '.site-title a',
			'settings'         => array( 'blogname' ),
			'render_callback'  => function() {
				return get_bloginfo( 'name', 'display' );
			}
		) );
	}

	// Move the Colors section.
	$wp_customize->get_section( 'colors' )->panel    = 'featured_design';
	$wp_customize->get_section( 'colors' )->priority = 1;

	// Move the Theme Layout
	$wp_customize->get_section( 'layout' )->panel    = 'featured_design';
	$wp_customize->get_section( 'layout' )->title    = esc_html__( 'Layouts', 'featured' );
	$wp_customize->get_section( 'layout' )->priority = 5;
	$wp_customize->get_control( 'theme-layout-control' )->label    = esc_html__( 'Post / Page Layout', 'featured' );
	$wp_customize->get_control( 'theme-layout-control' )->priority = 1;
	$wp_customize->get_control( 'theme-layout-control' )->active_callback = function() {
		return is_home() || is_page() || is_single();
	};

	// Move the Background Image section.
	$wp_customize->get_section( 'background_image' )->panel    = 'featured_design';
	$wp_customize->get_section( 'background_image' )->priority = 7;

	// Move the Static Front Page section.
	$wp_customize->get_section( 'static_front_page' )->panel    = 'featured_design';
	$wp_customize->get_section( 'static_front_page' )->priority = 9;

	// Move the Additional CSS section.
	$wp_customize->get_section( 'custom_css' )->panel    = 'featured_design';
	$wp_customize->get_section( 'custom_css' )->priority = 11;

	// Move background color to background image section.
	$wp_customize->get_section( 'background_image' )->title = esc_html__( 'Background', 'featured' );
	$wp_customize->get_control( 'background_color' )->section = 'background_image';

}
add_action( 'customize_register', 'featured_customize_functions', 99 );

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function featured_customize_preview_js() {
	wp_enqueue_script( 'featured-customizer', get_template_directory_uri() . '/assets/js/customizer/customizer.js', array( 'customize-preview', 'jquery' ) );
}
add_action( 'customize_preview_init', 'featured_customize_preview_js' );

/**
 * Custom styles.
 */
function featured_custom_css() {

	// Set up empty variable.
	$css = '';

	// Get the customizer value.
	$color           = get_theme_mod( 'featured_accent_color', '#e60000' );
	$footer_bg_color = get_theme_mod( 'featured_footer_bg', '#f5f5f5' );
	$heading_font    = get_theme_mod( 'featured_heading_font_family', '\'Playfair Display\', serif' );
	$body_font       = get_theme_mod( 'featured_body_font_family', 'Georgia, Palatino, \'Palatino Linotype\', Times, \'Times New Roman\', serif' );
	$secondary_font  = get_theme_mod( 'featured_secondary_font_family', '\'Montserrat\', sans-serif' );

	if ( $color != '#e60000' ) {
		$css .= '
		.cat-links a, button, input[type="button"], input[type="reset"], input[type="submit"], .button, .pagination .page-numbers.current, .pagination .page-numbers:hover, .author-badge, .tag-links a {
			background-color: ' . sanitize_hex_color( $color ) . ';
		}

		a, a:visited, a:hover, .menu-primary-items a:hover, .site-branding a:hover, .more-link-wrapper .more-link, .entry-title a:hover, .page-title a:hover, .post-pagination .post-detail span, .featured .entry-title a:hover, .block-one-big .entry-title a:hover, .entry-meta-single .entry-like a:hover {
			color: ' . sanitize_hex_color( $color ) . ';
		}

		.more-link-wrapper .more-link, .pagination .page-numbers.current, .pagination .page-numbers:hover, .widget_tabs .tabs-nav li.active a, blockquote {
			border-color: ' . sanitize_hex_color( $color ) . ';
		}
		';
	}

	if ( $heading_font != '\'Playfair Display\', serif' ) {
		$css .= '
			h1, h2, h3, h4, h5, h6, .entry-author {
				font-family: ' . wp_kses_post( $heading_font ) . ';
			}
		';
	}

	if ( $body_font != 'Georgia, Palatino, \'Palatino Linotype\', Times, \'Times New Roman\', serif' ) {
		$css .= '
			body {
				font-family: ' . wp_kses_post( $body_font ) . ';
			}
		';
	}

	if ( $secondary_font != '\'Montserrat\', sans-serif' ) {
		$css .= '
			.menu-primary-items a, .widget-title, .entry-author a, .cat-links a, .more-link-wrapper .more-link, .widget, .single .entry-meta, .entry-share .share-title, .tag-links a, .author-bio .name, .related-posts h3, .comment-reply-title, .comments-title, form.comment-form input[type="submit"], .comment-avatar .name, .author-badge, form.comment-form label, .post-pagination .post-detail span {
				font-family: ' . wp_kses_post( $secondary_font ) . ';
			}
		';
	}

	if ( $footer_bg_color != '#f5f5f5' ) {
		$css .= '.site-footer { background-color: ' . sanitize_hex_color( $footer_bg_color ) . '; }';
	}

	// Print the custom style
	wp_add_inline_style( 'featured-style', $css );

}
add_action( 'wp_enqueue_scripts', 'featured_custom_css' );

/**
 * Display theme documentation on customizer page.
 */
function featured_documentation_link() {

	// Enqueue the script
	wp_enqueue_script( 'featured-doc', get_template_directory_uri() . '/assets/js/customizer/doc.js', array(), '1.0.0', true );

	// Localize the script
	wp_localize_script( 'featured-doc', 'prefixL10n',
		array(
			'prefixURL'   => esc_url( 'http://docs.theme-junkie.com/featured/' ),
			'prefixLabel' => esc_html__( 'Documentation', 'featured' ),
		)
	);

}
add_action( 'customize_controls_enqueue_scripts', 'featured_documentation_link' );

/**
 * Sanitize the checkbox.
 *
 * @param boolean $input.
 * @return boolean (true|false).
 */
function featured_sanitize_checkbox( $input ) {
	if ( 1 == $input ) {
		return true;
	} else {
		return false;
	}
}

/**
 * Sanitize the Footer Credits
 */
function featured_sanitize_textarea( $text ) {
	if ( current_user_can( 'unfiltered_html' ) ) {
		$text = $text;
	} else {
		$text = wp_kses_post( $text );
	}
	return $text;
}

/**
 * Sanitize the container style value.
 */
function featured_sanitize_container_style( $style ) {
	if ( ! in_array( $style, array( 'fullwidth', 'boxed', 'framed' ) ) ) {
		$style = 'fullwidth';
	}
	return $style;
}

/**
 * Sanitize the pagination type value.
 */
function featured_sanitize_posts_pagination( $type ) {
	if ( ! in_array( $type, array( 'number', 'traditional' ) ) ) {
		$type = 'number';
	}
	return $type;
}

/**
 * Sanitize the footer widget columns value.
 */
function featured_sanitize_footer_widget_column( $col ) {
	if ( ! in_array( $col, array( '3', '4', '6' ) ) ) {
		$col = '6';
	}
	return $col;
}

/**
 * Sanitize archive layouts value.
 */
function featured_sanitize_archive_layouts( $layout ) {
	if ( ! in_array( $layout,
			array(
				'1c',
				'1c-n',
				'2c-l',
				'2c-r',
				'1c-g',
				'1c-g-n',
				'2c-l-g',
				'2c-r-g',
				'1c-m',
				'2c-l-m',
				'2c-r-m'
			)
		)
	) {
		$layout = '2c-l';
	}
	return $layout;
}
