			</div><!-- .container -->
		</div><!-- #content -->

		<footer id="colophon" class="site-footer">
			<div class="container">

				<?php get_template_part( 'sidebar', 'footer' ); // Loads the sidebar-footer.php template. ?>

				<?php featured_site_branding(); ?>

				<div class="site-info">
					<?php featured_footer_text(); ?>
				</div><!-- .site-info -->

			</div>
		</footer><!-- #colophon -->

	</div><!-- .wide-container -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
