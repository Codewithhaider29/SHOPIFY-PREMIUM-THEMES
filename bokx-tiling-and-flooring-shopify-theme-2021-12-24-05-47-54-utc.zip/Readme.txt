Within the Main folder[themeforest-bokx-shopify-theme.zip] there will be following folder and files.


Documentation
bokx.zip
Readme.txt
Log.txt
 
You need to install the bokx.zip file.

Online documentation URL:
http://themessupport.com/documentation/doc/bokx/

Kindly refer our documentation for installing the theme and doing customization. 
If you need any assistance, plz contact us through support@wedesignthemes.com


Thankyou,
Designthemes.



