Please unpack the whole package after downloading it from Themeforest.
On that extracted themeforest-avery-shopify-theme, You can find files like
Documentation,
avery.zip ,
Log.txt and Readme.txt.

You need to install the file "avery.zip".


Online documentation link :  https://themessupport.com/buddha-shop/avery/