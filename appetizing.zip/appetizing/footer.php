		</div><!-- #content -->

		<footer id="colophon" class="site-footer">

			<?php appetizing_newsletter(); ?>

			<?php appetizing_instagram(); ?>

			<div class="container">

				<div class="site-info">
					<?php appetizing_footer_text(); ?>
				</div>

			</div><!-- .site-info -->

		</footer><!-- #colophon -->

	</div><!-- .wide-container -->

</div><!-- #page -->

<a href="#" class="back-to-top" title="<?php esc_html_e( 'Back to top', 'appetizing' ); ?>"><i class="fa fa-chevron-up" aria-hidden="true"></i></a>

<?php wp_footer(); ?>

</body>
</html>
