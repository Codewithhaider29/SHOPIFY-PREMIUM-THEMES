<?php
// Get the data set in customizer
// Promo box 1
$box_one_img = get_theme_mod( 'appetizing_promobox_one_img' );
$box_one_url = get_theme_mod( 'appetizing_promobox_one_url' );
$box_one_text = get_theme_mod( 'appetizing_promobox_one_text' );

// Promo box 2
$box_two_img = get_theme_mod( 'appetizing_promobox_two_img' );
$box_two_url = get_theme_mod( 'appetizing_promobox_two_url' );
$box_two_text = get_theme_mod( 'appetizing_promobox_two_text' );

// Promo box 3
$box_three_img = get_theme_mod( 'appetizing_promobox_three_img' );
$box_three_url = get_theme_mod( 'appetizing_promobox_three_url' );
$box_three_text = get_theme_mod( 'appetizing_promobox_three_text' );

// Display on home page
if ( !is_home() ) {
	return;
}

if ( $box_one_img || $box_two_img || $box_three_img ) :
?>

	<div class="promo-box">
		<div class="container">

			<div class="promo-box-items">

				<?php if ( $box_one_img ) : ?>
					<?php $img = wp_get_attachment_image_src( absint( $box_one_img ), 'appetizing-post-small' ) ?>
					<div class="promo-box-item first-item">
						<a class="promo-box-link" href="<?php echo esc_url( $box_one_url ); ?>">
							<img src="<?php echo esc_url( $img[0] ); ?>" alt="<?php echo esc_attr( $box_one_text ); ?>">
							<span class="promo-box-title-wrapper">
								<span class="promo-box-title"><?php echo esc_attr( $box_one_text ); ?></span>
							</span>
						</a>
					</div>
				<?php endif; ?>

				<?php if ( $box_two_img ) : ?>
					<?php $img = wp_get_attachment_image_src( absint( $box_two_img ), 'appetizing-post-small' ) ?>
					<div class="promo-box-item second-item">
						<a class="promo-box-link" href="<?php echo esc_url( $box_two_url ); ?>">
							<img src="<?php echo esc_url( $img[0] ); ?>" alt="<?php echo esc_attr( $box_two_text ); ?>">
							<span class="promo-box-title-wrapper">
								<span class="promo-box-title"><?php echo esc_attr( $box_two_text ); ?></span>
							</span>
						</a>
					</div>
				<?php endif; ?>

				<?php if ( $box_three_img ) : ?>
					<?php $img = wp_get_attachment_image_src( absint( $box_three_img ), 'appetizing-post-small' ) ?>
					<div class="promo-box-item third-item">
						<a class="promo-box-link" href="<?php echo esc_url( $box_three_url ); ?>">
							<img src="<?php echo esc_url( $img[0] ); ?>" alt="<?php echo esc_attr( $box_three_text ); ?>">
							<span class="promo-box-title-wrapper">
								<span class="promo-box-title"><?php echo esc_attr( $box_three_text ); ?></span>
							</span>
						</a>
					</div>
				<?php endif; ?>

			</div>

		</div>
	</div>

<?php endif; ?>
