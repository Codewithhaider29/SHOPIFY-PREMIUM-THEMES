<?php
$size = 'appetizing-post';
if ( in_array( get_theme_mod( 'theme_layout' ), array( '1c' ) ) ) {
	$size = 'appetizing-post-large';
}
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<header class="entry-header">
		<?php appetizing_post_header(); ?>
	</header>

	<div class="thumbnail">
		<?php if ( has_post_format( 'video' ) ) : ?>
			<div class="entry-format">
				<?php echo hybrid_media_grabber( array( 'type' => 'video', 'split_media' => true ) ); ?>
			</div>
		<?php elseif ( has_post_format( 'audio' ) ) : ?>
			<div class="entry-format">
				<?php echo hybrid_media_grabber( array( 'type' => 'audio', 'split_media' => true ) ); ?>
			</div>
		<?php elseif ( ! has_post_format( 'quote' ) ) : ?>
			<?php
				the_post_thumbnail( $size, array(
					'alt' => the_title_attribute( array(
						'echo' => false,
					) ),
				) );
			?>
		<?php endif; ?>
	</div>

	<div class="post-content">

		<?php the_content(); ?>
		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'appetizing' ),
				'after'  => '</div>',
			) );
		?>

		<?php
			$tags   = get_the_tags();
			$enable = get_theme_mod( 'appetizing_post_tags', 1 );
			$title  = get_theme_mod( 'appetizing_post_tags_title', esc_html__( 'Topics', 'appetizing' ) );
			if ( $enable && $tags ) :
		?>
			<span class="tag-links">
				<span class="tag-title block-title"><?php echo esc_html( $title ); ?></span>
				<?php foreach( $tags as $tag ) : ?>
					<a href="<?php echo esc_url( get_tag_link( $tag->term_id ) ); ?>">#<?php echo esc_attr( $tag->name ); ?></a>
				<?php endforeach; ?>
			</span>
		<?php endif; ?>

	</div>

	<footer class="entry-footer">

		<div class="post-extras">
			<div class="post-meta">
				<?php appetizing_post_meta(); ?>
			</div>

			<?php appetizing_social_share(); ?>
		</div>

	</footer>

</article><!-- #post-## -->
