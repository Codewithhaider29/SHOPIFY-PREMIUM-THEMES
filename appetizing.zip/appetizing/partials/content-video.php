<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<header class="entry-header">
		<?php appetizing_post_header(); ?>
	</header>

	<div class="thumbnail">
		<?php $video = hybrid_media_grabber( array( 'type' => 'video', 'split_media' => true ) ); ?>
		<?php if ( $video ) :  ?>
			<div class="entry-format"><?php echo $video; ?></div>
		<?php else : ?>
			<?php appetizing_post_thumbnail( 'appetizing-post' ); ?>
		<?php endif; ?>
	</div>

	<div class="entry-summary">
		<?php the_excerpt(); ?>
	</div>

	<span class="more-link-wrapper">
		<a href="<?php the_permalink(); ?>" class="more-link"><?php esc_html_e( 'Keep Reading', 'appetizing' ); ?></a>
	</span>

	<footer class="entry-footer">

		<div class="post-extras">
			<div class="post-meta">
				<?php appetizing_post_meta(); ?>
			</div>

			<?php appetizing_social_share(); ?>
		</div>

	</footer>

</article><!-- #post-## -->
