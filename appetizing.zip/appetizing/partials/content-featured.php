<?php
if ( !is_home() ) {
	return;
}

// Get the customizer data
$enable = get_theme_mod( 'appetizing_featured_posts_enable', 1 );
$number = get_theme_mod( 'appetizing_featured_posts_number', 5 );

// Return early if disabled
if ( !$enable ) {
	return;
}

// Main post query
$query = array(
	'post_type'           => 'post',
	'posts_per_page'      => (int) $number,
	'ignore_sticky_posts' => 1
);

// Get the sticky post ids
$sticky = get_option( 'sticky_posts' );

// Get the tag id
$name = get_theme_mod( 'appetizing_featured_posts_tag', 'featured' );

// Set empty variable
$term = '';

if ( $name ) {
	$term = get_term_by( 'name', $name, 'post_tag' );
}

// Adds the custom arguments to the main query
if ( $term != '' ) {
	$query['tag_id'] = $term->term_id;
} else {
	$query['post__in'] = $sticky;
}

// Allow dev to filter the query.
$query = apply_filters( 'appetizing_featured_posts_args', $query );

$featured = new WP_Query( $query );
?>

<?php if ( $featured->have_posts() ) : ?>

	<div class="featured">
		<div class="container">

			<div class="featured-posts owl-carousel owl-theme">

				<?php while ( $featured->have_posts() ) : $featured->the_post(); ?>

					<article class="featured-post">

						<a href="<?php the_permalink(); ?>">

							<?php
								the_post_thumbnail( 'appetizing-post-large', array(
									'alt' => the_title_attribute( array(
										'echo' => false,
									) ),
								) );
							?>

							<div class="featured-content">
								<?php
									$category = get_the_category( get_the_ID() );
									if ( $category ) :
								?>
									<span class="cat-links">
										<?php echo esc_attr( $category[0]->name ); ?>
									</span>
								<?php endif; // End if category ?>

								<div class="featured-title-wrapper">
									<?php the_title( '<h2 class="entry-title">', '</h2>' ); ?>
								</div>
							</div>

						</a>

					</article>

				<?php endwhile; ?>

			</div>

		</div>
	</div>

<?php endif; wp_reset_postdata(); ?>

