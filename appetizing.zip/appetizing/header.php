<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">

<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<div id="page" class="site">

	<div class="wide-container">

		<?php if ( has_nav_menu ( 'primary' ) ) : ?>
			<nav class="main-navigation">
				<div class="container">

					<?php wp_nav_menu(
						array(
							'theme_location'  => 'primary',
							'menu_id'         => 'primary-menu',
							'menu_class'      => 'primary-menu',
							'container'       => ''
						)
					); ?>

					<?php if ( has_nav_menu ( 'social' ) ) : ?>
						<?php wp_nav_menu(
							array(
								'theme_location'  => 'social',
								'link_before'     => '<span class="screen-reader-text">',
								'link_after'      => '</span>',
								'depth'           => 1,
								'container'       => '',
								'menu_id'         => 'social-menu',
								'menu_class'      => 'social-menu'
							)
						); ?>
					<?php endif; ?>

				</div>
			</nav>
		<?php endif; ?>

		<header id="masthead" class="site-header">
			<div class="container">
				<?php appetizing_site_branding(); ?>
			</div>
		</header><!-- #masthead -->

		<?php if ( has_nav_menu ( 'secondary' ) ) : ?>
			<nav class="secondary-navigation">
				<div class="container">
					<?php wp_nav_menu(
						array(
							'theme_location'  => 'secondary',
							'menu_id'         => 'secondary-menu',
							'menu_class'      => 'secondary-menu',
							'container'       => ''
						)
					); ?>
				</div>
			</nav>
		<?php endif; ?>

		<?php get_template_part( 'partials/content', 'featured' ); ?>

		<?php get_template_part( 'partials/promo', 'box' ); ?>

		<div id="content" class="site-content">
