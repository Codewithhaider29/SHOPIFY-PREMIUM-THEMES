( function( $ ) {

	/**
	 * Responsive video
	 */
	function responsiveVideo() {
		$( '.entry, .widget, .entry-format' ).fitVids();
	}

	/**
	 * Back to top
	 */
	function backToTop() {
		if ( $( '.back-to-top' ).length ) {
			var scrollTrigger = 100,
				backToTop = function() {
					var scrollTop = $( window ).scrollTop();
					if ( scrollTop > scrollTrigger ) {
						$( '.back-to-top' ).addClass( 'show' );
					} else {
						$( '.back-to-top' ).removeClass( 'show' );
					}
				};

			backToTop();
			$( window ).on( 'scroll', function() {
				backToTop();
			} );

			$( '.back-to-top' ).on( 'click', function( e ) {
				e.preventDefault();
				$( 'html, body' ).animate( {
					scrollTop: 0
				}, 700 );
			} );

		}
	}

	/**
	 * Featured posts slider
	 */
	function featuredPosts() {
		$( '.featured-posts.owl-carousel' ).owlCarousel( {
			loop: true,
			nav: false,
			dots: true,
			items: 1
		} )
	}

	/**
	 * Mobile top menu
	 */
	function mobileTopNav() {
		$( '#primary-menu' ).slicknav( {
			label: '',
			prependTo: '.main-navigation .container',
			nestedParentLinks: false
		} );
	}

	/**
	 * Mobile main menu
	 */
	function mobileMainNav() {
		$( '#secondary-menu' ).slicknav( {
			label: '',
			prependTo: '.secondary-navigation .container',
			nestedParentLinks: false
		} );
	}

	/**
	 * Ingredient toggle class
	 */
	function ingredientsToggle() {
		$( '.appetizing-ingredients-shortcode li' ).on( 'click', function() {
			$( this ).toggleClass( 'clicked' );
		} );
	}

	// Document ready
	$( function() {
		responsiveVideo();
		backToTop();
		featuredPosts();
		mobileTopNav();
		mobileMainNav();
		ingredientsToggle();
	} );

}( jQuery ) );
