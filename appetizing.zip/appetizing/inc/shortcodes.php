<?php
/**
 * Custom shortcodes
 *
 * @package    Appetizing
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2018, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */

/**
 * Ingridients
 */
function appetizing_ingredients_shortcode( $atts, $content = null ) {

	extract( shortcode_atts( array(
		'title' => esc_html__( 'Ingredients', 'appetizing' )
    ), $atts ) );

   return '<div class="appetizing-ingredients-shortcode"><h3 class="ingredients-title">' . esc_attr( $title ) . '</h3>' . wp_kses_post( $content ) . '</div>';

}
add_shortcode( 'ingredients', 'appetizing_ingredients_shortcode' );
