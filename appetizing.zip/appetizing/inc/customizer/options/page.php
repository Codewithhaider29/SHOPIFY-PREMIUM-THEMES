<?php
/**
 * Page Customizer
 */

/**
 * Register the customizer.
 */
function appetizing_page_customize_register( $wp_customize ) {

	// Register new section: Page
	$wp_customize->add_section( 'appetizing_page' , array(
		'title'    => esc_html__( 'Pages', 'appetizing' ),
		'panel'    => 'appetizing_options',
		'priority' => 11
	) );

	// Register Page comment manager setting
	$wp_customize->add_setting( 'appetizing_page_comment', array(
		'default'           => 1,
		'sanitize_callback' => 'appetizing_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'appetizing_page_comment', array(
		'label'             => esc_html__( 'Enable comment on Pages', 'appetizing' ),
		'section'           => 'appetizing_page',
		'priority'          => 1,
		'type'              => 'checkbox'
	) );

	// Register Page title setting
	$wp_customize->add_setting( 'appetizing_page_title', array(
		'default'           => 1,
		'sanitize_callback' => 'appetizing_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'appetizing_page_title', array(
		'label'             => esc_html__( 'Enable page title', 'appetizing' ),
		'section'           => 'appetizing_page',
		'priority'          => 3,
		'type'              => 'checkbox'
	) );

	// Register Page appetizing image setting
	$wp_customize->add_setting( 'appetizing_page_appetizing_image', array(
		'default'           => 0,
		'sanitize_callback' => 'appetizing_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'appetizing_page_appetizing_image', array(
		'label'             => esc_html__( 'Enable page featured image', 'appetizing' ),
		'section'           => 'appetizing_page',
		'priority'          => 5,
		'type'              => 'checkbox'
	) );

}
add_action( 'customize_register', 'appetizing_page_customize_register' );
