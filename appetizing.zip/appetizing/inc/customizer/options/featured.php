<?php
/**
 * Featured Posts Customizer
 */

/**
 * Register the customizer.
 */
function appetizing_featured_posts_customize_register( $wp_customize ) {

	// Register new section: Featured Posts
	$wp_customize->add_section( 'appetizing_featured_posts' , array(
		'title'       => esc_html__( 'Featured Posts', 'appetizing' ),
		'description'    => sprintf( __( 'Use a <a href="%1$s">tag</a> to feature your posts. If no posts match the tag, <a href="%2$s">sticky posts</a> will be displayed instead.', 'appetizing' ),
				esc_url( add_query_arg( 'tag', _x( 'featured', 'featured content default tag slug', 'appetizing' ), admin_url( 'edit.php' ) ) ),
				admin_url( 'edit.php?show_sticky=1' )
			),
		'panel'       => 'appetizing_options',
		'priority'    => 13
	) );

	// Register enable featured posts setting
	$wp_customize->add_setting( 'appetizing_featured_posts_enable', array(
		'default'           => 1,
		'sanitize_callback' => 'appetizing_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'appetizing_featured_posts_enable', array(
		'label'             => esc_html__( 'Show featured posts', 'appetizing' ),
		'section'           => 'appetizing_featured_posts',
		'priority'          => 1,
		'type'              => 'checkbox'
	) );

	// Register query setting
	$wp_customize->add_setting( 'appetizing_featured_posts_tag', array(
		'default'           => 'featured',
		'sanitize_callback' => 'esc_attr',
	) );
	$wp_customize->add_control( 'appetizing_featured_posts_tag', array(
		'label'             => esc_html__( 'Tag Name', 'appetizing' ),
		'section'           => 'appetizing_featured_posts',
		'priority'          => 5,
		'type'              => 'text'
	) );

	// Register number setting
	$wp_customize->add_setting( 'appetizing_featured_posts_number', array(
		'default'           => 5,
		'sanitize_callback' => 'absint',
	) );
	$wp_customize->add_control( 'appetizing_featured_posts_number', array(
		'label'             => esc_html__( 'Number', 'velove' ),
		'section'           => 'appetizing_featured_posts',
		'priority'          => 7,
		'type'              => 'number',
		'input_attrs'       => array(
			'min'  => 0,
			'step' => 1
		)
	) );

}
add_action( 'customize_register', 'appetizing_featured_posts_customize_register' );
