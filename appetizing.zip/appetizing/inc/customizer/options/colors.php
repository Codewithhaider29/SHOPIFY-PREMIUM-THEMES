<?php
/**
 * Colors Customizer
 */

/**
 * Register the customizer.
 */
function appetizing_colors_customize_register( $wp_customize ) {

	// Register accent color setting
	$wp_customize->add_setting( 'appetizing_accent_color', array(
		'default'           => '#e0a633',
		'sanitize_callback' => 'appetizing_sanitize_hex_color'
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'appetizing_accent_color', array(
		'label'             => esc_html__( 'Accent Color', 'appetizing' ),
		'section'           => 'colors',
		'priority'          => 1
	) ) );

}
add_action( 'customize_register', 'appetizing_colors_customize_register' );
