<?php
/**
 * Promo Box Customizer
 */

/**
 * Register the customizer.
 */
function appetizing_promo_customize_register( $wp_customize ) {

	// Register new section: Promo Box
	$wp_customize->add_section( 'appetizing_promo' , array(
		'title'    => esc_html__( 'Promo Box', 'appetizing' ),
		'panel'    => 'appetizing_options',
		'priority' => 15
	) );

	// Register Promo Box 1 setting
	$wp_customize->add_setting( 'appetizing_promo_one', array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr'
	) );
	$wp_customize->add_control( new Appetizing_Custom_Text( $wp_customize, 'appetizing_promo_one', array(
		'label'             => esc_html__( 'PROMO BOX 1', 'appetizing' ),
		'section'           => 'appetizing_promo',
		'priority'          => 1
	) ) );

		$wp_customize->add_setting( 'appetizing_promobox_one_img', array(
			'default'           => '',
			'sanitize_callback' => 'absint'
		) );
		$wp_customize->add_control( new WP_Customize_Media_Control( $wp_customize, 'appetizing_promobox_one_img', array(
			'label'             => esc_html__( 'Image', 'appetizing' ),
			'section'           => 'appetizing_promo',
			'priority'          => 2,
			'mime_type'         => 'image',
		) ) );

		$wp_customize->add_setting( 'appetizing_promobox_one_url', array(
			'default'           => '',
			'sanitize_callback' => 'appetizing_sanitize_url',
		) );
		$wp_customize->add_control( 'appetizing_promobox_one_url', array(
			'label'             => esc_html__( 'URL', 'appetizing' ),
			'section'           => 'appetizing_promo',
			'priority'          => 3,
			'type'              => 'url'
		) );

		$wp_customize->add_setting( 'appetizing_promobox_one_text', array(
			'default'           => '',
			'sanitize_callback' => 'appetizing_sanitize_html',
		) );
		$wp_customize->add_control( 'appetizing_promobox_one_text', array(
			'label'             => esc_html__( 'Text', 'appetizing' ),
			'section'           => 'appetizing_promo',
			'priority'          => 4,
			'type'              => 'text'
		) );

	// Register Promo Box 2 setting
	$wp_customize->add_setting( 'appetizing_promo_two', array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr'
	) );
	$wp_customize->add_control( new Appetizing_Custom_Text( $wp_customize, 'appetizing_promo_two', array(
		'label'             => esc_html__( 'PROMO BOX 2', 'appetizing' ),
		'section'           => 'appetizing_promo',
		'priority'          => 6
	) ) );

		$wp_customize->add_setting( 'appetizing_promobox_two_img', array(
			'default'           => '',
			'sanitize_callback' => 'absint'
		) );
		$wp_customize->add_control( new WP_Customize_Media_Control( $wp_customize, 'appetizing_promobox_two_img', array(
			'label'             => esc_html__( 'Image', 'appetizing' ),
			'section'           => 'appetizing_promo',
			'priority'          => 7,
			'mime_type'         => 'image',
		) ) );

		$wp_customize->add_setting( 'appetizing_promobox_two_url', array(
			'default'           => '',
			'sanitize_callback' => 'appetizing_sanitize_url',
		) );
		$wp_customize->add_control( 'appetizing_promobox_two_url', array(
			'label'             => esc_html__( 'URL', 'appetizing' ),
			'section'           => 'appetizing_promo',
			'priority'          => 8,
			'type'              => 'url'
		) );

		$wp_customize->add_setting( 'appetizing_promobox_two_text', array(
			'default'           => '',
			'sanitize_callback' => 'appetizing_sanitize_html',
		) );
		$wp_customize->add_control( 'appetizing_promobox_two_text', array(
			'label'             => esc_html__( 'Text', 'appetizing' ),
			'section'           => 'appetizing_promo',
			'priority'          => 9,
			'type'              => 'text'
		) );

	// Register Promo Box 3 setting
	$wp_customize->add_setting( 'appetizing_promo_three', array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr'
	) );
	$wp_customize->add_control( new Appetizing_Custom_Text( $wp_customize, 'appetizing_promo_three', array(
		'label'             => esc_html__( 'PROMO BOX 3', 'appetizing' ),
		'section'           => 'appetizing_promo',
		'priority'          => 11
	) ) );

		$wp_customize->add_setting( 'appetizing_promobox_three_img', array(
			'default'           => '',
			'sanitize_callback' => 'absint'
		) );
		$wp_customize->add_control( new WP_Customize_Media_Control( $wp_customize, 'appetizing_promobox_three_img', array(
			'label'             => esc_html__( 'Image', 'appetizing' ),
			'section'           => 'appetizing_promo',
			'priority'          => 12,
			'mime_type'         => 'image',
		) ) );

		$wp_customize->add_setting( 'appetizing_promobox_three_url', array(
			'default'           => '',
			'sanitize_callback' => 'appetizing_sanitize_url',
		) );
		$wp_customize->add_control( 'appetizing_promobox_three_url', array(
			'label'             => esc_html__( 'URL', 'appetizing' ),
			'section'           => 'appetizing_promo',
			'priority'          => 13,
			'type'              => 'url'
		) );

		$wp_customize->add_setting( 'appetizing_promobox_three_text', array(
			'default'           => '',
			'sanitize_callback' => 'appetizing_sanitize_html',
		) );
		$wp_customize->add_control( 'appetizing_promobox_three_text', array(
			'label'             => esc_html__( 'Text', 'appetizing' ),
			'section'           => 'appetizing_promo',
			'priority'          => 14,
			'type'              => 'text'
		) );

}
add_action( 'customize_register', 'appetizing_promo_customize_register' );
