<?php
/**
 * General Customizer
 */

/**
 * Register the customizer.
 */
function appetizing_general_customize_register( $wp_customize ) {

	// Register new section: General
	$wp_customize->add_section( 'appetizing_general' , array(
		'title'    => esc_html__( 'General', 'appetizing' ),
		'panel'    => 'appetizing_options',
		'priority' => 1
	) );

	// Register container setting
	$wp_customize->add_setting( 'appetizing_container_style', array(
		'default'           => 'fullwidth',
		'sanitize_callback' => 'appetizing_sanitize_select',
	) );
	$wp_customize->add_control( 'appetizing_container_style', array(
		'label'             => esc_html__( 'Container', 'appetizing' ),
		'section'           => 'appetizing_general',
		'priority'          => 1,
		'type'              => 'radio',
		'choices'           => array(
			'fullwidth' => esc_html__( 'Full Width', 'appetizing' ),
			'boxed'     => esc_html__( 'Boxed', 'appetizing' ),
			'framed'    => esc_html__( 'Framed', 'appetizing' )
		)
	) );

	// Register pagination setting
	$wp_customize->add_setting( 'appetizing_posts_pagination', array(
		'default'           => 'number',
		'sanitize_callback' => 'appetizing_sanitize_select',
	) );
	$wp_customize->add_control( 'appetizing_posts_pagination', array(
		'label'             => esc_html__( 'Pagination type', 'appetizing' ),
		'section'           => 'appetizing_general',
		'priority'          => 3,
		'type'              => 'radio',
		'choices'           => array(
			'number'      => esc_html__( 'Number', 'appetizing' ),
			'traditional' => esc_html__( 'Older / Newer', 'appetizing' )
		)
	) );

	// Register sticky sidebar setting
	$wp_customize->add_setting( 'appetizing_sticky_sidebar', array(
		'default'           => 0,
		'sanitize_callback' => 'appetizing_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'appetizing_sticky_sidebar', array(
		'label'             => esc_html__( 'Enable sticky sidebar', 'appetizing' ),
		'section'           => 'appetizing_general',
		'priority'          => 5,
		'type'              => 'checkbox'
	) );

	// Register instagram shortcode setting
	$wp_customize->add_setting( 'appetizing_instagram_shortcode', array(
		'default'           => '',
		'sanitize_callback' => 'appetizing_sanitize_html',
	) );
	$wp_customize->add_control( 'appetizing_instagram_shortcode', array(
		'label'             => esc_html__( 'Instagram Shortcode', 'appetizing' ),
		'section'           => 'appetizing_general',
		'priority'          => 7,
		'type'              => 'text'
	) );

}
add_action( 'customize_register', 'appetizing_general_customize_register' );
