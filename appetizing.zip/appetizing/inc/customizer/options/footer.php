<?php
/**
 * Footer Customizer
 */

/**
 * Register the customizer.
 */
function appetizing_footer_customize_register( $wp_customize ) {

	// Register new section: Footer
	$wp_customize->add_section( 'appetizing_footer' , array(
		'title'    => esc_html__( 'Footer', 'appetizing' ),
		'panel'    => 'appetizing_options',
		'priority' => 17
	) );

	// Register Footer Credits setting
	$wp_customize->add_setting( 'appetizing_footer_credits', array(
		'sanitize_callback' => 'appetizing_sanitize_html',
		'default'           => '&copy; Copyright ' . date( 'Y' ) . ' <a href="' . esc_url( home_url() ) . '">' . esc_attr( get_bloginfo( 'name' ) ) . '</a> &middot; Designed and Developed by <a href="http://www.theme-junkie.com/">Theme Junkie</a>',
		'transport'         => 'postMessage',
	) );
	$wp_customize->add_control( 'appetizing_footer_credits', array(
		'label'             => esc_html__( 'Footer Text', 'appetizing' ),
		'section'           => 'appetizing_footer',
		'priority'          => 11,
		'type'              => 'textarea'
	) );
	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'appetizing_footer_credits', array(
			'selector'         => '.copyright',
			'settings'         => array( 'appetizing_footer_credits' ),
			'render_callback'  => function() {
				return appetizing_sanitize_html( get_theme_mod( 'appetizing_footer_credits' ) );
			}
		) );
	}

}
add_action( 'customize_register', 'appetizing_footer_customize_register' );
