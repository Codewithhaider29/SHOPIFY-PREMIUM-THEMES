<?php
/**
 * Newsletter Customizer
 */

/**
 * Register the customizer.
 */
function appetizing_newsletter_customize_register( $wp_customize ) {

	// Register new section: Newsletter
	$wp_customize->add_section( 'appetizing_newsletter' , array(
		'title'    => esc_html__( 'Newsletter', 'appetizing' ),
		'panel'    => 'appetizing_options',
		'priority' => 15
	) );

	// Register enable newsletter setting
	$wp_customize->add_setting( 'appetizing_newsletter_enable', array(
		'default'           => 1,
		'sanitize_callback' => 'appetizing_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'appetizing_newsletter_enable', array(
		'label'             => esc_html__( 'Enable newsletter', 'appetizing' ),
		'section'           => 'appetizing_newsletter',
		'priority'          => 1,
		'type'              => 'checkbox'
	) );

	// Register title setting
	$wp_customize->add_setting( 'appetizing_newsletter_title', array(
		'default'           => esc_html__( 'Our Recipes in your inbox!', 'appetizing' ),
		'sanitize_callback' => 'appetizing_sanitize_html',
	) );
	$wp_customize->add_control( 'appetizing_newsletter_title', array(
		'label'             => esc_html__( 'Title', 'appetizing' ),
		'section'           => 'appetizing_newsletter',
		'priority'          => 3,
		'type'              => 'text'
	) );

	// Register description setting
	$wp_customize->add_setting( 'appetizing_newsletter_desc', array(
		'default'           => esc_html__( 'Sign up to receive our weekly email newsletter and never miss an update!', 'appetizing' ),
		'sanitize_callback' => 'appetizing_sanitize_html',
	) );
	$wp_customize->add_control( 'appetizing_newsletter_desc', array(
		'label'             => esc_html__( 'Description', 'appetizing' ),
		'section'           => 'appetizing_newsletter',
		'priority'          => 5,
		'type'              => 'text'
	) );

	// Register shortcode setting
	$wp_customize->add_setting( 'appetizing_newsletter_shortcode', array(
		'default'           => '',
		'sanitize_callback' => 'appetizing_sanitize_html',
	) );
	$wp_customize->add_control( 'appetizing_newsletter_shortcode', array(
		'label'             => esc_html__( 'Form Shortcode', 'appetizing' ),
		'section'           => 'appetizing_newsletter',
		'priority'          => 7,
		'type'              => 'text'
	) );

}
add_action( 'customize_register', 'appetizing_newsletter_customize_register' );
