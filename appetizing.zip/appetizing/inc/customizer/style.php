<?php
/**
 * Customizer: Custom styles
 */

function appetizing_custom_css() {

	// Set up empty variable.
	$css = '';

	// Get the customizer value.
	// Colors
	$accent       = get_theme_mod( 'appetizing_accent_color', '#e0a633' );

	// Adjust color.
	$simple_color_adjuster = new Simple_Color_Adjuster;
	$lighten_accent = $simple_color_adjuster->lighten( $accent, 20 );

	// Typography
	$heading_font = get_theme_mod( 'appetizing_heading_font_family', '\'Lora\', serif' );
	$body_font    = get_theme_mod( 'appetizing_body_font_family', '\'Source Sans Pro\', sans-serif' );

	if ( $heading_font != '\'Lora\', serif' ) {
		$css .= '
			h1, h2, h3, h4, h5, h6, .entry-author {
				font-family: ' . wp_kses_post( $heading_font ) . ';
			}
		';
	}

	if ( $body_font != '\'Source Sans Pro\', sans-serif' ) {
		$css .= '
			body {
				font-family: ' . wp_kses_post( $body_font ) . ';
			}
		';
	}

	// Accent
	if ( $accent != '#e0a633' ) {
		$css .= '
			.cat-links,
			button:hover, input[type="button"]:hover, input[type="reset"]:hover, input[type="submit"]:hover, button:focus, input[type="button"]:focus, input[type="reset"]:focus, input[type="submit"]:focus, .button:hover, .button:focus,
			.author-badge {
				background-color: ' . sanitize_hex_color( $accent ) . ';
			}

			.primary-menu li a:hover,
			.secondary-menu li a:hover,
			.secondary-menu li:hover > a,
			.secondary-menu li ul li a:hover,
			.primary-menu li:hover > a,
			.social-search li:hover > a,
			.entry-title a:hover,
			.post-meta a:hover,
			.widget li a:hover,
			.site-info .copyright a,
			.tag-links a,
			.logged-in-as a,
			.post-edit-link,
			.site-branding .site-title a,
			.more-link,
			.more-link:visited,
			.back-to-top,
			.back-to-top:visited,
			.post-pagination .post-detail span,
			.widget_entries_thumbnail .post-title:hover {
			  color: ' . sanitize_hex_color( $accent ) . ';
			}

			.primary-menu .sub-menu li:hover,
			.secondary-menu .sub-menu li:hover,
			blockquote,
			.more-link {
			  border-color: ' . sanitize_hex_color( $accent ) . ';
			}

			.promo-box {
				background-color: ' . sanitize_hex_color( $lighten_accent ) . ';
			}

		';
	}

	// Print the custom style
	wp_add_inline_style( 'appetizing-style', $css );

}
add_action( 'wp_enqueue_scripts', 'appetizing_custom_css' );
