<?php
/**
 * Address widget.
 *
 * @package    Appetizing
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2018, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */
class Appetizing_Address_Widget extends WP_Widget {

	/**
	 * Sets up the widgets.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {

		// Set up the widget options.
		$widget_ops = array(
			'classname'   => 'widget_address',
			'description' => esc_html__( 'Display your address, phone and email.', 'appetizing' ),
			'customize_selective_refresh' => true
		);

		// Create the widget.
		parent::__construct(
			'appetizing-address',                          // $this->id_base
			esc_html__( '&raquo; Address', 'appetizing' ), // $this->name
			$widget_ops                                  // $this->widget_options
		);

		$this->alt_option_name = 'widget_address';

	}

	/**
	 * Outputs the widget based on the arguments input through the widget controls.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current Recent Posts widget instance.
	 */
	public function widget( $args, $instance ) {
		if ( ! isset( $args['widget_id'] ) ) {
			$args['widget_id'] = $this->id;
		}

		// Set up default value
		$title     = ( ! empty( $instance['title'] ) ) ? $instance['title'] : esc_html__( 'Address', 'appetizing' );
		$address   = ( ! empty( $instance['address'] ) ) ? $instance['address'] : '';
		$phone     = ( ! empty( $instance['phone'] ) ) ? $instance['phone'] : '';
		$email     = ( ! empty( $instance['email'] ) ) ? $instance['email'] : '';

		// Output the theme's $before_widget wrapper.
		echo $args['before_widget'];

		// If the title not empty, display it.
		if ( $title ) {
			echo $args['before_title'] . apply_filters( 'widget_title', $title, $instance, $this->id_base ) . $args['after_title'];
		}
		?>

			<ul class="address">
				<li>
					<span class="icon"><i class="fa fa-map-marker" aria-hidden="true"></i></span>
					<span class="text"><?php echo esc_html( $address ); ?></span>
				</li>
				<li>
					<span class="icon"><i class="fa fa-phone" aria-hidden="true"></i></span>
					<span class="text"><?php echo esc_html( $phone ); ?></span>
				</li>
				<li>
					<span class="icon"><i class="fa fa-envelope" aria-hidden="true"></i></span>
					<span class="text"><?php echo is_email( $email ); ?></span>
				</li>
			</ul>

		<?php
		// Close the theme's widget wrapper.
		echo $args['after_widget'];

	}

	/**
	 * Updates the widget control options for the particular instance of the widget.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Updated settings to save.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance              = $old_instance;
		$instance['title']     = sanitize_text_field( $new_instance['title'] );
		$instance['address']   = sanitize_text_field( $new_instance['address'] );
		$instance['phone']     = sanitize_text_field( $new_instance['phone'] );
		$instance['email']     = is_email( $new_instance['email'] );
		return $instance;
	}

	/**
	 * Displays the widget control options in the Widgets admin screen.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		$title     = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : esc_html__( 'Address', 'appetizing' );
		$address   = isset( $instance['address'] ) ? esc_attr( $instance['address'] ) : '';
		$phone     = isset( $instance['phone'] ) ? esc_attr( $instance['phone'] ) : '';
		$email     = isset( $instance['email'] ) ? is_email( $instance['email'] ) : '';
	?>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>">
				<?php esc_html_e( 'Title', 'appetizing' ); ?>
			</label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $title; ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'address' ); ?>">
				<?php esc_html_e( 'Address', 'appetizing' ); ?>
			</label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'address' ); ?>" name="<?php echo $this->get_field_name( 'address' ); ?>" value="<?php echo $address; ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'phone' ); ?>">
				<?php esc_html_e( 'Phone', 'appetizing' ); ?>
			</label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'phone' ); ?>" name="<?php echo $this->get_field_name( 'phone' ); ?>" value="<?php echo $phone; ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'email' ); ?>">
				<?php esc_html_e( 'Email', 'appetizing' ); ?>
			</label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'email' ); ?>" name="<?php echo $this->get_field_name( 'email' ); ?>" value="<?php echo $email; ?>" />
		</p>

	<?php

	}

}
