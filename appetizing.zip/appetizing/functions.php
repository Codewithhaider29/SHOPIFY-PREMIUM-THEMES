<?php
/**
 * Theme functions file
 *
 * Contains all of the Theme's setup functions, custom functions,
 * custom hooks and Theme settings.
 *
 * @package    Appetizing
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2018, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */

if ( ! function_exists( 'appetizing_theme_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * @since  1.0.0
	 */
	function appetizing_theme_setup() {

		// Make the theme available for translation.
		load_theme_textdomain( 'appetizing', trailingslashit( get_template_directory() ) . 'languages' );

		// Add custom stylesheet file to the TinyMCE visual editor.
		add_editor_style( array( 'assets/css/editor-style.css', appetizing_fonts_url() ) );

		// Add RSS feed links to <head> for posts and comments.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// Declare image sizes.
		add_image_size( 'appetizing-post', 750, 500, true );
		add_image_size( 'appetizing-post-large', 1170, 600, true );
		add_image_size( 'appetizing-post-small', 720, 480, true );

		// Register custom navigation menu.
		register_nav_menus( array(
			'primary'   => esc_html__( 'Top Location', 'appetizing' ),
			'secondary' => esc_html__( 'Main Location' , 'appetizing' ),
			'social'    => esc_html__( 'Social Links' , 'appetizing' ),
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		/*
		 * Enable support for Post Formats.
		 * See: http://codex.wordpress.org/Post_Formats
		 */
		add_theme_support( 'post-formats', array(
			'video'
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'appetizing_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 50,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );

		// Enable theme-layouts extensions.
		add_theme_support( 'theme-layouts',
			array(
				'1c'   => esc_html__( '1 Column Wide (Full Width)', 'appetizing' ),
				'1c-n' => esc_html__( '1 Column Narrow', 'appetizing' ),
				'2c-l' => esc_html__( '2 Columns: Content / Sidebar', 'appetizing' ),
				'2c-r' => esc_html__( '2 Columns: Sidebar / Content', 'appetizing' )
			),
			array( 'customize' => false, 'default' => '2c-l' )
		);

		// This theme uses its own gallery styles.
		add_filter( 'use_default_gallery_style', '__return_false' );

		// Indicate widget sidebars can use selective refresh in the Customizer.
		add_theme_support( 'customize-selective-refresh-widgets' );

	}
endif; // appetizing_theme_setup
add_action( 'after_setup_theme', 'appetizing_theme_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function appetizing_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'appetizing_content_width', 750 );
}
add_action( 'after_setup_theme', 'appetizing_content_width', 0 );

/**
 * Set new content width if user uses 1 column layout.
 */
if ( ! function_exists( 'appetizing_secondary_content_width' ) ) :
	function appetizing_secondary_content_width() {
		global $content_width;

		if ( in_array( get_theme_mod( 'theme_layout' ), array( '1c' ) ) ) {
			$content_width = 1170;
		}
	}
endif;
add_action( 'template_redirect', 'appetizing_secondary_content_width' );

/**
 * Registers custom widgets.
 *
 * @since 1.0.0
 * @link  http://codex.wordpress.org/Function_Reference/register_widget
 */
function appetizing_widgets_init() {

	// Register ad widget.
	require trailingslashit( get_template_directory() ) . 'inc/widgets/widget-ads.php';
	register_widget( 'Appetizing_Ads_Widget' );

	// Register Facebook widget.
	require trailingslashit( get_template_directory() ) . 'inc/widgets/widget-facebook.php';
	register_widget( 'Appetizing_Facebook_Widget' );

	// Register posts thumbnail widget.
	require trailingslashit( get_template_directory() ) . 'inc/widgets/widget-posts.php';
	register_widget( 'Appetizing_Posts_Widget' );

	// Register twitter widget.
	require trailingslashit( get_template_directory() ) . 'inc/widgets/widget-twitter.php';
	register_widget( 'Appetizing_Twitter_Widget' );

	// Register social widget.
	require trailingslashit( get_template_directory() ) . 'inc/widgets/widget-social.php';
	register_widget( 'Appetizing_Social_Widget' );

	// Register address widget.
	require trailingslashit( get_template_directory() ) . 'inc/widgets/widget-address.php';
	register_widget( 'Appetizing_Address_Widget' );

}
add_action( 'widgets_init', 'appetizing_widgets_init' );

/**
 * Registers widget areas and custom widgets.
 *
 * @since 1.0.0
 * @link  http://codex.wordpress.org/Function_Reference/register_sidebar
 */
function appetizing_sidebars_init() {

	register_sidebar(
		array(
			'name'          => esc_html__( 'Primary Sidebar', 'appetizing' ),
			'id'            => 'primary',
			'description'   => esc_html__( 'Main sidebar that appears on the right.', 'appetizing' ),
			'before_widget' => '<aside id="%1$s" class="widget %2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<h3 class="widget-title"><span>',
			'after_title'   => '</span></h3>',
		)
	);

}
add_action( 'widgets_init', 'appetizing_sidebars_init' );

/**
 * Register Google fonts.
 *
 * @since  1.0.0
 * @return string
 */
function appetizing_fonts_url() {

	// Get the customizer data
	$body_font    = get_theme_mod( 'appetizing_body_font', 'Source+Sans+Pro:400,400i,700,700i' );
	$heading_font = get_theme_mod( 'appetizing_heading_font', 'Lora:400,400i,700,700i' );

	// Important variable
	$fonts_url = '';
	$fonts     = array();

	if ( $body_font ) {
		$fonts[]   = esc_attr( str_replace( '+', ' ', $body_font ) );
	}

	if ( $heading_font && ( $body_font != $heading_font ) ) {
		$fonts[]   = esc_attr( str_replace( '+', ' ', $heading_font ) );
	}

	if ( $fonts ) {
		$fonts_url = add_query_arg( array(
			'family' => urlencode( implode( '|', $fonts ) ),
		), 'https://fonts.googleapis.com/css' );
	}

	return $fonts_url;
}

/**
 * Post views count
 */
function appetizing_post_views( $id ) {

	if ( is_singular() ) {

		$key   = 'post_views';
		$count = get_post_meta( $id, $key, true );

		if ( $count == '' ) {
			$count = 0;
			delete_post_meta( $id, $key );
			add_post_meta( $id, $key, '0' );
		} else {
			$count++;
			update_post_meta( $id, $key, $count );
		}
	}

}

/**
 * Custom template tags for this theme.
 */
require trailingslashit( get_template_directory() ) . 'inc/template-tags.php';

/**
 * Enqueue scripts and styles.
 */
require trailingslashit( get_template_directory() ) . 'inc/scripts.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require trailingslashit( get_template_directory() ) . 'inc/extras.php';

/**
 * Require and recommended plugins list.
 */
require trailingslashit( get_template_directory() ) . 'inc/plugins.php';

/**
 * Custom built-in shortcodes
 */
require trailingslashit( get_template_directory() ) . 'inc/shortcodes.php';

/**
 * Customizer.
 */
require trailingslashit( get_template_directory() ) . 'inc/customizer/customizer.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/sanitize.php';
require trailingslashit( get_template_directory() ) . 'inc/customizer/style.php';

/**
 * Demo importer.
 */
require trailingslashit( get_template_directory() ) . 'inc/demo/demo-importer.php';

/**
 * We use some part of Hybrid Core to extends our themes.
 *
 * @link  http://themehybrid.com/hybrid-core Hybrid Core site.
 */
require trailingslashit( get_template_directory() ) . 'inc/extensions/theme-layouts.php';
require trailingslashit( get_template_directory() ) . 'inc/extensions/hybrid-media-grabber.php';

/**
 * Automatic theme update.
 */
require trailingslashit( get_template_directory() ) . 'inc/updater.php';

/**
 * Custom color adjuster function
 */
require trailingslashit( get_template_directory() ) . 'inc/extensions/simple-color-adjuster.php';
