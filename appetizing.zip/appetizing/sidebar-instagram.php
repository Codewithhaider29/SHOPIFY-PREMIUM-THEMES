<?php
// Return early if no widget found.
if ( ! is_active_sidebar( 'instagram' ) ) {
	return;
}
?>

<div class="instagram-widget">
	<?php dynamic_sidebar( 'instagram' ); ?>
</div>
