$(document).ready(function() {
  var controller = $.superscrollorama();
  // individual element tween examples
  controller.addTween('.fade-it', TweenMax.fromTo( $('.fade-it'), .7, {css:{opacity: 0}}, {css:{opacity:1}}),0,0,false);
  controller.addTween('#fade-it-1', TweenMax.fromTo( $('#fade-it-1'), .5, {css:{opacity: 0}}, {css:{opacity:1}}),0,-150,false);
  controller.addTween('#fade-it-2', TweenMax.fromTo( $('#fade-it-2'), .7, {css:{opacity: 0}}, {css:{opacity:1}}),0,-150,false);
  controller.addTween('#fade-it-3', TweenMax.fromTo( $('#fade-it-3'), .9, {css:{opacity: 0}}, {css:{opacity:1}}),0,-150,false);
  controller.addTween('#fade-it-4', TweenMax.fromTo( $('#fade-it-4'), 1.1, {css:{opacity: 0}}, {css:{opacity:1}}),0,-150,false);
  controller.addTween('#fade-it-5', TweenMax.fromTo( $('#fade-it-5'), 1.3, {css:{opacity: 0}}, {css:{opacity:1}}),0,-150,false);
  controller.addTween('#fade-it-6', TweenMax.fromTo( $('#fade-it-6'), .5, {css:{opacity: 0}}, {css:{opacity:1}}),0,-150,false);
  controller.addTween('#fade-it-7', TweenMax.fromTo( $('#fade-it-7'), .7, {css:{opacity: 0}}, {css:{opacity:1}}),0,-150,false);
  controller.addTween('#fade-it-8', TweenMax.fromTo( $('#fade-it-8'), .9, {css:{opacity: 0}}, {css:{opacity:1}}),0,-150,false);
  controller.addTween('#fade-it-9', TweenMax.fromTo( $('#fade-it-9'), 1.2, {css:{opacity: 0}}, {css:{opacity:1}}),0,-150,false);
  controller.addTween('#fade-it-10', TweenMax.fromTo( $('#fade-it-10'), 1.4, {css:{opacity: 0}}, {css:{opacity:1}}),0,-150,false);
  controller.addTween('#fade-it-11', TweenMax.fromTo( $('#fade-it-10'), 1.6, {css:{opacity: 0}}, {css:{opacity:1}}),0,-150,false);
  controller.addTween('#fade-it-12', TweenMax.fromTo( $('#fade-it-10'), 1.8, {css:{opacity: 0}}, {css:{opacity:1}}),0,-150,false);
  controller.addTween('#banner-1',TweenMax.fromTo( $('#banner-1'), .5, {css:{opacity: 0}}, {css:{opacity:1}}),0,-150,false);
  controller.addTween('#banner-2', TweenMax.fromTo( $('#banner-2'), .7, {css:{opacity: 0}}, {css:{opacity:1}}),0,-150,false);
});