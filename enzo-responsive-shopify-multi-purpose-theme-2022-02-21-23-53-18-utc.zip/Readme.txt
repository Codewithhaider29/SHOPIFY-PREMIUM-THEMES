Within the Main folder[Enzo-Pack-V1.zip] there will be following folder and files.

Documentation
Outdoor.zip
Fashion.zip
Readme.txt

If you wish to  have Outdoor Theme , just install Outdoor.zip. Or if you wish to have Fashion theme you have to install Fashion.zip.

---------------------------------------------------------

http://wedesignthemes.com/shopify/enzo

---------------------------------------------------------



Kindly refer our documentation for installing the theme and doing customization. 
If you need any assistance, please contact us through support@wedesignthemes.com


Thank You.
Buddhathemes.


