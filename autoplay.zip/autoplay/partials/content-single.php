<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<header class="entry-header">
		<?php if ( 'post' == get_post_type() ) : ?>
			<?php
				/* translators: used between list items, there is a space after the comma */
				$categories_list = get_the_category_list( esc_html__( ', ', 'autoplay' ) );
				if ( $categories_list ) :
			?>
				<span class="cat-links">
					<?php echo $categories_list; ?>
				</span>
			<?php endif; // End if categories ?>
		<?php endif; ?>

		<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>

		<div class="post-meta">
			<?php autoplay_post_meta(); ?>
		</div>
	</header>

	<div class="content">

		<?php autoplay_social_share(); ?>

		<div class="post-content">

			<?php the_content(); ?>
			<?php
				wp_link_pages( array(
					'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'autoplay' ),
					'after'  => '</div>',
				) );
			?>

			<?php
				$tags   = get_the_tags();
				$enable = get_theme_mod( 'autoplay_post_tags', 1 );
				$title  = get_theme_mod( 'autoplay_post_tags_title', esc_html__( 'Topics', 'autoplay' ) );
				if ( $enable && $tags ) :
			?>
				<span class="tag-links">
					<span class="tag-title block-title"><?php echo esc_html( $title ); ?></span>
					<?php foreach( $tags as $tag ) : ?>
						<a href="<?php echo esc_url( get_tag_link( $tag->term_id ) ); ?>">#<?php echo esc_attr( $tag->name ); ?></a>
					<?php endforeach; ?>
				</span>
			<?php endif; ?>

		</div>

	</div>

</article><!-- #post-## -->
