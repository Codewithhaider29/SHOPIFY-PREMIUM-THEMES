<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<div class="thumbnail">
		<?php autoplay_post_thumbnail( 'autoplay-post' ); ?>
	</div>

	<div class="content">
		<header class="entry-header">
			<?php autoplay_post_header(); ?>
		</header>

		<div class="entry-summary">
			<?php the_excerpt(); ?>
		</div>

		<div class="post-meta">
			<?php autoplay_post_meta(); ?>
		</div>
	</div>

</article><!-- #post-## -->
