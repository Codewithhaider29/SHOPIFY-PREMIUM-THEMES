( function( $ ) {

	/**
	 * Responsive video
	 */
	function responsiveVideo() {
		$( '.entry, .widget, .post-thumbnail, .entry-format' ).fitVids();
	}

	/**
	 * Sticky social share
	 */
	function stickySocialShare() {
		$( '.post-share' ).theiaStickySidebar( {
			additionalMarginTop: 30
		} );
	}

	/**
	 * Search pop up
	 */
	function searchPopup() {
		$( '.search-toggle' ).magnificPopup( {
			type: 'inline',
			mainClass: 'popup-fade',
			closeOnBgClick: false,
			closeBtnInside: false,
			callbacks: {
				open: function() {
					setTimeout( function() {
						$( '.search-popup input' ).focus();
					}, 1000 );
				}
			}
		} );
	}

	/**
	 * Most views carousel
	 */
	function mostViewsCarousel() {
		$( '.views-posts .owl-carousel' ).owlCarousel( {
			loop: true,
			nav: true,
			margin: 30,
			dots: false,
			navText: [ '<i class="icon-left-open"></i>', '<i class="icon-right-open"></i>' ],
			responsive: {
				0: {
					items: 1
				},
				600: {
					items: 3
				},
				1000: {
					items: 4
				}
			}
		} )

	}

	/**
	 * Back to top
	 */
	function backToTop() {
		if ( $( '.back-to-top' ).length ) {
			var scrollTrigger = 100,
				backToTop = function() {
					var scrollTop = $( window ).scrollTop();
					if ( scrollTop > scrollTrigger ) {
						$( '.back-to-top' ).addClass( 'show' );
					} else {
						$( '.back-to-top' ).removeClass( 'show' );
					}
				};

			backToTop();
			$( window ).on( 'scroll', function() {
				backToTop();
			} );

			$( '.back-to-top' ).on( 'click', function( e ) {
				e.preventDefault();
				$( 'html, body' ).animate( {
					scrollTop: 0
				}, 700 );
			} );

		}
	}

	/**
	 * Mobile top menu
	 */
	function mobileTopNav() {
		$( '#primary-menu' ).slicknav( {
			label: '',
			prependTo: '.main-navigation .container',
			allowParentLinks: true
		} );
	}

	/**
	 * Mobile main menu
	 */
	function mobileMainNav() {
		$( '#secondary-menu' ).slicknav( {
			label: '',
			prependTo: '.secondary-navigation',
			allowParentLinks: true
		} );
	}

	/**
	 * Popup video
	 */
	function popupVideo() {
		$( '.has-video' ).magnificPopup( {
			type: 'inline',
			midClick: true,
			mainClass: 'popup-fade',
			closeOnBgClick: false,
			closeBtnInside: false,
			fixedContentPos: true
		} );
	}

	// Document ready
	$( function() {
		responsiveVideo();
		stickySocialShare();
		searchPopup();
		mostViewsCarousel();
		backToTop();
		mobileTopNav();
		mobileMainNav();
		popupVideo();
	} );

}( jQuery ) );
