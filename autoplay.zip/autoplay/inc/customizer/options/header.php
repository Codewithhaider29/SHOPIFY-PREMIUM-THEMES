<?php
/**
 * Header Customizer
 */

/**
 * Register the customizer.
 */
function autoplay_header_customize_register( $wp_customize ) {

	// Register new section: Header
	$wp_customize->add_section( 'autoplay_header' , array(
		'title'       => esc_html__( 'Header', 'autoplay' ),
		'panel'       => 'autoplay_options',
		'priority'    => 5
	) );

	// Register top bar background color setting
	$wp_customize->add_setting( 'autoplay_top_bar_bg_color', array(
		'default'           => '#000000',
		'sanitize_callback' => 'autoplay_sanitize_hex_color',
		'transport'         => 'postMessage'
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'autoplay_top_bar_bg_color', array(
		'label'             => esc_html__( 'Top bar background color', 'autoplay' ),
		'section'           => 'autoplay_header',
		'priority'          => 1
	) ) );

	// Register header background color setting
	$wp_customize->add_setting( 'autoplay_header_bg_color', array(
		'default'           => '#14171c',
		'sanitize_callback' => 'autoplay_sanitize_hex_color',
		'transport'         => 'postMessage'
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'autoplay_header_bg_color', array(
		'label'             => esc_html__( 'Header background color', 'autoplay' ),
		'section'           => 'autoplay_header',
		'priority'          => 3
	) ) );

	// Register fixed top bar setting
	$wp_customize->add_setting( 'autoplay_top_bar_fixed', array(
		'default'           => 0,
		'sanitize_callback' => 'autoplay_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'autoplay_top_bar_fixed', array(
		'label'             => esc_html__( 'Fixed top bar', 'autoplay' ),
		'section'           => 'autoplay_header',
		'priority'          => 5,
		'type'              => 'checkbox'
	) );

	// Register header search setting
	$wp_customize->add_setting( 'autoplay_top_bar_search', array(
		'default'           => 1,
		'sanitize_callback' => 'autoplay_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'autoplay_top_bar_search', array(
		'label'             => esc_html__( 'Enable search', 'autoplay' ),
		'section'           => 'autoplay_header',
		'priority'          => 7,
		'type'              => 'checkbox'
	) );

}
add_action( 'customize_register', 'autoplay_header_customize_register' );
