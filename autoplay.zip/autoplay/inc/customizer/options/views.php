<?php
/**
 * Most Views Customizer
 */

/**
 * Register the customizer.
 */
function autoplay_views_customize_register( $wp_customize ) {

	// Register new section: Most Views
	$wp_customize->add_section( 'autoplay_views' , array(
		'title'    => esc_html__( 'Most Views', 'autoplay' ),
		'panel'    => 'autoplay_options',
		'priority' => 15
	) );

	// Register enable most views posts setting
	$wp_customize->add_setting( 'autoplay_views_enable', array(
		'default'           => 1,
		'sanitize_callback' => 'autoplay_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'autoplay_views_enable', array(
		'label'             => esc_html__( 'Enable most views posts', 'autoplay' ),
		'section'           => 'autoplay_views',
		'priority'          => 1,
		'type'              => 'checkbox'
	) );

	// Register most views background color setting
	$wp_customize->add_setting( 'autoplay_views_bg_color', array(
		'default'           => '#14171c',
		'sanitize_callback' => 'autoplay_sanitize_hex_color',
		'transport'         => 'postMessage'
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'autoplay_views_bg_color', array(
		'label'             => esc_html__( 'Background color', 'autoplay' ),
		'section'           => 'autoplay_views',
		'priority'          => 3
	) ) );

	// Register title setting
	$wp_customize->add_setting( 'autoplay_views_title', array(
		'default'           => esc_html__( 'Most Viewed Videos', 'autoplay' ),
		'sanitize_callback' => 'autoplay_sanitize_html',
		'transport'         => 'postMessage'
	) );
	$wp_customize->add_control( 'autoplay_views_title', array(
		'label'             => esc_html__( 'Title', 'autoplay' ),
		'section'           => 'autoplay_views',
		'priority'          => 5,
		'type'              => 'text'
	) );
	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'autoplay_views_title', array(
			'selector'         => '.views-posts-title',
			'settings'         => array( 'autoplay_views_title' ),
			'render_callback'  => function() {
				return autoplay_sanitize_html( get_theme_mod( 'autoplay_views_title' ) );
			}
		) );
	}

	// Register most views number setting
	$wp_customize->add_setting( 'autoplay_views_number', array(
		'default'           => 8,
		'sanitize_callback' => 'absint'
	) );
	$wp_customize->add_control( 'autoplay_views_number', array(
		'label'             => esc_html__( 'Posts number', 'autoplay' ),
		'description'       => esc_html__( 'The number of posts you want to show.', 'autoplay' ),
		'section'           => 'autoplay_views',
		'priority'          => 7,
		'type'              => 'number',
		'input_attrs'       => array(
			'min'  => 0,
			'step' => 1
		)
	) );

	// Register most view time setting
	$wp_customize->add_setting( 'autoplay_views_time', array(
		'default'           => 'all',
		'sanitize_callback' => 'autoplay_sanitize_select',
	) );
	$wp_customize->add_control( 'autoplay_views_time', array(
		'label'             => esc_html__( 'Time', 'autoplay' ),
		'description'       => esc_html__( 'Display most views posts for', 'autoplay' ),
		'section'           => 'autoplay_views',
		'priority'          => 9,
		'type'              => 'radio',
		'choices'           => array(
			'all'   => esc_html__( 'All time', 'autoplay' ),
			'today' => esc_html__( 'Today', 'autoplay' ),
			'week'  => esc_html__( 'This week', 'autoplay' ),
			'month' => esc_html__( 'This month', 'autoplay' )
		)
	) );

}
add_action( 'customize_register', 'autoplay_views_customize_register' );
