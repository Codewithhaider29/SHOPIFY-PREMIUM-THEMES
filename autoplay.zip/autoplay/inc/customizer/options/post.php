<?php
/**
 * Post Customizer
 */

/**
 * Register the customizer.
 */
function autoplay_post_customize_register( $wp_customize ) {

	// Register new section: Post
	$wp_customize->add_section( 'autoplay_post' , array(
		'title'       => esc_html__( 'Posts', 'autoplay' ),
		'description' => esc_html__( 'These options is used for customizing the post area.', 'autoplay' ),
		'panel'       => 'autoplay_options',
		'priority'    => 9
	) );

	// Register post tags setting
	$wp_customize->add_setting( 'autoplay_post_tags', array(
		'default'           => 1,
		'sanitize_callback' => 'autoplay_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'autoplay_post_tags', array(
		'label'             => esc_html__( 'Enable tags', 'autoplay' ),
		'section'           => 'autoplay_post',
		'priority'          => 1,
		'type'              => 'checkbox'
	) );

	// Register post tags title setting
	$wp_customize->add_setting( 'autoplay_post_tags_title', array(
		'default'           => esc_html__( 'Topics', 'autoplay' ),
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage'
	) );
	$wp_customize->add_control( 'autoplay_post_tags_title', array(
		'label'             => esc_html__( 'Post tags title', 'autoplay' ),
		'section'           => 'autoplay_post',
		'priority'          => 3,
		'type'              => 'text',
		'active_callback'   => 'autoplay_is_post_tags_checked'
	) );
	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'autoplay_post_tags_title', array(
			'selector'         => '.tag-title',
			'settings'         => array( 'autoplay_post_tags_title' ),
			'render_callback'  => function() {
				return autoplay_sanitize_html( get_theme_mod( 'autoplay_post_tags_title' ) );
			}
		) );
	}

	// Register Author Box setting
	$wp_customize->add_setting( 'autoplay_author_box', array(
		'default'           => 1,
		'sanitize_callback' => 'autoplay_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'autoplay_author_box', array(
		'label'             => esc_html__( 'Enable author box', 'autoplay' ),
		'section'           => 'autoplay_post',
		'priority'          => 5,
		'type'              => 'checkbox'
	) );

	// Register Next & Prev post setting
	$wp_customize->add_setting( 'autoplay_next_prev_post', array(
		'default'           => 1,
		'sanitize_callback' => 'autoplay_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'autoplay_next_prev_post', array(
		'label'             => esc_html__( 'Enable next & prev post', 'autoplay' ),
		'section'           => 'autoplay_post',
		'priority'          => 7,
		'type'              => 'checkbox'
	) );

	// Register Post Share setting
	$wp_customize->add_setting( 'autoplay_post_share', array(
		'default'           => 1,
		'sanitize_callback' => 'autoplay_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'autoplay_post_share', array(
		'label'             => esc_html__( 'Enable share buttons', 'autoplay' ),
		'section'           => 'autoplay_post',
		'priority'          => 9,
		'type'              => 'checkbox'
	) );

	// Register Related Posts setting
	$wp_customize->add_setting( 'autoplay_related_posts', array(
		'default'           => 1,
		'sanitize_callback' => 'autoplay_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'autoplay_related_posts', array(
		'label'             => esc_html__( 'Enable related posts', 'autoplay' ),
		'section'           => 'autoplay_post',
		'priority'          => 11,
		'type'              => 'checkbox'
	) );

	// Register Related posts title setting
	$wp_customize->add_setting( 'autoplay_related_posts_title', array(
		'default'           => esc_html__( 'You Might Also Like', 'autoplay' ),
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage'
	) );
	$wp_customize->add_control( 'autoplay_related_posts_title', array(
		'label'             => esc_html__( 'Related posts title', 'autoplay' ),
		'section'           => 'autoplay_post',
		'priority'          => 13,
		'type'              => 'text',
		'active_callback'   => 'autoplay_is_related_posts_checked'
	) );
	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'autoplay_related_posts_title', array(
			'selector'         => '.related-posts-title',
			'settings'         => array( 'autoplay_related_posts_title' ),
			'render_callback'  => function() {
				return autoplay_sanitize_html( get_theme_mod( 'autoplay_related_posts_title' ) );
			}
		) );
	}

	// Register Related posts title setting
	$wp_customize->add_setting( 'autoplay_related_posts_number', array(
		'default'           => 5,
		'sanitize_callback' => 'absint',
	) );
	$wp_customize->add_control( 'autoplay_related_posts_number', array(
		'label'             => esc_html__( 'Related posts number', 'autoplay' ),
		'description'       => esc_html__( 'The number of posts you want to show.', 'autoplay' ),
		'section'           => 'autoplay_post',
		'priority'          => 15,
		'type'              => 'number',
		'input_attrs'       => array(
			'min'  => 0,
			'step' => 1
		),
		'active_callback'   => 'autoplay_is_related_posts_checked'
	) );

	// Register Random Posts setting
	$wp_customize->add_setting( 'autoplay_random_posts', array(
		'default'           => 1,
		'sanitize_callback' => 'autoplay_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'autoplay_random_posts', array(
		'label'             => esc_html__( 'Enable random posts', 'autoplay' ),
		'section'           => 'autoplay_post',
		'priority'          => 17,
		'type'              => 'checkbox'
	) );

	// Register Random posts title setting
	$wp_customize->add_setting( 'autoplay_random_posts_title', array(
		'default'           => esc_html__( 'Random Posts', 'autoplay' ),
		'sanitize_callback' => 'esc_attr',
		'transport'         => 'postMessage'
	) );
	$wp_customize->add_control( 'autoplay_random_posts_title', array(
		'label'             => esc_html__( 'Random posts title', 'autoplay' ),
		'section'           => 'autoplay_post',
		'priority'          => 19,
		'type'              => 'text',
		'active_callback'   => 'autoplay_is_random_posts_checked'
	) );
	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'autoplay_random_posts_title', array(
			'selector'         => '.random-posts-title',
			'settings'         => array( 'autoplay_random_posts_title' ),
			'render_callback'  => function() {
				return autoplay_sanitize_html( get_theme_mod( 'autoplay_random_posts_title' ) );
			}
		) );
	}

	// Register Random posts title setting
	$wp_customize->add_setting( 'autoplay_random_posts_number', array(
		'default'           => 6,
		'sanitize_callback' => 'absint',
	) );
	$wp_customize->add_control( 'autoplay_random_posts_number', array(
		'label'             => esc_html__( 'Random posts number', 'autoplay' ),
		'description'       => esc_html__( 'The number of posts you want to show.', 'autoplay' ),
		'section'           => 'autoplay_post',
		'priority'          => 21,
		'type'              => 'number',
		'input_attrs'       => array(
			'min'  => 0,
			'step' => 1
		),
		'active_callback'   => 'autoplay_is_random_posts_checked'
	) );

	// Register Post comment manager setting
	$wp_customize->add_setting( 'autoplay_post_comment', array(
		'default'           => 1,
		'sanitize_callback' => 'autoplay_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'autoplay_post_comment', array(
		'label'             => esc_html__( 'Enable comment on post', 'autoplay' ),
		'section'           => 'autoplay_post',
		'priority'          => 23,
		'type'              => 'checkbox'
	) );

}
add_action( 'customize_register', 'autoplay_post_customize_register' );

/**
 * Active callback when Post Tags checked.
 */
function autoplay_is_post_tags_checked() {
	$tags = get_theme_mod( 'autoplay_post_tags', 1 );

	if ( $tags ) {
		return true;
	} else {
		return false;
	}
}

/**
 * Active callback when Related Posts checked.
 */
function autoplay_is_related_posts_checked() {
	$related = get_theme_mod( 'autoplay_related_posts', 1 );

	if ( $related ) {
		return true;
	} else {
		return false;
	}
}

/**
 * Active callback when Random Posts checked.
 */
function autoplay_is_random_posts_checked() {
	$random = get_theme_mod( 'autoplay_random_posts', 1 );

	if ( $random ) {
		return true;
	} else {
		return false;
	}
}
