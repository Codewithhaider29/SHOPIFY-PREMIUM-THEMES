<?php
/**
 * Trending Customizer
 */

/**
 * Register the customizer.
 */
function autoplay_trending_customize_register( $wp_customize ) {

	// Register new section: Trending
	$wp_customize->add_section( 'autoplay_trending' , array(
		'title'    => esc_html__( 'Trending', 'autoplay' ),
		'panel'    => 'autoplay_options',
		'priority' => 15
	) );

	// Register enable newsletter setting
	$wp_customize->add_setting( 'autoplay_trending_enable', array(
		'default'           => 1,
		'sanitize_callback' => 'autoplay_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'autoplay_trending_enable', array(
		'label'             => esc_html__( 'Enable trending', 'autoplay' ),
		'section'           => 'autoplay_trending',
		'priority'          => 1,
		'type'              => 'checkbox'
	) );

	// Register trending title setting
	$wp_customize->add_setting( 'autoplay_trending_title', array(
		'default'           => esc_html__( 'Trending Now', 'autoplay' ),
		'sanitize_callback' => 'autoplay_sanitize_html',
		'transport'         => 'postMessage'
	) );
	$wp_customize->add_control( 'autoplay_trending_title', array(
		'label'             => esc_html__( 'Trending title', 'autoplay' ),
		'section'           => 'autoplay_trending',
		'priority'          => 3,
		'type'              => 'text'
	) );
	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'autoplay_trending_title', array(
			'selector'         => '.trending-title',
			'settings'         => array( 'autoplay_trending_title' ),
			'render_callback'  => function() {
				return autoplay_sanitize_html( get_theme_mod( 'autoplay_trending_title' ) );
			}
		) );
	}

	// Register trending description setting
	$wp_customize->add_setting( 'autoplay_trending_desc', array(
		'default'           => '',
		'sanitize_callback' => 'autoplay_sanitize_html',
		'transport'         => 'postMessage'
	) );
	$wp_customize->add_control( 'autoplay_trending_desc', array(
		'label'             => esc_html__( 'Trending description', 'autoplay' ),
		'section'           => 'autoplay_trending',
		'priority'          => 5,
		'type'              => 'textarea'
	) );
	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'autoplay_trending_desc', array(
			'selector'         => '.trending-desc',
			'settings'         => array( 'autoplay_trending_desc' ),
			'render_callback'  => function() {
				return autoplay_sanitize_html( get_theme_mod( 'autoplay_trending_desc' ) );
			}
		) );
	}

	// Register trending time setting
	$wp_customize->add_setting( 'autoplay_trending_time', array(
		'default'           => 'all',
		'sanitize_callback' => 'autoplay_sanitize_select',
	) );
	$wp_customize->add_control( 'autoplay_trending_time', array(
		'label'             => esc_html__( 'Time', 'autoplay' ),
		'description'       => esc_html__( 'Display trending posts for', 'autoplay' ),
		'section'           => 'autoplay_trending',
		'priority'          => 7,
		'type'              => 'radio',
		'choices'           => array(
			'all'   => esc_html__( 'All time', 'autoplay' ),
			'today' => esc_html__( 'Today', 'autoplay' ),
			'week'  => esc_html__( 'This week', 'autoplay' ),
			'month' => esc_html__( 'This month', 'autoplay' )
		)
	) );

}
add_action( 'customize_register', 'autoplay_trending_customize_register' );
