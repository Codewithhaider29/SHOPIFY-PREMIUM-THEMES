<?php
/**
 * Archive Customizer
 */

/**
 * Register the customizer.
 */
function autoplay_archive_customize_register( $wp_customize ) {

	// Register new section: Archive
	$wp_customize->add_section( 'autoplay_archive' , array(
		'title'       => esc_html__( 'Archive', 'autoplay' ),
		'panel'       => 'autoplay_options',
		'priority'    => 7
	) );

	// Register blog layouts setting
	$wp_customize->add_setting( 'autoplay_archive_layouts', array(
		'default'           => '2c-l',
		'sanitize_callback' => 'autoplay_sanitize_select',
	) );
	$wp_customize->add_control( 'autoplay_archive_layouts', array(
		'label'             => esc_html__( 'Archive Layout', 'autoplay' ),
		'section'           => 'autoplay_archive',
		'priority'          => 1,
		'type'              => 'radio',
		'choices'           => array(
			'2c-l'   => esc_html__( 'Right sidebar', 'autoplay' ),
			'2c-r'   => esc_html__( 'Left sidebar', 'autoplay' ),
			'1c'     => esc_html__( 'No sidebar', 'autoplay' )
		),
	) );

	// Register blog types setting
	$wp_customize->add_setting( 'autoplay_archive_types', array(
		'default'           => 'default',
		'sanitize_callback' => 'autoplay_sanitize_select',
	) );
	$wp_customize->add_control( 'autoplay_archive_types', array(
		'label'             => esc_html__( 'Archive Types', 'autoplay' ),
		'section'           => 'autoplay_archive',
		'priority'          => 3,
		'type'              => 'radio',
		'choices'           => array(
			'default'       => esc_html__( 'Default', 'autoplay' ),
			'grid-two'      => esc_html__( 'Grid 2 columns', 'autoplay' ),
			'grid-three'    => esc_html__( 'Grid 3 columns', 'autoplay' )
		),
	) );

}
add_action( 'customize_register', 'autoplay_archive_customize_register' );
