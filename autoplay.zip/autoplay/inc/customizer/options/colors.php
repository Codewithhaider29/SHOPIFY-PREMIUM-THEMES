<?php
/**
 * Colors Customizer
 */

/**
 * Register the customizer.
 */
function autoplay_colors_customize_register( $wp_customize ) {

	// Register predefined colors setting
	$wp_customize->add_setting( 'autoplay_predefined_colors', array(
		'default'           => 'default',
		'sanitize_callback' => 'autoplay_sanitize_select',
	) );
	$wp_customize->add_control( 'autoplay_predefined_colors', array(
		'label'             => esc_html__( 'Predefined Colors', 'autoplay' ),
		'section'           => 'colors',
		'priority'          => 1,
		'type'              => 'radio',
		'choices'           => array(
			'default' => esc_html__( 'Default', 'autoplay' ),
			'pink'    => esc_html__( 'Pink', 'autoplay' ),
			'purple'  => esc_html__( 'Purple', 'autoplay' ),
			'green'   => esc_html__( 'Green', 'autoplay' ),
			'blue'    => esc_html__( 'Blue', 'autoplay' )
		)
	) );

	// Register accent color setting
	$wp_customize->add_setting( 'autoplay_accent_color', array(
		'default'           => '#ee5b6a',
		'sanitize_callback' => 'autoplay_sanitize_hex_color'
	) );
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'autoplay_accent_color', array(
		'label'             => esc_html__( 'Accent Color', 'autoplay' ),
		'description'       => esc_html__( 'To get this color picker working, please set the Predefined Colors to &quot;Default&quot;', 'autoplay' ),
		'section'           => 'colors',
		'priority'          => 3
	) ) );

	// Register body colors setting
	$wp_customize->add_setting( 'autoplay_body_colors_text', array(
		'default'           => '',
		'sanitize_callback' => 'esc_attr'
	) );
	$wp_customize->add_control( new Autoplay_Custom_Text( $wp_customize, 'autoplay_body_colors_text', array(
		'label'             => esc_html__( 'Body', 'autoplay' ),
		'description'       => esc_html__( 'Body area colors setting.', 'autoplay' ),
		'section'           => 'colors',
		'priority'          => 5
	) ) );

		// Register body background color setting
		$wp_customize->add_setting( 'autoplay_body_bg_color', array(
			'default'           => '#ffffff',
			'sanitize_callback' => 'autoplay_sanitize_hex_color',
			'transport'         => 'postMessage'
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'autoplay_body_bg_color', array(
			'label'             => esc_html__( 'Background Color', 'autoplay' ),
			'section'           => 'colors',
			'priority'          => 7
		) ) );

		// Register body text color setting
		$wp_customize->add_setting( 'autoplay_body_text_color', array(
			'default'           => '#555555',
			'sanitize_callback' => 'autoplay_sanitize_hex_color'
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'autoplay_body_text_color', array(
			'label'             => esc_html__( 'Text Color', 'autoplay' ),
			'section'           => 'colors',
			'priority'          => 9
		) ) );

		// Register body heading color setting
		$wp_customize->add_setting( 'autoplay_body_heading_color', array(
			'default'           => '#333333',
			'sanitize_callback' => 'autoplay_sanitize_hex_color'
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'autoplay_body_heading_color', array(
			'label'             => esc_html__( 'Heading Color', 'autoplay' ),
			'section'           => 'colors',
			'priority'          => 11
		) ) );

}
add_action( 'customize_register', 'autoplay_colors_customize_register' );
