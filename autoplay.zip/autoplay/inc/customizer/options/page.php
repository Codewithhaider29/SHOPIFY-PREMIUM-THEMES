<?php
/**
 * Page Customizer
 */

/**
 * Register the customizer.
 */
function autoplay_page_customize_register( $wp_customize ) {

	// Register new section: Page
	$wp_customize->add_section( 'autoplay_page' , array(
		'title'    => esc_html__( 'Pages', 'autoplay' ),
		'panel'    => 'autoplay_options',
		'priority' => 11
	) );

	// Register Page comment manager setting
	$wp_customize->add_setting( 'autoplay_page_comment', array(
		'default'           => 1,
		'sanitize_callback' => 'autoplay_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'autoplay_page_comment', array(
		'label'             => esc_html__( 'Enable comment on Pages', 'autoplay' ),
		'section'           => 'autoplay_page',
		'priority'          => 1,
		'type'              => 'checkbox'
	) );

	// Register Page title setting
	$wp_customize->add_setting( 'autoplay_page_title', array(
		'default'           => 1,
		'sanitize_callback' => 'autoplay_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'autoplay_page_title', array(
		'label'             => esc_html__( 'Enable page title', 'autoplay' ),
		'section'           => 'autoplay_page',
		'priority'          => 3,
		'type'              => 'checkbox'
	) );

	// Register Page autoplay image setting
	$wp_customize->add_setting( 'autoplay_page_autoplay_image', array(
		'default'           => 0,
		'sanitize_callback' => 'autoplay_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'autoplay_page_autoplay_image', array(
		'label'             => esc_html__( 'Enable page featured image', 'autoplay' ),
		'section'           => 'autoplay_page',
		'priority'          => 5,
		'type'              => 'checkbox'
	) );

}
add_action( 'customize_register', 'autoplay_page_customize_register' );
