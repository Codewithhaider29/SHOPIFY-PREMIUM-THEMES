<?php
/**
 * Elementor compatibility and custom functions
 *
 * @package    Autoplay
 * @author     Theme Junkie
 * @copyright  Copyright (c) 2018, Theme Junkie
 * @license    http://www.gnu.org/licenses/gpl-2.0.html
 * @since      1.0.0
 */

namespace Elementor;

/**
 * Elementor setup function.
 *
 * @return void
 */
function autoplay_update_elementor_global_option () {
	update_option( 'elementor_disable_color_schemes', 'yes' );
	update_option( 'elementor_disable_typography_schemes', 'yes' );
	update_option( 'elementor_container_width', '1110' );
}
add_action( 'after_switch_theme', 'Elementor\autoplay_update_elementor_global_option' );

/**
 * Add widgets
 */
function autoplay_elementor_custom_widgets() {
	require_once get_template_directory() . '/inc/elementor/widgets/featured.php';
	require_once get_template_directory() . '/inc/elementor/widgets/trending.php';
	require_once get_template_directory() . '/inc/elementor/widgets/videos.php';
}
add_action( 'elementor/widgets/widgets_registered', 'Elementor\autoplay_elementor_custom_widgets' );

/**
 * Add new category for Elementor.
 */
function elementor_init() {

	$elementor = \Elementor\Plugin::$instance;

	// Add element category in panel
	$elementor->elements_manager->add_category(
		'autoplay-elements',
		[
			'title' => esc_html__( 'Autoplay Elements', 'autoplay' ),
			'icon' => 'font',
		],
		1
	);
}
add_action( 'elementor/init', 'Elementor\elementor_init', 1 );
