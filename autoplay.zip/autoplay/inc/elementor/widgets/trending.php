<?php
/**
 * Trending posts widgets
 */

namespace Elementor;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Autoplay_Trending_Posts_Widget extends Widget_Base {

	public function get_name() {
		return 'autoplay-trending-posts';
	}

	public function get_title() {
		return esc_html__( 'Trending Posts', 'autoplay' );
	}

	public function get_icon() {
		return 'eicon-favorite';
	}

	public function get_categories() {
		return [ 'autoplay-elements' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'section_posts',
			[
				'label' => esc_html__( 'Posts', 'autoplay' ),
			]
		);

		$this->add_control(
			'title',
			[
				'label'         => esc_html__( 'Title', 'autoplay' ),
				'default'       => esc_html__( 'Trending Now', 'autoplay' ),
				'type'          => Controls_Manager::TEXT,
				'label_block'   => true,
			]
		);

		$this->add_control(
			'desc',
			[
				'label'         => esc_html__( 'Description', 'autoplay' ),
				'type'          => Controls_Manager::TEXTAREA,
				'label_block'   => true,
			]
		);

		$this->add_control(
			'time',
			[
				'label'         => esc_html__( 'Time', 'autoplay' ),
				'type'          => Controls_Manager::SELECT,
				'default'       => 'all',
				'options'       => [
					'all'       => esc_html__( 'All Time', 'autoplay' ),
					'today'     => esc_html__( 'Today', 'autoplay' ),
					'week'      => esc_html__( 'This Week', 'autoplay' ),
					'month'     => esc_html__( 'This Month', 'autoplay' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_elements',
			[
				'label' => esc_html__( 'Elements', 'autoplay' )
			]
		);

		$this->add_control(
			'show_title',
			[
				'label'         => esc_html__( 'Display Title', 'autoplay' ),
				'type'          => Controls_Manager::SELECT,
				'default'       => 'true',
				'options'       => [
					'true'      => esc_html__( 'Show', 'autoplay' ),
					'false'     => esc_html__( 'Hide', 'autoplay' ),
				],
			]
		);

		$this->add_control(
			'show_desc',
			[
				'label'         => esc_html__( 'Display Description', 'autoplay' ),
				'type'          => Controls_Manager::SELECT,
				'default'       => 'true',
				'options'       => [
					'true'      => esc_html__( 'Show', 'autoplay' ),
					'false'     => esc_html__( 'Hide', 'autoplay' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_title_color',
			[
				'label'         => esc_html__( 'Title', 'autoplay' ),
				'tab'           => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'         => esc_html__( 'Color', 'autoplay' ),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .autoplay-elements.trending-posts .layout-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_desc_color',
			[
				'label'         => esc_html__( 'Description', 'autoplay' ),
				'tab'           => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'desc_color',
			[
				'label'         => esc_html__( 'Color', 'autoplay' ),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .autoplay-elements.trending-posts .layout-desc' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_post_title_color',
			[
				'label'         => esc_html__( 'Post Title', 'autoplay' ),
				'tab'           => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'post_title_color',
			[
				'label'         => esc_html__( 'Color', 'autoplay' ),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .autoplay-elements.trending-posts .entry-title a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'post_title_color_hover',
			[
				'label'         => esc_html__( 'Hover Color', 'autoplay' ),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .autoplay-elements.trending-posts .entry-title a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings();

		// Vars
		$time  = $settings['time'];

		$args = array(
			'meta_key'            => 'post_views',
			'orderby'             => 'meta_value_num',
			'posts_per_page'      => 3,
			'ignore_sticky_posts' => 1,
		);

		// Get the date
		$today = getdate();

		if ( $time == 'today' ) {
			$args['date_query'] = array(
				array(
					'year'  => $today['year'],
					'month' => $today['mon'],
					'day'   => $today['mday'],
				),
			);
		}

		if ( $time == 'week' ) {
			$args['date_query'] = array(
				array(
					'year' => $today['year'],
					'week' => date( 'W' ),
				),
			);
		}

		if ( $time == 'month' ) {
			$args['date_query'] = array(
				array(
					'year'  => $today['year'],
					'month' => $today['mon'],
				),
			);
		}

		// Build the WordPress query
		$trending = new \WP_Query( $args );

		// Output posts
		if ( $trending->have_posts() ) :

			// Vars
			$title      = $settings['title'];
			$show_title = $settings['show_title'];
			$desc       = $settings['desc'];
			$show_desc  = $settings['show_desc'];

			// Wrapper classes
			$wrap_classes = array( 'autoplay-elements', 'trending-posts' );

			$wrap_classes = implode( ' ', $wrap_classes ); ?>

			<div class="<?php echo esc_attr( $wrap_classes ); ?>">

				<div class="trending">

					<div class="posts">

						<div class="trending-info post-layout-grid-four">
							<?php
							// Display title if $show_title is true
							if ( $show_title == 'true' ) : ?>
								<div class="trending-title layout-title block-title"><?php echo esc_html( $title ); ?></div>
							<?php endif; ?>

							<?php
							// Display description if $show_desc is true
							if ( $show_desc == 'true' ) : ?>
								<div class="trending-desc layout-desc"><?php echo esc_html( $desc ); ?></div>
							<?php endif; ?>
						</div>

						<?php while ( $trending->have_posts() ) : $trending->the_post(); ?>

							<article class="post-layout-grid-four">

								<div class="thumbnail">
									<?php autoplay_post_thumbnail( 'autoplay-post-small' ); ?>
								</div>

								<div class="content">
									<header class="entry-header">
										<?php autoplay_post_header(); ?>
									</header>

									<div class="post-meta">
										<?php autoplay_post_meta(); ?>
									</div>
								</div>

							</article><!-- #post-## -->

						<?php endwhile; ?>

					</div>

				</div>

			</div>

			<?php
			// Reset the post data to prevent conflicts with WP globals
			wp_reset_postdata();

		// If no posts are found display message
		else : ?>

			<div class="trending">
				<div class="container">
					<p><?php _e( 'There is no trending post. Please try another Time option.', 'autoplay' ); ?></p>
				</div>
			</div>

		<?php
		// End post check
		endif; ?>

	<?php
	}

}

Plugin::instance()->widgets_manager->register_widget_type( new Autoplay_Trending_Posts_Widget() );
