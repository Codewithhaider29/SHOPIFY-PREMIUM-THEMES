<?php
/**
 * Video posts widgets
 */

namespace Elementor;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Autoplay_Videos_Widget extends Widget_Base {

	public function get_name() {
		return 'autoplay-video-posts';
	}

	public function get_title() {
		return esc_html__( 'Video Posts', 'autoplay' );
	}

	public function get_icon() {
		return 'eicon-posts-grid';
	}

	public function get_categories() {
		return [ 'autoplay-elements' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'section_posts',
			[
				'label' => esc_html__( 'Posts', 'autoplay' ),
			]
		);

		$this->add_control(
			'title',
			[
				'label'         => esc_html__( 'Title', 'autoplay' ),
				'type'          => Controls_Manager::TEXT,
				'label_block'   => true,
			]
		);

		$this->add_control(
			'count',
			[
				'label'         => esc_html__( 'Number of Posts', 'autoplay' ),
				'description'   => esc_html__( 'The number of posts you want to show', 'autoplay' ),
				'type'          => Controls_Manager::TEXT,
				'default'       => '6',
				'label_block'   => true,
			]
		);

		$this->add_control(
			'order',
			[
				'label'         => esc_html__( 'Order', 'autoplay' ),
				'type'          => Controls_Manager::SELECT,
				'default'       => '',
				'options'       => [
					''          => esc_html__( 'Default', 'autoplay' ),
					'DESC'      => esc_html__( 'DESC', 'autoplay' ),
					'ASC'       => esc_html__( 'ASC', 'autoplay' ),
				],
			]
		);

		$this->add_control(
			'orderby',
			[
				'label'         => esc_html__( 'Order By', 'autoplay' ),
				'type'          => Controls_Manager::SELECT,
				'default'       => '',
				'options'       => [
					''              => esc_html__( 'Default', 'autoplay' ),
					'date'          => esc_html__( 'Date', 'autoplay' ),
					'title'         => esc_html__( 'Title', 'autoplay' ),
					'name'          => esc_html__( 'Name', 'autoplay' ),
					'modified'      => esc_html__( 'Modified', 'autoplay' ),
					'author'        => esc_html__( 'Author', 'autoplay' ),
					'rand'          => esc_html__( 'Random', 'autoplay' ),
					'ID'            => esc_html__( 'ID', 'autoplay' ),
					'comment_count' => esc_html__( 'Comment Count', 'autoplay' ),
					'menu_order'    => esc_html__( 'Menu Order', 'autoplay' ),
				],
			]
		);

		$this->add_control(
			'include_categories',
			[
				'label'         => esc_html__( 'Include Categories', 'autoplay' ),
				'description'   => esc_html__( 'Enter the categories slugs seperated by a "comma"', 'autoplay' ),
				'type'          => Controls_Manager::TEXT,
				'label_block'   => true,
			]
		);

		$this->add_control(
			'include_tags',
			[
				'label'         => esc_html__( 'Include Tags', 'autoplay' ),
				'description'   => esc_html__( 'Enter the tags slugs seperated by a "comma"', 'autoplay' ),
				'type'          => Controls_Manager::TEXT,
				'label_block'   => true,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_elements',
			[
				'label' => esc_html__( 'Elements', 'autoplay' )
			]
		);

		$this->add_control(
			'show_title',
			[
				'label'        => esc_html__( 'Show Title', 'autoplay' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Show', 'autoplay' ),
				'label_off'    => esc_html__( 'Hide', 'autoplay' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'view_more',
			[
				'label'        => esc_html__( 'Show View More', 'autoplay' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'label_on'     => esc_html__( 'Show', 'autoplay' ),
				'label_off'    => esc_html__( 'Hide', 'autoplay' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'view_more_text',
			[
				'label'         => esc_html__( 'View More Text', 'autoplay' ),
				'type'          => Controls_Manager::TEXT,
				'default'       => esc_html__( 'View More', 'autoplay' ),
				'label_block' 	=> true,
			]
		);

		$this->add_control(
			'view_more_url',
			[
				'label'         => esc_html__( 'View More URL', 'autoplay' ),
				'type'          => Controls_Manager::URL,
				'default'       => [
					'url'         => 'http://',
					'is_external' => '',
				],
				'show_external' => true
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_title_color',
			[
				'label'         => esc_html__( 'Title', 'autoplay' ),
				'tab'           => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'         => esc_html__( 'Color', 'autoplay' ),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .autoplay-elements.video-posts .layout-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'          => 'title_typography',
				'selector'      => '{{WRAPPER}} .autoplay-elements.video-posts .layout-title',
				'scheme'        => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_view_more_color',
			[
				'label'         => esc_html__( 'View More', 'autoplay' ),
				'tab'           => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'view_more_color',
			[
				'label'         => esc_html__( 'Color', 'autoplay' ),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .autoplay-elements.video-posts .view-more' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'view_more_color_hover',
			[
				'label'         => esc_html__( 'Hover Color', 'autoplay' ),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .autoplay-elements.video-posts .view-more:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'          => 'view_more_typography',
				'selector'      => '{{WRAPPER}} .autoplay-elements.video-posts .view-more',
				'scheme'        => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_post_title_color',
			[
				'label'         => esc_html__( 'Post Title', 'autoplay' ),
				'tab'           => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'post_title_color',
			[
				'label'         => esc_html__( 'Color', 'autoplay' ),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .autoplay-elements.video-posts .entry-title a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'post_title_color_hover',
			[
				'label'         => esc_html__( 'Hover Color', 'autoplay' ),
				'type'          => Controls_Manager::COLOR,
				'selectors'     => [
					'{{WRAPPER}} .autoplay-elements.video-posts .entry-title a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'          => 'post_title_typography',
				'selector'      => '{{WRAPPER}} .autoplay-elements.video-posts .entry-title',
				'scheme'        => Scheme_Typography::TYPOGRAPHY_1,
			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings();

		// Vars
		$count      = $settings['count'];
		$order      = $settings['order'];
		$orderby    = $settings['orderby'];
		$categories = $settings['include_categories'];
		$tags       = $settings['include_tags'];

		$args = array(
			'post_type'         => 'post',
			'posts_per_page'    => absint( $count ),
			'order'             => esc_attr( $order ),
			'orderby'           => esc_attr( $orderby ),
			'tax_query'         => array(
				'relation'      => 'AND',
			),
		);

		// Include category
		if ( ! empty( $categories ) ) {

			// Sanitize category and convert to array
			$categories = str_replace( ', ', ',', $categories );
			$categories = explode( ',', $categories );

			// Add to query arg
			$args['tax_query'][] = array(
				'taxonomy' => 'category',
				'field'    => 'slug',
				'terms'    => $categories,
				'operator' => 'IN',
			);

		}

		// Include tag
		if ( ! empty( $tags ) ) {

			// Sanitize category and convert to array
			$tags = str_replace( ', ', ',', $tags );
			$tags = explode( ',', $tags );

			// Add to query arg
			$args['tax_query'][] = array(
				'taxonomy' => 'post_tag',
				'field'    => 'slug',
				'terms'    => $tags,
				'operator' => 'IN',
			);

		}

		// Build the WordPress query
		$videos = new \WP_Query( $args );

		// Output posts
		if ( $videos->have_posts() ) :

			// Vars
			$title          = $settings['title'];
			$show_title     = $settings['show_title'];
			$view_more      = $settings['view_more'];
			$view_more_text = $settings['view_more_text'];
			$view_more_url  = $settings['view_more_url'];

			// Wrapper classes
			$wrap_classes = array( 'autoplay-elements', 'video-posts' );

			$wrap_classes = implode( ' ', $wrap_classes ); ?>

			<div class="<?php echo esc_attr( $wrap_classes ); ?>">

				<?php
				// Display title if $title is true
				if ( $title && ( $show_title == 'yes' ) ) : ?>

					<div class="layout-title block-title"><?php echo esc_html( $title ); ?></div>

					<?php
					$url    = $view_more_url['url'];
					$target = $view_more_url['is_external'] ? 'target="_blank"' : '';
					// Display view more
					if ( $view_more  ) : ?>
						<a class="view-more" href="<?php echo esc_url( $url ); ?>" <?php echo $target; ?>><?php echo esc_html( $view_more_text ); ?></a>
					<?php endif; ?>

				<?php endif; ?>

				<div class="posts">
					<?php while ( $videos->have_posts() ) : $videos->the_post(); ?>
						<div <?php post_class( 'post-layout-grid-three' ); ?>>

							<div class="thumbnail">
								<?php autoplay_post_thumbnail( 'autoplay-post-small' ); ?>
							</div>

							<div class="post-content">
								<header class="entry-header">
									<?php autoplay_post_header(); ?>
								</header>

								<div class="post-meta">
									<?php autoplay_post_meta(); ?>
								</div>
							</div>

						</div>
					<?php endwhile; ?>
				</div>

			</div>

			<?php
			// Reset the post data to prevent conflicts with WP globals
			wp_reset_postdata();

		// If no posts are found display message
		else : ?>

			<div class="video-posts">
				<div class="container">
					<p><?php _e( 'It seems we can&rsquo;t find what you&rsquo;re looking for.', 'autoplay' ); ?></p>
				</div>
			</div>

		<?php
		// End post check
		endif; ?>

	<?php
	}

}

Plugin::instance()->widgets_manager->register_widget_type( new Autoplay_Videos_Widget() );
