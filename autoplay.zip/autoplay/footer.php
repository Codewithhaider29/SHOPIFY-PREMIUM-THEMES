		</div><!-- #content -->

		<?php autoplay_most_views(); ?>

		<footer id="colophon" class="site-footer">

			<div class="container">
				<?php get_template_part( 'sidebar', 'footer' ); // Loads the sidebar-footer.php template. ?>
			</div>

			<div class="container">
				<div class="site-info">
					<?php autoplay_footer_branding(); ?>
					<?php autoplay_footer_text(); ?>
				</div>
			</div><!-- .site-info -->

		</footer><!-- #colophon -->

	</div><!-- .wide-container -->

</div><!-- #page -->

<div id="search-overlay" class="search-popup popup-content mfp-hide">
	<form method="get" class="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
		<input type="search" class="search-field field" placeholder="<?php echo esc_attr_x( 'Search', 'placeholder', 'autoplay' ) ?>" value="<?php echo get_search_query() ?>" name="s" title="<?php echo esc_attr_x( 'Search for:', 'label', 'autoplay' ) ?>" />
	</form>
</div>

<a href="#" class="back-to-top" title="<?php esc_html_e( 'Back to top', 'autoplay' ); ?>"><i class="icon-up-open" aria-hidden="true"></i></a>

<?php wp_footer(); ?>

</body>
</html>
