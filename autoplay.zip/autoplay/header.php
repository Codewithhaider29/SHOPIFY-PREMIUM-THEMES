<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">

<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<div id="page" class="site">

	<div class="wide-container">

		<?php if ( has_nav_menu ( 'primary' ) ) : ?>
			<nav class="main-navigation">
				<div class="container">
					<?php wp_nav_menu(
						array(
							'theme_location'  => 'primary',
							'menu_id'         => 'primary-menu',
							'menu_class'      => 'primary-menu',
							'container'       => ''
						)
					); ?>

					<?php if ( has_nav_menu ( 'social' ) ) : ?>
						<?php wp_nav_menu(
							array(
								'theme_location'  => 'social',
								'link_before'     => '<span class="screen-reader-text">',
								'link_after'      => '</span>',
								'depth'           => 1,
								'container'       => '',
								'menu_id'         => 'social-menu',
								'menu_class'      => 'social-menu'
							)
						); ?>
					<?php endif; ?>
				</div>
			</nav>
		<?php endif; ?>

		<header id="masthead" class="site-header">
			<div class="container">

				<?php autoplay_site_branding(); ?>

				<?php if ( has_nav_menu ( 'secondary' ) ) : ?>
					<nav class="secondary-navigation">
						<?php wp_nav_menu(
							array(
								'theme_location'  => 'secondary',
								'menu_id'         => 'secondary-menu',
								'menu_class'      => 'secondary-menu',
								'container_class' => 'secondary-menu-items'
							)
						); ?>
					</nav>
				<?php endif; ?>

				<?php
					$search = get_theme_mod( 'autoplay_top_bar_search', 1 );
					if ( $search ) :
				?>
					<div class="search-icon">
						<a href="#search-overlay" class="search-toggle">
							<i class="icon-search"></i>
						</a>
					</div>
				<?php endif; ?>

			</div>
		</header><!-- #masthead -->

		<?php autoplay_trending(); ?>

		<?php autoplay_post_cover(); ?>

		<div id="content" class="site-content">
