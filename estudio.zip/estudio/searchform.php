<div class="search-form">
	<form action="<?php echo home_url(); ?>" id="searchform" method="get">
		<input name="s" type="text" placeholder="Type and hit search"></input>
		<button type="submit"><?php _e('Search','themejunkie'); ?></button>
		<div class="clear"></div>
	</form>
</div><!-- .search-form -->