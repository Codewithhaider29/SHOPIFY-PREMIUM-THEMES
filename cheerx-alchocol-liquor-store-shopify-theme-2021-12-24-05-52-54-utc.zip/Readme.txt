Within the Main folder[themeforest-cheerx-beer-shopify-theme.zip] there will be following folder and files.


Documentation
cheerx-beer.zip
Readme.txt
Log.txt
 
You need to install the cheerx-beer.zip file.

Online documentation URL:
http://themessupport.com/documentation/doc/cheerx-beer/

Kindly refer our documentation for installing the theme and doing customization. 
If you need any assistance, plz contact us through support@wedesignthemes.com


Thankyou,
Designthemes.



