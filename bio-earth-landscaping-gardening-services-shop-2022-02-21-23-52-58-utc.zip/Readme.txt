Within the main folder [themeforest-bioearth-shopify-theme.zip] there will be following folder and files.


Documentation
Readme.txt
Log.txt
bioearth.zip   



-------------------------------------------------------------------
https://themessupport.com/buddha-shop/bioearth/

Kindly refer our documentation for installing the theme and doing customization. 
If you need any assistance, plz contact us through support@wedesignthemes.com


Thank You.
DesignThemes.










