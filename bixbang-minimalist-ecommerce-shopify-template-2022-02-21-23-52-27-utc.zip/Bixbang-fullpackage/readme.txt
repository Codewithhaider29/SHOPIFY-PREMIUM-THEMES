Hello dear customer.

We are happy to present our most featured update for Bixbang - Minimalist eCommerce Theme
It includes hundreds of improvements:
- code review, code remake. Two times faster page load.
- theme setting rework. No more HTML in theme configuration. Only user friendly controls
- Home page builder. Now theme fully support and use latest Shopify features.
- 10 new skins: Fashion Shop, Electronic, Furniture store, Jewelry Store, Watch store, Sneaker Store, Parallax design, Collection skin, instagram shop ( comming soon ), slider skin

Setup demo:

step1: open folder "Demo Data" 

Step2: Open file txt with home page skin do you want and copy text to that folder then

Step3: Go to admin shopify panel edit theme ( bixbang code editor menu )

Step4: open edit file Config > Settings_data.json

step5: pates your text content at step 2 to file settings_data.json

You done!


Document ready: http://spyropress.com/documents.html

Ticket Support: http://spyropress.com/forums/

Email questions: webmaster@spyropress.com

I hope you will appreciate our work and love Bixbang - Minimalist eCommerce Theme as we do.

Thank you for your understanding.

Best regards, SpyroPress Team