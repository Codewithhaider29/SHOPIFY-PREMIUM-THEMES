jQuery(document).ready(function($) {
    // Cache the Window object
	$window = $(window);
	var lastpos = $(window).scrollTop(), headerFixed = $(".yolo-header"), body = $("body"), mainnav = $(".yolo-wrap-menu"), // menu
	header = $(".site-header"), // header ( logo )
	mainnav2 = $(".fixed_top"), boxed_layout = $(".boxed-layout .yolo-header"), headerHeight = headerFixed.outerHeight();
	// Add class for mainmenu when scroller
	(function() {
		if ($("section").hasClass("yolo-page-heading")) {
			// has page title
			if ($(".yolo-page-heading").hasClass("header_transparent")) {} else {}
		} else {
			// hasn't page title
			if ($("header").hasClass("header_transparent")) {
				// header transparent
				$("#primary.header_transparent").css("margin-top", "0px");
			}
		}
		if (mainnav.length) {
			elmHeightMainnav = mainnav.outerHeight(true);
			elmHeightHeader = header.outerHeight(true);
			elmHeight = elmHeightHeader + elmHeightMainnav;
			// height of menu and header
			elmHeight2 = elmHeight + 0;
			elmHeight3 = elmHeight + 700;
			$(window).scroll(function() {
				var scrolltop = $(window).scrollTop();
				mainnav2.addClass("animated");
				if (scrolltop > elmHeight3) {
					mainnav2.addClass("affix");
					mainnav2.removeClass("slideOutUp");
					mainnav2.addClass("slideInDown");
				} else if (elmHeight2 < scrolltop && scrolltop <= elmHeight3) {
					mainnav2.removeClass("slideInDown");
					mainnav2.addClass("slideOutUp");
				} else if (scrolltop <= elmHeight2) {
					mainnav2.removeClass("affix");
					mainnav2.removeClass("slideOutUp");
				}
			});
		}
	})();
	
	$(".animsition").animsition({
        inClass: "fade-in-down-sm",
        outClass: "fade-out",
        inDuration: 1e3,
        outDuration: 800,
        linkElement: "li.yolo-menu a",
        loading: true,
        loadingParentElement: "body",
        //animsition wrapper element
        loadingClass: "animsition-loading",
        loadingInner: "",
        // e.g '<img src="loading.svg" />'
        timeout: true,
        timeoutCountdown: 5e3,
        onLoadEvent: true,
        browser: [ "animation-duration", "-webkit-animation-duration" ],
        // "browser" option allows you to disable the "animsition" in case the css property in the array is not supported by your browser.
        // The default setting is to disable the "animsition" in a browser that does not support "animation-duration".
        overlay: false,
        overlayClass: "animsition-overlay-slide",
        overlayParentElement: "body",
        transition: function(url) {
            window.location.href = url;
        }
    });
    //Init masonry isotope
    $(".masonry").each(function() {
        var self = $(this);
        var $container = $(this).find(".masonry-container");
        var $filter = $(this).find(".masonry-filters a");
        var masonry_options = {
            gutter: 0
        };
        $container.isotope({
            itemSelector: ".masonry-item",
            transitionDuration: "0.8s",
            masonry: masonry_options,
            layoutMode: "fitRows"
        });
        imagesLoaded(self, function() {
            $container.isotope("layout");
        });
        $(window).resize(function() {
            $container.isotope("layout");
        });
        $filter.on( "click", function(e) {
            e.stopPropagation();
            e.preventDefault();
            var $this = jQuery(this);
            // don't proceed if already selected
            if ($this.hasClass("selected")) {
                return false;
            }
            self.find(".masonry-result h3").text($this.text());
            var filters = $this.closest("ul");
            filters.find(".selected").removeClass("selected");
            $this.addClass("selected");
            var options = {
                layoutMode: "fitRows",
                transitionDuration: "0.8s",
                masonry: {
                    gutter: 0
                }
            }, key = filters.attr("data-option-key"), value = $this.attr("data-option-value");
            value = value === "false" ? false : value;
            options[key] = value;
            $container.isotope(options);
        });
    });
    var onArrange = function() {
        $(".posts-loop-title h3 span").html($(".masonry-item:visible").length);
        if ($(".masonry-item:visible").length <= 0 && $(".loadmore-action .btn-loadmore").is(":visible")) {
            $(".loadmore-action .btn-loadmore").click();
        }
    };
	
	//Scroll to top
	$(window).scroll(function() {
		$(this).scrollTop() > 500 ? $(".go-to-top").addClass("on") : $(".go-to-top").removeClass("on");
	});
	$("body").on("click", ".go-to-top", function() {
		return $("html, body").animate({
			scrollTop: 0
		}, 800), !1;
	});
	
	//Popup Search form
	$(".search-button").on( "click", function() {
		$(".searchbar").fadeIn(1).addClass("show");
	}); 
	$(".search-remove").on( "click", function() {
		$(".searchbar").fadeOut(1).removeClass("show");
	});
	
	//Owl Carousel 2 items
	$('.carousel-2-items .carousel-items').owlCarousel({
		items : 2,
		itemsCustom : false,
		itemsDesktop : [1320, 2],
		itemsDesktopSmall : [1199, 2],
		itemsTablet : [991, 1],
		itemsTabletSmall : [767, 2],
		itemsMobile : [479, 1],
		slideSpeed:500,
		paginationSpeed:800,
		rewindSpeed:1000,
		autoHeight: false,
		addClassActive: true,
		autoPlay: false,
		loop:true,
		navigation : false,
		pagination: false
	});
	$('.carousel-2-items').find(".nav_next").on( "click", function() {
		$(this).parent(".carousel-2-items").find(".carousel-items").trigger('owl.next');
	});
	$('.carousel-2-items').find(".nav_prev").on( "click", function() {
		$(this).parent(".carousel-2-items").find(".carousel-items").trigger('owl.prev');
	});
	
	//Owl Carousel 5 items
	$('.carousel-5-items .carousel-items').owlCarousel({
		items: 5,
		pagination: false,
		slideSpeed : 500,
		paginationSpeed:800,
		rewindSpeed:1000,
		loop:true,
		navigation : false,
		pagination: false
	});  
	$(".carousel-5-items .nav_next").on( "click", function() {
		jQuery(this).parent(".carousel-5-items").find(".carousel-items").trigger('owl.next');
	});
	$(".carousel-5-items .nav_prev").on( "click", function() {
		jQuery(this).parent(".carousel-5-items").find(".carousel-items").trigger('owl.prev');
	});
	
	//Owl Carousel 3 items
	$('.carousel-3-items .carousel-items').owlCarousel({
		items : '3',
		itemsCustom : false,
		itemsDesktop : [1320, '3'],
		itemsDesktopSmall : [1200, 3],
		itemsTablet : false,
		itemsTabletSmall : [800, 2],
		itemsMobile : [480, 1],
		slideSpeed:1000,
		paginationSpeed:800,
		rewindSpeed:1000,
		autoHeight: false,
		addClassActive: true,
		autoPlay: false,
		loop:true,
		pagination: false
	});  
	$(".carousel-3-items .nav_next").on( "click", function() {
		jQuery(this).parent(".carousel-3-items").find(".carousel-items").trigger('owl.next');
	});
	$(".carousel-3-items .nav_prev").on( "click", function() {
		jQuery(this).parent(".carousel-3-items").find(".carousel-items").trigger('owl.prev');
	});
	
	//Owl Carousel 4 items
	$('.carousel-4-items .carousel-items').owlCarousel({
		items : '4',
		itemsCustom : false,
		itemsDesktop : [1320, '4'],
		itemsDesktopSmall : [1200, 3],
		itemsTablet : false,
		itemsTabletSmall : [800, 2],
		itemsMobile : [480, 1],
		slideSpeed:1000,
		paginationSpeed:800,
		rewindSpeed:1000,
		autoHeight: false,
		addClassActive: true,
		autoPlay: false,
		loop:true,
		pagination: false
	});  
	$(".carousel-4-items .nav_next").on( "click", function() {
		jQuery(this).parent(".carousel-4-items").find(".carousel-items").trigger('owl.next');
	});
	$(".carousel-4-items .nav_prev").on( "click", function() {
		jQuery(this).parent(".carousel-4-items").find(".carousel-items").trigger('owl.prev');
	});
	
	//Owl Carousel 1 items
	$('.carousel-1-items .carousel-items').owlCarousel({
		items : 1,
		itemsCustom : false,
		itemsDesktop : [1320, 1],
		itemsDesktopSmall : [1200, 1],
		itemsTablet : [991, 1],
		itemsTabletSmall : false,
		itemsMobile : [500, 1],
		slideSpeed:500,
		paginationSpeed:800,
		rewindSpeed:1000,
		autoHeight: false,
		addClassActive: true,
		autoPlay: false,
		loop:true,
		navigation : false,
		pagination: false
	});  
	$(".carousel-1-items .nav_next").on( "click", function() {
		jQuery(this).parent(".carousel-1-items").find(".carousel-items").trigger('owl.next');
	});
	$(".carousel-1-items .nav_prev").on( "click", function() {
		jQuery(this).parent(".carousel-1-items").find(".carousel-items").trigger('owl.prev');
	});
	
	//Blog Slider
	$(".blog-slider .sliders").imagesLoaded().owlCarousel({
		slideSpeed : 300,
		paginationSpeed : 400,
		singleItem:true,
		autoPlay: true,
		loop:true,
		pagination: false
	   // navigation:true
	});
	// Custom Navigation Events
	$(".blog-slider").find(".slider-control.next-btn").on( "click", function() {
		$(".blog-slider .sliders").trigger('owl.next');
	 })
	$(".blog-slider").find(".slider-control.prev-btn").on( "click", function() {
		$(".blog-slider .sliders").trigger('owl.prev');
	})
	
	//Installgram Hover Effect
	$(".carousel-5-items .instagram-gallery").on("hover", function(e) {
		if (e.type == "mouseenter") {
			$('.carousel-5-items .instagram-gallery a').addClass('graysc');
		}
		else {
			$('.carousel-5-items .instagram-gallery a').removeClass('graysc');
		}
	});
	
	$(".content-featured").fitVids();
	
	if($(".section-parallax").length > 0) {
		$('.section-parallax').parallax("50%", 0);
	}
	
	//Ajax popup
	if($(".ajax-popup-link").length > 0) {
		$('.ajax-popup-link').magnificPopup({
			type: 'ajax'
		});
	}
	
	//Toggle Accordion
	var iconOpen = 'fa fa-minus',
		iconClose = 'fa fa-plus';

	$(document).on('show.bs.collapse hide.bs.collapse', '.accordion', function (e) {
		var $target = $(e.target)
		  $target.siblings('.accordion-heading')
		  .find('.toggle-icon').toggleClass(iconOpen + ' ' + iconClose);
		  if(e.type == 'show')
			  $target.prev('.accordion-heading').find('.accordion-toggle').addClass('active');
		  if(e.type == 'hide')
			  $(this).find('.accordion-toggle').not($target).removeClass('active');
	});
	
	//Revolution slider
	if($("#rev_slider_1").length > 0) {
		revolutionSlider_1();
	}
	if($("#rev_slider_2").length > 0) {
		revolutionSlider_2();
	}
	if($("#rev_slider_4").length > 0) {
		revolutionSlider_4();
	}
	if($("#rev_slider_5").length > 0) {
		revolutionSlider_5();
	}
});

function revolutionSlider_1() {
	$("#rev_slider_1").show().revolution({
		sliderType:"standard",
		sliderLayout:"fullwidth",
		dottedOverlay:"none",
		delay:9000,
		navigation: {
			keyboardNavigation:"off",
			keyboard_direction: "horizontal",
			mouseScrollNavigation:"off",
			onHoverStop:"off",
			touch:{
				touchenabled:"on",
				swipe_threshold: 75,
				swipe_min_touches: 50,
				swipe_direction: "horizontal",
				drag_block_vertical: false
			}
			,
			arrows: {
				style:"hades",
				enable:true,
				hide_onmobile:false,
				hide_onleave:true,
				hide_delay:200,
				hide_delay_mobile:1200,
				tmp:'<div class="tp-arr-allwrapper">	<div class="tp-arr-imgholder"></div></div>',
				left: {
					h_align:"left",
					v_align:"center",
					h_offset:40,
					v_offset:0
				},
				right: {
					h_align:"right",
					v_align:"center",
					h_offset:40,
					v_offset:0
				}
			}
		},
		responsiveLevels:[1240,1024,778,480],
		gridwidth:[1400,1240,778,480],
		gridheight:[900,768,900,720],
		lazyType:"single",
		parallax: {
			type:"mouse",
			origo:"slidercenter",
			speed:1000,
			levels:[2,3,4,5,6,7,12,16,10,50],
			disable_onmobile:"on"
		},
		shadow:0,
		spinner:"spinner2",
		stopLoop:"off",
		stopAfterLoops:-1,
		stopAtSlide:-1,
		shuffle:"off",
		autoHeight:"off",
		disableProgressBar:"on",
		hideThumbsOnMobile:"on",
		hideSliderAtLimit:0,
		hideCaptionAtLimit:0,
		hideAllCaptionAtLilmit:0,
		debugMode:false,
		fallbacks: {
			simplifyAll:"off",
			nextSlideOnWindowFocus:"off",
			disableFocusListener:false,
		}
	});
}

function revolutionSlider_2() {
	$("#rev_slider_2").show().revolution({
		sliderType:"standard",
		sliderLayout:"fullwidth",
		dottedOverlay:"none",
		delay:9000,
		navigation: {
			keyboardNavigation:"off",
			keyboard_direction: "horizontal",
			mouseScrollNavigation:"off",
			onHoverStop:"off",
			touch:{
				touchenabled:"on",
				swipe_threshold: 75,
				swipe_min_touches: 50,
				swipe_direction: "horizontal",
				drag_block_vertical: false
			}
			,
			arrows: {
				style:"metis",
				enable:true,
				hide_onmobile:true,
				hide_under:600,
				hide_onleave:true,
				hide_delay:200,
				hide_delay_mobile:1200,
				tmp:'',
				left: {
					h_align:"left",
					v_align:"center",
					h_offset:30,
					v_offset:0
				},
				right: {
					h_align:"right",
					v_align:"center",
					h_offset:30,
					v_offset:0
				}
			}
		},
		responsiveLevels:[1240,1024,778,480],
		gridwidth:[1240,1024,778,480],
		gridheight:[700,668,800,620],
		lazyType:"smart",
		parallax: {
			type:"mouse",
			origo:"slidercenter",
			speed:2000,
			levels:[2,3,4,5,6,7,12,16,10,50],
		},
		shadow:0,
		spinner:"off",
		stopLoop:"off",
		stopAfterLoops:-1,
		stopAtSlide:-1,
		shuffle:"off",
		autoHeight:"off",
		hideThumbsOnMobile:"off",
		hideSliderAtLimit:0,
		hideCaptionAtLimit:0,
		hideAllCaptionAtLilmit:0,
		debugMode:false,
		fallbacks: {
			simplifyAll:"off",
			nextSlideOnWindowFocus:"off",
			disableFocusListener:false,
		}
	});
}

function revolutionSlider_4() {
	$("#rev_slider_4").show().revolution({
		sliderType:"standard",
		sliderLayout:"auto",
		dottedOverlay:"none",
		delay:9000,
		navigation: {
			keyboardNavigation:"off",
			keyboard_direction: "horizontal",
			mouseScrollNavigation:"off",
			onHoverStop:"on",
			touch:{
				touchenabled:"on",
				swipe_threshold: 75,
				swipe_min_touches: 50,
				swipe_direction: "horizontal",
				drag_block_vertical: false
			}
			,
			arrows: {
				style:"gyges",
				enable:true,
				hide_onmobile:true,
				hide_under:600,
				hide_onleave:true,
				hide_delay:200,
				hide_delay_mobile:1200,
				tmp:'',
				left: {
					h_align:"left",
					v_align:"center",
					h_offset:30,
					v_offset:0
				},
				right: {
					h_align:"right",
					v_align:"center",
					h_offset:30,
					v_offset:0
				}
			}
		},
		responsiveLevels:[1240,1024,778,480],
		gridwidth:[1240,1024,778,480],
		gridheight:[600,768,960,720],
		lazyType:"smart",
		parallax: {
			type:"mouse",
			origo:"slidercenter",
			speed:2000,
			levels:[2,3,4,5,6,7,12,16,10,50],
		},
		shadow:0,
		spinner:"spinner2",
		stopLoop:"off",
		stopAfterLoops:-1,
		stopAtSlide:-1,
		shuffle:"off",
		autoHeight:"off",
		hideThumbsOnMobile:"off",
		hideSliderAtLimit:0,
		hideCaptionAtLimit:0,
		hideAllCaptionAtLilmit:0,
		debugMode:false,
		fallbacks: {
			simplifyAll:"off",
			nextSlideOnWindowFocus:"off",
			disableFocusListener:false,
		}
	});
}

function revolutionSlider_5() {
	$("#rev_slider_5").show().revolution({
		sliderType:"standard",
		sliderLayout:"auto",
		dottedOverlay:"none",
		delay:9000,
		navigation: {
			keyboardNavigation:"off",
			keyboard_direction: "horizontal",
			mouseScrollNavigation:"off",
			onHoverStop:"on",
			touch:{
				touchenabled:"on",
				swipe_threshold: 75,
				swipe_min_touches: 50,
				swipe_direction: "horizontal",
				drag_block_vertical: false
			}
			,
			arrows: {
				style:"zeus",
				enable:true,
				hide_onmobile:true,
				hide_under:600,
				hide_onleave:true,
				hide_delay:200,
				hide_delay_mobile:1200,
				tmp:'<div class="tp-title-wrap">  	<div class="tp-arr-imgholder"></div> </div>',
				left: {
					h_align:"left",
					v_align:"center",
					h_offset:30,
					v_offset:0
				},
				right: {
					h_align:"right",
					v_align:"center",
					h_offset:30,
					v_offset:0
				}
			}
		},
		responsiveLevels:[1240,1024,778,480],
		gridwidth:[1240,1024,778,480],
		gridheight:[600,668,860,620],
		lazyType:"none",
		parallax: {
			type:"mouse",
			origo:"slidercenter",
			speed:2000,
			levels:[2,3,4,5,6,7,12,16,10,50],
		},
		shadow:0,
		spinner:"off",
		stopLoop:"off",
		stopAfterLoops:-1,
		stopAtSlide:-1,
		shuffle:"off",
		autoHeight:"off",
		hideThumbsOnMobile:"off",
		hideSliderAtLimit:0,
		hideCaptionAtLimit:0,
		hideAllCaptionAtLilmit:0,
		debugMode:false,
		fallbacks: {
			simplifyAll:"off",
			nextSlideOnWindowFocus:"off",
			disableFocusListener:false,
		}
	});
}
