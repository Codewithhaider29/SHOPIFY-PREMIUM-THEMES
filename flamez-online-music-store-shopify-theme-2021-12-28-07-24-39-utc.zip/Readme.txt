Within the Main folder[themeforest-flamez-shopify-theme.zip] there will be following folder and files.


Documentation
flamez.zip
Readme.txt
Log.txt
 
You need to install the flamez.zip file.


Online documentation link: http://themessupport.com/documentation/doc/buddhathemes/flamez/ 


Kindly refer our documentation for installing the theme and doing customization. 
If you need any assistance, plz contact us through support@wedesignthemes.com


Thankyou,
Buddhathemes.



