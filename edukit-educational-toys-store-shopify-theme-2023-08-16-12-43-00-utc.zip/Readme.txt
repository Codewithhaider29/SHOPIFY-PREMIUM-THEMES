Please unpack the whole package after downloading it from Themeforest.
On that extracted themeforest-edukit-shopify-theme, You can find files like
Documentation,
edukit.zip ,
Log.txt and Readme.txt.

You need to install the file "edukit.zip".


Online documentation link :  
https://themessupport.com/buddha-shop/edukit/