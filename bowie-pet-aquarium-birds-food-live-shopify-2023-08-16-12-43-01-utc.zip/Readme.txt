Within the main folder [themeforest-bowie-shopify-theme.zip] there will be following folder and files.


Documentation
Readme.txt
Log.txt
bowie.zip            


------------------------------------------------------------------------------------------------------------------------------------
https://themessupport.com/buddha-shop/bowie/

Kindly refer our documentation for installing the theme and doing customization. 
If you need any assistance, plz contact us through support@wedesignthemes.com


Thank You.
DesignThemes.










