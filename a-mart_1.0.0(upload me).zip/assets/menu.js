document.addEventListener('DOMContentLoaded', function () {
    window.addEventListener('headerInitialized', function () {
        setTimeout(function () {
            shopifyMenuCollapse()
            addEllipsisMenuVisibilityListeners()
            addAccountMenuVisibilityListeners()
            replaceSubmenu()
        }, 100)
    })
    window.addEventListener('resize', function () {
        shopifyMenuCollapse();
        replaceSubmenu();
    });

    function shopifyMenuCollapse() {
        const ul = document.querySelector('.sc_layouts_menu > ul')

        if (! menuHasMoreThanOneItem(ul)) {
            return
        }

        const maxFreeSpace = calculateMaxFreeSpace(ul);
        let totalWidth = 0;

        // Check if need to move items
        let collapse = false;
        ul.querySelectorAll(':scope > li').forEach(function (menuItem, index) {
            menuItem.setAttribute('data-index', index.toString())

            if (collapse) {
                return
            }

            totalWidth += menuItem.offsetWidth
            collapse = totalWidth > maxFreeSpace
        });

        const ellipsis = getEllipsis(ul)
        const ellipsisUl = ellipsis.querySelector(':scope > ul')

        if (collapse) {
            totalWidth = ellipsis.offsetWidth
            ul.querySelectorAll(':scope > li:not(.menu-collapse)').forEach(function (menuItem, index) {
                if (totalWidth <= maxFreeSpace) {
                    totalWidth += menuItem.offsetWidth;
                }

                if (totalWidth > maxFreeSpace) {
                    let moved = false;
                    ellipsisUl.querySelectorAll(':scope > li').forEach(function (ellipsisItem) {
                        if (! moved && parseInt(ellipsisItem.getAttribute('data-index')) > index) {
                            menuItem.setAttribute('data-width', menuItem.offsetWidth)
                            ellipsisUl.insertBefore(menuItem, ellipsisItem)
                            moved = true;
                        }
                    });

                    if (! moved) {
                        menuItem.setAttribute('data-width', menuItem.offsetWidth)
                        ellipsisUl.appendChild(menuItem)
                    }
                }
            });
            ellipsis.style.removeProperty('display')

            return
        }

        // Else - move items to the menu again
        const items = ellipsisUl.querySelectorAll(':scope > li')
        let cnt = 0
        collapse = true

        items.forEach(function (ellipsisItem) {
            if (! collapse) {
                return
            }

            if (items.length - cnt === 1) {
                totalWidth -= ellipsis.offsetWidth
            }

            totalWidth += parseFloat(ellipsisItem.getAttribute('data-width'))

            if (totalWidth >= maxFreeSpace) {
                collapse = false

                return
            }

            ellipsis.parentNode.insertBefore(ellipsisItem, ellipsis)
            cnt++
        })

        if (items.length - cnt === 0) {
            ellipsis.style.setProperty('display', 'none');
        }
    }

    function calculateMaxFreeSpace(ul) {
        const container = ul.closest('.header_item').parentNode
        const additionalSpacingInPixels = 50;

        return container.offsetWidth - Array.prototype.slice.call(container.querySelectorAll(':scope > div')).reduce(
            function (carry, sibling) {
                if (sibling.querySelector('#' + ul.id) !== null) {
                    return carry
                }

                return carry + sibling.offsetWidth
            },
            additionalSpacingInPixels
        )
    }

    function getEllipsis(menu) {
        const ellipsis = menu.querySelector('li.menu-item.menu-collapse')

        if (ellipsis !== null) {
            return ellipsis
        }

        const li = document.createElement('LI')
        li.className = 'menu-item menu-collapse site-nav--has-dropdown'
        menu.appendChild(li)

        const a = document.createElement('A')
        a.href = '#'
        a.className = 'sf-with-ul'
        li.appendChild(a)

        const ul = document.createElement('UL')
        ul.className = 'site-nav__dropdown'
        li.appendChild(ul)

        return li;
    }

    function replaceSubmenu() {
        if (! document.querySelector('.sc_layouts_menu')) {
            return
        }

        document.querySelectorAll('.site-nav--has-dropdown').forEach(function (menuChild) {
            menuChild.addEventListener('click', function () {
                setTimeout(function () {
                    const leftParentDistance = menuChild.getBoundingClientRect().left;
                    const initEachSubmenu = menuChild.querySelector('.site-nav__dropdown');
                    const widthEachSubmenu = initEachSubmenu.offsetWidth + 10;
                    const calcFreePlace = (screen.width - leftParentDistance);

                    if (widthEachSubmenu > calcFreePlace) {
                        initEachSubmenu.classList.add('submenu_left');
                    }
                }, 100)
            });
        });
    }

    function menuHasMoreThanOneItem(menu) {
        return menu !== null && menu.querySelectorAll(':scope > li').length > 1
    }

    function addEllipsisMenuVisibilityListeners() {
        const openMenuClassName = 'open';
        const ellipsis = document.querySelector('.sf-with-ul');
        const menu = document.querySelector('.site-nav .menu-item.menu-collapse .site-nav__dropdown');

        ellipsis.addEventListener('click', function (event) {
            event.stopPropagation()
            menu.classList.toggle(openMenuClassName)
        });

        document.querySelector('body').addEventListener('click', function (event) {
            if (event.target === menu || menu.contains(event.target)) {
                return
            }

            menu.classList.remove(openMenuClassName)
        })
    }

    function addAccountMenuVisibilityListeners() {
        var elemCheck = document.getElementsByClassName('site-header__account');
        if ( elemCheck.length != 0 ) {
            const openMenuClassName = 'open';
            const ellipsis = document.querySelector('.site-header .site-header__icons-wrapper .site-header__account');
            const menu = document.querySelector('.site-header .site-header__icons-wrapper .site-header__account .account-list');
    
            ellipsis.addEventListener('click', function (event) {
                event.stopPropagation()
                menu.classList.toggle(openMenuClassName)
            });
            ellipsis.addEventListener('keypress', function (event) {
                event.stopPropagation()
                menu.classList.toggle(openMenuClassName)
            });
    
            document.querySelector('body').addEventListener('click', function (event) {
                if (event.target === menu) {
                    return
                }
    
                menu.classList.remove(openMenuClassName)
            })
        }
    }
});
