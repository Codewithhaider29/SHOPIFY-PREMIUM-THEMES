// jQuery(document).ready(function($) {
//     "use strict";
//   /* Do Update Mini Cart */
//   function doUpdateMiniCart(cart) {
    

//     if (cart.item_count > 0) {
//       for (var i = 0; i < cart.items.length; i++) {
//         var item = template;
//         item = item.replace(/\{id\}/g, cart.items[i].id);
//         item = item.replace(/\{url\}/g, cart.items[i].url);
//         item = item.replace(/\{title\}/g, cart.items[i].title);
//         item = item.replace(/\{quantity\}/g, cart.items[i].quantity);
//         item = item.replace(/\{img\}/g, Shopify.resizeImage(cart.items[i].image, 'small'));
//         item = item.replace(/\{price\}/g, Shopify.formatMoney(cart.items[i].price, window.money_format));
//         $('.mini-cart .mini-products-list').append(item);
//       }
//       $('.mini-cart .btn-remove').click(function(event) {          
//         event.preventDefault();
//         var productId = $(this).parents('.item').attr('id');
//         productId = productId.match(/\d+/g);
//         console.log(productId);
//         Shopify.removeItem(productId, function(cart) {
//           doUpdateMiniCart(cart);
//         });          
//       });

//     } 
//     checkItemsInMiniCart();
// //      currency();
//   }window.doUpdateMiniCart=doUpdateMiniCart;
  
//   /* Check Item Mini Cart */
//   function checkItemsInMiniCart() {  

//     if($('.mini-cart .mini-products-list').children().length > 0) {

//       $('.mini-cart').addClass('hasItem');          
//     } else{
//       $('.mini-cart').removeClass('hasItem'); 
//     }
//   }window.checkItemsInMiniCart=checkItemsInMiniCart;
  
//   /* Mini Cart Click to Show */
    

//       $('.mini-cart .btn-remove').click(function(event) {       
//         event.preventDefault();
//         var productId = $(this).parents('.item').attr('id');
//         productId = productId.match(/\d+/g);
//         console.log(productId);
//         Shopify.removeItem(productId, function(cart) {
//           doUpdateMiniCart(cart);       
//         });
//       });
    
// });