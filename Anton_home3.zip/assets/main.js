jQuery(document).ready(function($) {
    "use strict";

    // menu
    $(".level1_h1 .level11 a").on("click", function() {
        $(this).parent().parent().find("level11").removeClass("active").addClass("active");

    });
    $(".level1_h1 .level11 a").on("hover", function() {
        $(this).parent().parent().find("level11").addClass("active");

    });

    $("#open-filters").on("click", function() {
        $(this).toggleClass("hamburger-icon");
    })
    // home2
    var fixSpaceTabSlick = function(display) {
        var tabList = $('.js-tab-product');
        $.each(tabList, function() {
            var check = $(this).attr('id');
            if (check == display) {
                $(this).show();
                $(this).slick('setPosition');
            } else {
                $(this).hide();
            }
        });
    }
    // End/menu

    // categories

    $('a[data-toggle="tab"]').on('show.bs.tab', function(e) {
        fixSpaceTabSlick($(this).attr('aria-controls'));
    });

    $('.js-tab-product').slick({
        infinite: true,
        slidesToShow: 5,
        arrows: true,
        slidesToScroll: 1,
        dots: false,
        responsive: [{
                breakpoint: 991,
                settings: {
                    slidesToShow: 3,

                }
            },
            {
                breakpoint: 769,
                settings: {
                    slidesToShow: 2,

                }
            },
            {
                breakpoint: 450,
                settings: {
                    slidesToShow: 1,

                }
            },

        ]
    });

    fixSpaceTabSlick($('.product-tab-slide .nav-tabs li[class*="active"] > a').attr('aria-controls'));
    $('.js-categories-prd-dtails1').slick({
        infinite: true,
        slidesToShow: 4,
        arrows: true,
        slidesToScroll: 1,
        dots: false,
        responsive: [{
                breakpoint: 991,
                settings: {
                    slidesToShow: 3,

                }
            },
            {
                breakpoint: 769,
                settings: {
                    slidesToShow: 2,

                }
            },
            {
                breakpoint: 450,
                settings: {
                    slidesToShow: 1,

                }
            },

        ]
    });

    // end/categories

    // product
    var $productSlick = $('.js-mobi-product');
    var detectViewPort = function() {
        var viewPortWidth = $(window).width();
        if (viewPortWidth < 769) {
            if (!$productSlick.hasClass('slick-initialized')) {
                $('.js-mobi-product').slick({
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    dots: false,
                    arrows: true,
                    responsive: [{
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                        }
                    }]
                });
            }
        } else {
            if ($productSlick.hasClass('slick-initialized')) {
                $('.js-mobi-product').slick('destroy');
            }
        }
    };

    detectViewPort();
    $(window).resize(function() {
        detectViewPort();
    });

    setTimeout(function() {
        $('body').addClass('loaded');
    }, 2000);
    // end/product
    // search
//     $(".close-search-form").on("click", function() {
//         $('.menubar-search-form').removeClass('js-open-search');
//     });
    // end/search

    // user
    $(".click-hover-user").on("click", function() {
        $(".submenu_user").css("opacity", "1");
        $(".submenu_user").css("visibilyti", "inherit");
    });
    // end / user


    $(".dropdown").on("hover", function() {
            $('.dropdown-menu', this).stop(true, true).slideDown("fast");
            $(this).toggleClass('open');
        },
        function() {
            $('.dropdown-menu', this).stop(true, true).slideUp("fast");
            $(this).toggleClass('open');
        }
    );

    $('select.selectpicker').selectpicker({
        caretIcon: 'glyphicon glyphicon-menu-down',
    });



    // slide price
    if ($("#price").length) {
        var slider = new Slider('#price', {});
    }
    $(".noo-menu").on("click", function() {
        var slide = $(this).find('.sub-menu').slideToggle(600);
    })


    // slick


    $('.js-team').slick({
        infinite: true,
        slidesToShow: 5,
        arrows: true,
        slidesToScroll: 1,
        dots: false,
        responsive: [{
                breakpoint: 991,
                settings: {
                    slidesToShow: 4,
                    dots: true,
                    arrows: false,
                }
            },
            {
                breakpoint: 769,
                settings: {
                    slidesToShow: 2,
                    dots: true,
                    arrows: false,
                }
            },
            {
                breakpoint: 450,
                settings: {
                    slidesToShow: 1,
                    dots: true,
                    arrows: false,

                }
            },

        ]
    });
    $('.slider-for-dt2').slick({

        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        dots: false,
        fade: true,
        infinite: false,
        asNavFor: '.slider-nav-dt2',
        responsive: [{
            breakpoint: 991,
            settings: {
                dots: true
            }
        }]
    });

    $('.slider-nav-dt2').slick({
        slidesToShow: 2,
        slidesToScroll: 1,
        asNavFor: '.slider-for-dt2',
        arrows: true,
        dots: false,
        infinite: false,
        vertical: true,
        verticalSwiping: true,
        focusOnSelect: true,
        responsive: [{
                breakpoint: 991,
                settings: {
                    slidesToShow: 2,
                    vertical: false,
                    verticalSwiping: false,
                    focusOnSelect: false,
                }
            },

        ]
    });
    $('.js-slideshow').slick({
        infinite: true,
        slidesToShow: 1,
        arrows: true,
        slidesToScroll: 1,
        dots: false

    });
    $('.home-2').slick({
        infinite: true,
        slidesToShow: 5,
        arrows: true,
        slidesToScroll: 1,
        dots: false,
        responsive: [{
                breakpoint: 991,
                settings: {
                    slidesToShow: 3,

                }
            },
            {
                breakpoint: 769,
                settings: {
                    slidesToShow: 2,

                }
            },
            {
                breakpoint: 450,
                settings: {
                    slidesToShow: 1,

                }
            },

        ]
    });
    $('.js-slide-brand').slick({
        infinite: true,
        slidesToShow: 6,
        arrows: false,
        slidesToScroll: 1,
        dots: false,
        responsive: [{
                breakpoint: 991,
                settings: {
                    slidesToShow: 4,

                }
            },
            {
                breakpoint: 769,
                settings: {
                    slidesToShow: 3,

                }
            },
            {
                breakpoint: 450,
                settings: {
                    slidesToShow: 2,

                }
            },

        ]
    });
    $('.slider-for').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        fade: true,
        asNavFor: '.slider-nav'
    });
    $('.slider-nav').slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        asNavFor: '.slider-for',
        arrows: true,
        leftMode: true,
        focusOnSelect: true,
        responsive: [{
            breakpoint: 480,
            settings: {
                slidesToShow: 2,
            }
        }]
    });
    // End/slick
    // number
    var quantitiy = 0;

    $('.js-minus').on("click", function(e) {
        e.preventDefault();
        var quantity = parseInt($('.js-number').val(), 10);
        $('.js-number').val(quantity + 1);
    });

    $('.js-plus').on("click", function(e) {
        e.preventDefault();
        var quantity = parseInt($('.js-number').val(), 10);
        if (quantity > 0) {
            $('.js-number').val(quantity - 1);
        }
    });
    // end/number

    // ordering
    $(".ordering .list").on("click", function() {
        $(this).toggleClass("active");
        $(".item").addClass("list-item");
        $(".ordering .col").removeClass("active");
        $(".col-remove").removeClass("col-md-4");
        $(".col-remove").removeClass("col-md-3");
        $(".act-img").toggleClass("act-img-click");
        $(".img-ic").toggleClass("img-ic-click");

    });
    $(".ordering .col").on("click", function() {
        $(this).toggleClass("active");
        $(".item").removeClass("list-item");
        $(this).removeClass("active");
        $(".act-img").toggleClass("act-img-click");
        $(".img-ic").toggleClass("img-ic-click");

        // end/ordering
    });
    /*MAP*/
    function init() {
        var mapOptions = {
            zoom: 14,
          center: new google.maps.LatLng(33.3209127, -111.8005377),
            styles: [{
                "featureType": "administrative.province",
                "elementType": "all",
                "stylers": [{
                    "visibility": "off"
                }]
            }, {
                "featureType": "landscape",
                "elementType": "all",
                "stylers": [{
                    "saturation": -100
                }, {
                    "lightness": 65
                }, {
                    "visibility": "on"
                }]
            }, {
                "featureType": "poi",
                "elementType": "all",
                "stylers": [{
                    "saturation": -100
                }, {
                    "lightness": 51
                }, {
                    "visibility": "simplified"
                }]
            }, {
                "featureType": "road.highway",
                "elementType": "all",
                "stylers": [{
                    "saturation": -100
                }, {
                    "visibility": "simplified"
                }]
            }, {
                "featureType": "road.arterial",
                "elementType": "all",
                "stylers": [{
                    "saturation": -100
                }, {
                    "lightness": 30
                }, {
                    "visibility": "on"
                }]
            }, {
                "featureType": "road.local",
                "elementType": "all",
                "stylers": [{
                    "saturation": -100
                }, {
                    "lightness": 40
                }, {
                    "visibility": "on"
                }]
            }, {
                "featureType": "transit",
                "elementType": "all",
                "stylers": [{
                    "saturation": -100
                }, {
                    "visibility": "simplified"
                }]
            }, {
                "featureType": "transit",
                "elementType": "geometry.fill",
                "stylers": [{
                    "visibility": "on"
                }]
            }, {
                "featureType": "water",
                "elementType": "geometry",
                "stylers": [{
                    "hue": "#ffff00"
                }, {
                    "lightness": -25
                }, {
                    "saturation": -97
                }]
            }, {
                "featureType": "water",
                "elementType": "labels",
                "stylers": [{
                    "visibility": "on"
                }, {
                    "lightness": -25
                }, {
                    "saturation": -100
                }]
            }]
        };
        var mapElement = document.getElementById('map');
        var map = new google.maps.Map(mapElement, mapOptions);
        var marker = new google.maps.Marker({
            position: new google.maps.LatLng(33.3209127, -111.8005377),
            map: map,
            title: 'Snazzy!'
        });
    }
    if ($('#map').length > 0) {
        google.maps.event.addDomListener(window, 'load', init);

    }
    /*END/MAP*/


    // Slider
    $(function() {
        initSlide();
        $('.slider__show').on('beforeChange', function(event, slick, currentSlide, nextSlide) {
            initInfo();
        });
    });

    function initSlide() {
        $('.slideshow-item').slick({
            slidesToShow: 1,
            autoplay: true,
            autoplaySpeed: 1000,
            arrows: false
        });


        $('.slider__show').slick({
            centerMode: true,
            slidesToShow: 3,
            centerPadding: '0px',
            autoplaySpeed: 1000,
            arrows: false,
            responsive: [{
                    breakpoint: 769,
                    settings: {
                        slidesToShow: 3,
                    }
                },
                {
                    breakpoint: 569,
                    settings: {
                        slidesToShow: 1,
                        dots: true,
                    }

                },
                {
                    breakpoint: 321,
                    settings: {
                        slidesToShow: 1,
                        dots: true,
                    }
                },
            ]
        });

        initInfo();

    }


    function initInfo() {
        var itemCurr = $('.slider__show .slick-current');
        $('.slider__meta > .name').html(itemCurr.data('name'));
        $('.slider__meta > .position').html(itemCurr.data('position'));
        $('.slider__meta > .desc').html(itemCurr.data('desc'));
    }
    // End/Slider

    // toggleClass
    $('#open-filters').on("click", function() {
        $('.left-slidebar').toggleClass('open-fil');

    });
    $('.js-click-config').on("click", function() {
        $('.sidenav').toggleClass('mySidenav');

    })
    $(".btn-navbar").on("click", function() {
        $(".off-canvas-nav").toggleClass('open-canvas-nav');
    })
    $('.js-click-cart').on("click", function() {
        $('.overlay').toggleClass('myNav');

    })
    // end/toggleClass
    // search
    $('.js-click-search').on("click", function() {
        $("span", this).toggleClass("pe-7s-search pe-7s-close");
        $('.menubar-search-form').toggleClass('engoj-search-form');

    });
    $('.js-click-search-mobi').on("click", function() {
        $("span", this).toggleClass("pe-7s-search pe-7s-close");
        $('.menubar-search-form').toggleClass('js-open-search');
    });
    // submenu_user
    $('.js-click-user').on("click", function() {
        $('.submenu_user').toggleClass('js-open-user');

    });
    // myNav

    // removeClass
    $('.closebtn').on("click", function() {
        $('.overlay').removeClass('myNav');
    })


    $('.close').on("click", function() {
        $('.sidenav').removeClass('mySidenav');

    })

    $(".remove-menumobile").on("click", function() {
        $(".off-canvas-nav").removeClass('open-canvas-nav');
    })
    // end/removeClass


});