Thank you for purchase our theme. 
For more instruction, please read the document in folder /Guides

-------------------------
Thank again,
Engo Theme - Engo Team