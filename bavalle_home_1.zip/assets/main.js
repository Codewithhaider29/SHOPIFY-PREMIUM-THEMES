jQuery(document).ready(function($) {
    "use strict";
  
  	
  
  	$('.scrollbar-macosx').scrollbar();
  	$('.scrollbar-inner').scrollbar();
  
  $(function() {
        $('.lazy').Lazy();
    });
  $('.element-currency .dropdown-menu a').click(function(){
    $('.element-currency .dropdown-toggle > span:first-child').text($(this).text());
  });
  
//  Footer collapse 
 $('.footer-v1 button, .footer-v3 button, .footer-v4 button').click( function(e) {
    $('.collapse').collapse('hide');
});
  
	//  	FAQS 	
  	 // ------accordion--------
 	var acc = document.getElementsByClassName("accordion");
 
    var i;

    for (i = 0; i < acc.length; i++) {
      acc[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var panel = this.nextElementSibling;
        if (panel.style.maxHeight){
          panel.style.maxHeight = null;
        } else {
          panel.style.maxHeight = panel.scrollHeight + "px";
        } 
      });
    }
    // Ajax search
    $('.ajax-search input[type="text"]').on('blur', function() {
        $('.list-product-search').removeClass('active');
    });
    $('.ajax-search input[type="text"]').on('keydown', function() {
        if ($(this).val() == "") {
            $('.list-product-search').removeClass('active');
        } else {
            $('.list-product-search').addClass('active');
        }
    });
    // close quickview

    $(".quickview-close").on("click", function() {
        $('.quickview-wrapper').hide();
        $('.quickview-wrapper').removeClass('open');
        $('.quick-modal').removeClass('show');
    });
    // open Vertical menu 
    $(".js-vertical-menu").on("click", function() {
        $('.vertical-wrapper').slideToggle(200);
        $(this).toggleClass('active');
    });
     /* Nomos Carousel  */
     nomos_init_carousel();
    function nomos_init_carousel() {
        
        $('.js-owl-customize').each(function (index, el) {
            var config = $(this).data();
            if ($(this).is('.category-filter-mobile')) {
                config['autoWidth'] = true;
            }
            config.navText = ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'];
            var animateOut = $(this).data('animateout');
            var animateIn = $(this).data('animatein');
            var slidespeed = $(this).data('slidespeed');
            
            if (typeof animateOut != 'undefined') {
                config.animateOut = animateOut;
            }
            if (typeof animateIn != 'undefined') {
                config.animateIn = animateIn;
            }
            if (typeof (slidespeed) != 'undefined') {
                config.smartSpeed = slidespeed;
            }
            
            var owl = $(this);
            owl.on('initialized.owl.carousel', function (event) {
                var total_active = owl.find('.owl-item.active').length;
                var i = 0;
                owl.find('.owl-item').removeClass('item-first item-last');
                setTimeout(function () {
                    owl.find('.owl-item.active').each(function () {
                        i++;
                        if (i == 1) {
                            $(this).addClass('item-first');
                        }
                        if (i == total_active) {
                            $(this).addClass('item-last');
                        }
                    });
                    
                }, 100);
            })
            owl.on('refreshed.owl.carousel', function (event) {
                var total_active = owl.find('.owl-item.active').length;
                var i = 0;
                owl.find('.owl-item').removeClass('item-first item-last');
                setTimeout(function () {
                    owl.find('.owl-item.active').each(function () {
                        i++;
                        if (i == 1) {
                            $(this).addClass('item-first');
                        }
                        if (i == total_active) {
                            $(this).addClass('item-last');
                        }
                    });
                    
                }, 100);
            })
            owl.on('change.owl.carousel', function (event) {
                var total_active = owl.find('.owl-item.active').length;
                var i = 0;
                owl.find('.owl-item').removeClass('item-first item-last');
                setTimeout(function () {
                    owl.find('.owl-item.active').each(function () {
                        i++;
                        if (i == 1) {
                            $(this).addClass('item-first');
                        }
                        if (i == total_active) {
                            $(this).addClass('item-last');
                        }
                    });
                    
                }, 100);
                
                
            });
            owl.on('translated.owl.carousel', function (event) {
                // Fami lazy load for owl
                if ($('.owl-item .lazy').length) {
                    $('.owl-item .lazy').lazy({
                        bind: "event"
                    });
                }
            });
            owl.owlCarousel(config);
            
        });
    }
    
     // Caculator megamenu width
     nomos_resizeMegamenu();
     nomos_get_scrollbar_width();
     function nomos_resizeMegamenu() {
        var window_size = $('body').innerWidth();
        window_size += nomos_get_scrollbar_width();
        if (window_size > 1024) {
            if ($('#header .main-menu-wrapper').length > 0) {
                var container = $('#header .main-menu-wrapper');
                if (container != 'undefined') {
                    var container_width = 0;
                    container_width = container.innerWidth();
                    var container_offset = container.offset();
                    setTimeout(function() {
                        $('#header .navbar-nav .level1').each(function(index, element) {
                            $(element).children('.menu-level-1').css({ 'max-width': container_width + 'px' });
                            var sub_menu_width = $(element).children('.menu-level-1').outerWidth();
                            var item_width = $(element).outerWidth();
                            $(element).children('.menu-level-1').css({ 'left': '-' + (sub_menu_width / 2 - item_width / 2) + 'px' });
                            var container_left = container_offset.left;
                            var container_right = (container_left + container_width);
                            var item_left = $(element).offset().left;
                            var overflow_left = (sub_menu_width / 2 > (item_left - container_left));
                            var overflow_right = ((sub_menu_width / 2 + item_left) > container_right);
                            if (overflow_left) { var left = (item_left - container_left);
                                $(element).children('.menu-level-1').css({ 'left': -left + 'px' }) }
                            if (overflow_right && !overflow_left) { var left = (item_left - container_left);
                                left = left - (container_width - sub_menu_width);
                                $(element).children('.menu-level-1').css({ 'left': -left + 'px' }) }
                        })
                    }, 100)
                }
            }

            if ($('.page-right-content .main-menu-wrapper').length > 0) {
                var container = $('.page-right-content .main-menu-wrapper');
                if (container != 'undefined') {
                    var container_width = 0;
                    container_width = container.innerWidth();
                    var container_offset = container.offset();
                    setTimeout(function() {
                        $('.sidebar-menu-middle .navbar-nav .level1').each(function(index, element) {
                            $(element).children('.menu-level-1').css({ 'max-width': container_width + 'px' });
                            var sub_menu_width = $(element).children('.menu-level-1').outerWidth();
                            var item_width = $(element).outerWidth();
                            $(element).children('.menu-level-1').css({ 'left': '-' + (sub_menu_width / 2 - item_width / 2) + 'px' });
                            var container_left = container_offset.left;
                            var container_right = (container_left + container_width);
                            var item_left = $(element).offset().left;
                            var overflow_left = (sub_menu_width / 2 > (item_left - container_left));
                            var overflow_right = ((sub_menu_width / 2 + item_left) > container_right);
                            if (overflow_left) { var left = (item_left - container_left);
                                $(element).children('.menu-level-1').css({ 'left': -left + 'px' }) }
                            if (overflow_right && !overflow_left) { var left = (item_left - container_left);
                                left = left - (container_width - sub_menu_width);
                                $(element).children('.menu-level-1').css({ 'left': -left + 'px' }) }
                        })
                    }, 100)
                }
            }
        }
    }
    function nomos_get_scrollbar_width() { 
        var $inner = $('<div style="width: 100%; height:200px;">test</div>'),
        $outer = $('<div style="width:200px; height:150px; position: absolute; top: 0; left: 0; visibility: hidden; overflow:hidden;"></div>').append($inner),
        inner = $inner[0],
        outer = $outer[0];
    $('body').append(outer); var width1 = inner.offsetWidth;
    $outer.css('overflow', 'scroll'); var width2 = outer.clientWidth;
    $outer.remove(); return (width1 - width2) }
  

// Hover product  
	
// funiter_hover_product_item_both2();
//   function funiter_hover_product_item_both2($elem) {
//     	var $elem =$('.product-carousel .product-item');
//         $elem.each(function () {
//             var _winw = $(window).innerWidth();
//             if (_winw > 1024) {
//                 $(this).on('mouseenter', function () {
//                     $(this).closest('.slick-list').css({
//                         'padding-left': '30px',
//                         'padding-right': '30px',
//                         'padding-bottom': '15px',
//                         'margin-left': '-30px',
//                         'margin-right': '-30px',
//                         'margin-bottom': '-15px'
//                     });
//                 });
//                 $(this).on('mouseleave', function () {
//                     $(this).closest('.slick-list').css({
//                         'padding-left': '0',
//                         'padding-right': '0',
//                         'padding-bottom': '0',
//                         'margin-left': '0',
//                         'margin-right': '0',
//                         'margin-bottom': '0'
//                     });
//                 });
//             }
//         });
//     }

$(".icon-sub-menu").on("click", function(e) {
    var $this = $(this);
    var thisMenu = $this.closest('.js-menubar');
    var thisMenuWrap = thisMenu.closest('.box-mobile-menu');
    thisMenu.removeClass('active');
    var text_next = $this.prev().text();
    thisMenuWrap.find('.box-title').html(text_next);
    thisMenu.find('li').removeClass('mobile-active');
    $this.parent().addClass('mobile-active').find('.menu-level1').addClass('open');
    $this.parent().closest('.menu-level1').css({ 'position': 'static', 'height': '0' });
    thisMenuWrap.find('.back-menu, .box-title').css('display', 'block');
  thisMenuWrap.find('.js-menubar').css({ 'height': '80%','border-radius': '0 0 5px 5px'});
    if ($this.parent().find('.fami-lazy:not(.already-fix-lazy)').length) { $this.parent().find('.fami-lazy:not(.already-fix-lazy)').lazy({ bind: 'event', delay: 0 }).addClass('already-fix-lazy') }
    e.preventDefault()
});

  
   $(".register-link").on("click", function() {
        $(".login-form").addClass('hidden');
    	$(".register-form").removeClass('hidden');
        $('.register-link').addClass('hidden');
    	$('.login-link').removeClass('hidden');
    	$('#RecoverPasswordForm').addClass('hidden');
    });
  $(".login-link").on("click", function() {
        $(".login-form").removeClass('hidden');
        $('.register-form').addClass('hidden');
    	$(this).addClass('hidden');
    	$('.register-link').removeClass('hidden');
    });
$('#btn-login').on('click',function(){
	$('.login_form_pc').addClass('active');
});
  $('.btn_close_login').on('click',function(){
	$('.login_form_pc').removeClass('active');
});
  $('#RecoverPassword').on('click',function(){
	$('.login-form').addClass('hidden');
    $('#RecoverPasswordForm').removeClass('hidden');
});
  $('#HideRecoverPasswordLink').on('click',function(){
	$('.login-form').removeClass('hidden');
    $('#RecoverPasswordForm').addClass('hidden');
});  
$(document).on('click', '.box-mobile-menu .back-menu', function(e) {
    var $this = $(this);
    var thisMenuWrap = $this.closest('.box-mobile-menu');
    var thisMenu = thisMenuWrap.find('.js-menubar');
    thisMenu.find('li.mobile-active').each(function() {
        thisMenu.find('li').removeClass('mobile-active');
        if ($(this).parent().hasClass('js-menubar')) { 
            thisMenu.addClass('active');
            $('.box-mobile-menu .box-title').html('MAIN MENU');
            $('.back-menu').css('display', 'none') } 
            else { 
                thisMenu.removeClass('active');
                $(this).parent().parent().addClass('mobile-active');
                $(this).parent().css({ 'position': 'absolute', 'height': 'auto' }); 
                var text_prev = $(this).parent().parent().children('a').text();
                $('.box-mobile-menu .box-title').html(text_prev) }
        e.preventDefault()
    })
});

    // Show less more 
    // Product Detail
    
    
    // Single product mobile more detail
    $(document).on('click', '.product-toggle-more-detail', function (e) {
        var thisSummary = $(this).closest('.summary');
        thisSummary.find('.product-mobile-more-detail-wrap').toggleClass('active').slideToggle();
        if (thisSummary.find('.product-mobile-more-detail-wrap').is('.active')) {
            $(this).addClass('active').text("LESS DETAILS");
            thisSummary.find('.single-product-info').css({ 'padding-top': '15px'});
        }
        else {
            $(this).removeClass('active').text("MORE DETAILS");
            thisSummary.find('.single-product-info').css({ 'padding-top': '24px'}); 
        }
        e.preventDefault();
    });  

    // Push menu home 5
    var menuLeft = $('.pushmenu-left');
    var menuHome6 = $('.menu-home5');
    var nav_list = $('.icon-cart');
    var nav_click = $('.icon-pushmenu');
    nav_list.on("click", function(event) {
        event.stopPropagation();
        $(this).toggleClass('active');
        $('body').toggleClass('pushmenu-push-toright-cart');
        menuLeft.toggleClass('pushmenu-open');
        $(".container").toggleClass("canvas-container");
    });
    nav_click.on("click", function(event) {
        event.stopPropagation();
        $(this).toggleClass('active');
        $('body').toggleClass('pushmenu-push-toleft');
        menuHome6.toggleClass('pushmenu-open');
    });
    $(".wrappage").on("click", function() {
        $(this).removeClass('active');
        $('body').removeClass('pushmenu-push-toright-cart').removeClass('pushmenu-push-toleft');
        menuLeft.removeClass('pushmenu-open');
        menuHome6.removeClass('pushmenu-open');
    });
    $(".close-menu-mobile").on("click", function() {
        $(this).removeClass('active');
        $('body').removeClass('pushmenu-push-toright-cart');
        menuLeft.removeClass('pushmenu-open');
    });
    $(".close-menu-mobile").on("click", function() {
        $('body').removeClass('pushmenu-push-toleft');
        menuHome6.removeClass('pushmenu-open');
    });
    // SHOPPING CART Quantity increment buttons

    var quantitiy = 0;
    $('.js-plus').on("click", function(e) {

        // Stop acting like a button
        e.preventDefault();
        // Get the field name
        var quantity = parseInt($('.js-number').val(), 10);

        // If is not undefined

        $('.js-number').val(quantity + 1);


        // Increment    
    });

    $('.js-minus').on("click", function(e) {
        // Stop acting like a button
        e.preventDefault();
        // Get the field name
        var quantity = parseInt($('.js-number').val(), 10);

        // If is not undefined

        // Increment
        if (quantity > 0) {
            $('.js-number').val(quantity - 1);
        }
    });

    // blog Masonry
    

    // Js product single slider
   

    // Product Detail Gallery
    $('.nomos-center-mode').not('.slick-initialized').slick({
        centerMode: true,
        centerPadding: '27.8947368%',
        slidesToShow: 1,
        arrows: false,
        dots: true,
        responsive: [
            {
                breakpoint: 767,
                settings: {
                    centerMode: false,
                }
            }
        ]
    });

   

    //SHOP LISTING FILTER
    // Price Slider
    if ($('.price-slider').length > 0) {
        $('.price-slider').slider({
            min: 100,
            max: 700,
            step: 10,
            value: [100, 400],


        });
    }
    // Shop Filter
    
   $(".js-filter-menu li .js-plus-icon").on("click", function() {
        $(this).toggleClass('minus');
        $(this).parent().find(".filter-menu").slideToggle(function() {
            $(this).next().stop(true).toggleClass('open', $(this).is(":visible"));
        });
    });
  
    if ($(".shop-filter .dropdown-menu").length > 0) { 
        $('.shop-filter .dropdown-menu').hide(); 
    }
        $(".js-filter").click(function() { 
            if ($(this).find('.filter').hasClass("active")) { 
                $('.shop-filter .dropdown-menu').slideUp() } 
                else { 
                    $('.shop-filter .dropdown-menu').slideDown(); 
                } 
                $(this).find('.filter').toggleClass("active"); 
            })
    //SHOP Grid change column
    // Shop mobile
    $(".view-mode > a").on("click", function() {
        $(this).addClass('active').siblings().removeClass('active');;
        if ($(this).hasClass('col')) {
            $(".product-grid").removeClass("product-grid-v2 product-list");
        }
        if ($(this).hasClass('list')) {
            $(".product-grid").addClass("product-list product-grid-v2");
        }
    });
    /* Products size */
    $(document).on('click', '.view-mode .products-size', function (e) {
        var $this = $(this);
        var product_size = parseInt($this.attr('data-products_num'));
        var thisParent = $this.closest('.view-mode');
        var thisContainer = $this.closest('.shop-content');
        var is_shortcode = thisParent.is('.products-sizes-shortcode');
        if (is_shortcode) {
            thisContainer = $this.closest('.prdctfltr_sc_products');
        }
        var productsList = $('.product-collection-grid');
        var product_item_classes = 'col-xs-6 col-sm-3 col-md-15 col-lg-15'; // 5 items
        
        // Remove all classes with prefix "products_list-size-"
        productsList.removeClass(function (index, class_name) {
            return (class_name.match(/\bproducts_list-size-\S+/g) || []).join(' '); // removes anything that starts with "products_list-size-"
        }).addClass('products_list-size-' + product_size);
        // Remove all classes with prefix "col-"
        productsList.find('.product-item').removeClass(function (index, class_name) {
            return (class_name.match(/\bcol-\S+/g) || []).join(' '); // removes anything that starts with "col-"
        });
        
        switch (product_size) {
            case 5:
                product_item_classes = 'col-xs-6 col-sm-3 col-md-15 col-lg-15';
                break;
            case 4:
                product_item_classes = 'col-xs-6 col-sm-3 col-md-3 col-lg-3';
                break;
            case 3:
                product_item_classes = 'col-xs-6 col-sm-3 col-md-4 col-lg-4';
                break;
        }
        
        productsList.find('.product-item').addClass(product_item_classes);
        thisParent.find('.products-size').removeClass('active');
        $this.addClass('active');
        
        
        if ($this.hasClass('products-grid')) {
            productsList.addClass('grid-size');
        } else {
            productsList.removeClass('grid-size');
        }
        
        e.preventDefault();
    });

   
    
     //Open filter menu mobile
    $('.filter-collection-left > a').on('click', function(e) {
        $('.wrappage').addClass('show-filter');
      	e.stopPropagation()
    });
    $(document).on("click", function(e) {
      if ($(e.target).is(".filter-collection-left > a") === false) {
        $('.wrappage').removeClass("show-filter");
      }
    });
    $('.close-sidebar-collection').click(function() {
        $('.wrappage').removeClass('show-filter');
    });

    // Scroll slider

    $('.nomos-minial-scroll').on('click', function() {
        $('html, body').animate({ scrollTop: $('section#main-content').offset().top }, 'slow');
        return false;
    });
    // Scroll to TOP
    $(window).scroll(function() {
        if ($(this).scrollTop() > 100) {
            $('.scroll_top').fadeIn();
        } else {
            $('.scroll_top').fadeOut();
        }
    });

    $('.scroll_top').on('click', function() {
        $("html, body").animate({
            scrollTop: 0
        }, 600);
        return false;
    });
    $(window).scroll(function() {
        var scroll = $(window).scrollTop();

        if (scroll > 500) {
            $(".intro").hide();
            $(".scroll_down").hide();
        }
    });
    // scroll down
    $(".scroll_down").on('click', function(e) {
        e.preventDefault();
        $(".intro").hide();
        $(this).hide();
        return false;
    });

  
	$('.js-owl-post').owlCarousel({
        nav: true,
        navText: ["<span class='fa fa-angle-left'></span>", "<span class='fa fa-angle-right'></span>"],
        items: 1,
        dots: false
    });  
    // Product related owl category
    $('.js-owl-cate').owlCarousel({
        margin: 0,
        autoplay: false,
        autoplayTimeout: 3000,
        loop: true,
        dots: true,
      	navText: ["<span class='ion-ios-arrow-thin-left'></span>", "<span class='ion-ios-arrow-thin-right'></span>"],
        nav: true,
        responsive: {
            0: {
                
                items: 2
            },
            480: {
                
                items: 2
            },
            768: {
                
                items: 3
            },
            1024: {
                items: 3

            },
            1200: {
                margin: 30,
                items: 3,
                nav: true,
              dots:false,
            },
            1600: {
                margin: 30,
                items: 3,
                nav: true,
              dots:false
            }
        }
    });
    $('.js-owl-test').each( function() {
        var $carousel = $(this);
          $carousel.owlCarousel({
              dots : $carousel.data("dots"),
              autoplay:$carousel.data("autoplay"),
              items : $carousel.data("items"),
              loop : $carousel.data("loop"),
                slidespeed: $carousel.data("slidespeed"),
              margin : $carousel.data("margin"),
              nav : $carousel.data("nav"),
              navText: ["<span class='fa fa-angle-left'></span>", "<span class='fa fa-angle-right'></span>"],
              responsive : $carousel.data("responsive"),
          });
    });
    
	$('.js-slick-test-dots--ct').each( function() {
              var slick = $(this),
              dots =  $(this).data('dots'),
              arrow =  $(this).data('nav'), 
              autoplay =  $(this).data('autoplay'),
              infinity =  $(this).data('infinite'),
              speed =  $(this).data('autoplaySpeed'); 
                $(this).slick({
                  dots: dots,
                  arrows: arrow,
                  autoplay:autoplay,
                  infinite: infinity,
                  autoplaySpeed : speed,
                  customPaging: function(slider, i) {
                      var thumb = $(slider.$slides[i]).data();
                      return '<a>' + (i + 1) + '</a>';
                  },
                  slidesToShow: 1,
                  slidesToScroll: 1
              });
     });
  
$('.js-click-test').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        asNavFor: '.js-test-slider',
        dots: false,
        focusOnSelect: true,
        infinite: true,
        arrows: false,
        
       
    });
    $('.js-test-slider').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,	
        asNavFor: '.js-click-test'
    });
  
  
    // owl brand
    $('.js-owl-brand').each( function() {
      	var $carousel = $(this);
          $carousel.owlCarousel({
              dots : $carousel.data("dots"),
              autoplay:$carousel.data("autoplay"),
              items : $carousel.data("items"),
              loop : $carousel.data("loop"),
                slidespeed: $carousel.data("slidespeed"),
              margin : $carousel.data("margin"),
              nav : $carousel.data("nav"),
              navText: ["<span class='fa fa-angle-left'></span>", "<span class='fa fa-angle-right'></span>"],
              responsive : $carousel.data("responsive"),
            	
          });
        
    });
    
    $(".js-owl-brand .owl-item .brand-item").click(function() {
    $('.js-owl-brand .owl-item .brand-item').removeClass("active");
      $(this).addClass("active");

    });    
         $('.js-owl-testab').owlCarousel({
        margin: 30,
        autoplay: false,
        autoplayTimeout: 3000,
        loop: true,
        dots: true,
        nav: false,
        responsive: {
            0: {
                items: 1
            },
            480: {
                items: 2
            },
            768: {
                items: 3
            },
            1024: {
                items: 3
            },
            1200: {
                items: 3           
            }
        }
    });
    


    // owl brand
    $('.js-owl-brandab').owlCarousel({
        margin: 30,
        autoplay: false,
        autoplayTimeout: 3000,
        loop: true,
        dots: false,
        nav: true,
        navText: ["<span class='fa fa-angle-left'></span>", "<span class='fa fa-angle-right'></span>"],
        responsive: {
            0: {
                items: 1
            },
            480: {
                items: 3
            },
            1024: {
                items: 5
            },
            1200: {
                items: 6
            }
        }
    });
    // product carousel
    // product carousel
    
   $('.js-owl-product').each( function() {
          var $carousel = $(this);
          $carousel.owlCarousel({
              dots : $carousel.data("dots"),
              autoplay:$carousel.data("autoplay"),
              items : $carousel.data("items"),
              loop : $carousel.data("loop"),
                slidespeed: $carousel.data("slidespeed"),
              margin : $carousel.data("margin"),
              nav : $carousel.data("nav"),
              navText: ["<span class='ion-ios-arrow-thin-left'></span>", "<span class='ion-ios-arrow-thin-right'></span>"],
              responsive : $carousel.data("responsive"),
          });
      });
	
  
  $('.grid-flat').masonry({
        itemSelector: '.grid-item',
        columnWidth: '.grid-sizer',
        percentPosition: true
    }); 
  
// Single element  
  $('.js-single').slick({
        autoplay: false,
        slidesToShow: 1,
        slidesToScroll: 1,
        infinite: true,
        arrows:true,
        dots: false,
    	prevArrow: '<span class="prev"><i class="fa fa-angle-left" aria-hidden="true"></i></span>',
        nextArrow: '<span class="next"><i class="fa fa-angle-right" aria-hidden="true"></i></span>',
    });
// js product more row  
  $('.js-multiple-row-arrow').each( function() {
    var slick = $(this),
    item =  $(this).data('item'),
    row =  $(this).data('row'); 
      $(this).slick({
        
        slidesToShow: item,
        
        prevArrow: '<span class="prev"><i class="fa fa-angle-left" aria-hidden="true"></i></span>',
        nextArrow: '<span class="next"><i class="fa fa-angle-right" aria-hidden="true"></i></span>',
        
        rows: row,
        
        responsive: [{
                breakpoint: 1025,
                settings: {
                    slidesToShow: 3,
                }
            },
            {
                breakpoint: 813,
                settings: {
                    slidesToShow: 2,
                }
            },
            {
                breakpoint: 480,
                settings: {
                                      
                    arrows: true,
                    prevArrow: '<span class="prev"><i class="fa fa-angle-left" aria-hidden="true"></i></span>',
                    nextArrow: '<span class="next"><i class="fa fa-angle-right" aria-hidden="true"></i></span>',
                    
                    infinite: true,
                    
                    slidesToShow: 2,
                    rows: 2,
                }
            }
        ]
    });
  }); 

   
    $('.js-owl-blog').each( function() {
          var $carousel = $(this);
          $carousel.owlCarousel({
              dots : $carousel.data("dots"),
              autoplay:$carousel.data("autoplay"),
              items : $carousel.data("items"),
              loop : $carousel.data("loop"),
                slidespeed: $carousel.data("slidespeed"),
              margin : $carousel.data("margin"),
              nav : $carousel.data("nav"),
              navText: ["<span class='fa fa-angle-left'></span>", "<span class='fa fa-angle-right'></span>"],
              responsive : $carousel.data("responsive"),
          });
      });

    
    $(".js-quickview-slide  .slick-arrow").on("click", function() {
        $(this).addClass('active');
    });
    
    // Instagram carousel




    // Js slider
     //Slick Slider
    
        $('.slick-slide-wrap').slick({
            centerMode: true,
            centerPadding: "26.2105263%",
            slidesToShow: 1,
            dots: false,
            prevArrow: "<span class='arrow-prev'><span class='arrow_sep'><span class='arrow_begin'></span><span class='arrow_end'></span><span class='arrow_top'></span><span class='arrow_bottom'></span></span></span>",
            nextArrow: "<span class='arrow-next'><span class='arrow_sep'><span class='arrow_begin'></span><span class='arrow_end'></span><span class='arrow_top'></span><span class='arrow_bottom'></span></span></span>",
            responsive: [
                {
                    breakpoint: 767,
                    settings: {
                        centerMode: false,
                    }
                }
            ]
        });
    
   
	// Js product single slider
    $('.js-click-product').slick({
        slidesToShow: 5,
        slidesToScroll: 1,
        asNavFor: '.js-product-slider',
        dots: false,
        focusOnSelect: true,
        infinite: true,
        arrows: false,
        
       
    });
    $('.js-product-slider').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: true,
      	
        asNavFor: '.js-click-product',
      	prevArrow:"<span class='slick-prev'><i class='ion-ios-arrow-thin-left' aria-hidden='true'></i></span>",
        nextArrow:"<span class='slick-next'><i class='ion-ios-arrow-thin-right' aria-hidden='true'></i></span>"
    });
  
	$('.js-click-product-v2').slick({
        slidesToShow: 5,
        slidesToScroll: 1,
        asNavFor: '.js-product-slider-v2',
        dots: false,
        focusOnSelect: true,
        infinite: true,
        arrows: true,
        prevArrow:"<span class='slick-prev'><i class='fa fa-angle-left' aria-hidden='true'></i></span>",
        nextArrow:"<span class='slick-next'><i class='fa fa-angle-right' aria-hidden='true'></i></span>"
    });
    $('.js-product-slider-v2').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        asNavFor: '.js-click-product-v2'
    });  
  
    // Slide Home Simple
    $('.js-slide-full').slick({
        dots: true,
        arrows: true,
        infinite: false,
        slidesToShow: 1,
        slidesToScroll: 1
    });
    
    $('.js-slide-dot').each( function() {
      var slick = $(this),
      dots =  $(this).data('dots'),
      arrow =  $(this).data('nav'), 
      autoplay =  $(this).data('autoplay'),
      infinity =  $(this).data('infinite'),
      speed =  $(this).data('autoplaySpeed'); 
        $(this).slick({
          dots: dots,
          arrows: arrow,
          autoplay:autoplay,
          infinite: infinity,
          autoplaySpeed : speed,
          slidesToShow: 1,
          slidesToScroll: 1
      });
  });

     if( $('#fullpage').length ){
     $('#fullpage').fullpage({
        css3:!0,
        navigation:!0,
        verticalCentered:!0,
        scrollOverflow:!1,
        sectionSelector:'.nomos-full-page-elem',
        autoScrolling:!0,
        scrollHorizontally:!0,
     });

  }

   
    //  Show more

    // Scroll slide homepage 2

    $('.slide-scroll').on('click', function() {
        $('html, body').animate({ scrollTop: $('section#contenthome2').offset().top }, 'slow');
        return false;
    });
    var handleScrollTop = function(e) {
        e.preventDefault();
        $('html, body').animate({ scrollTop: 0 }, 250);
    };
    // Footer to top
    $('footer > .scroll-top').on('click', function(e) {
        handleScrollTop(e);
    });

    $('.backto.vow-top').on('click', function(e) {
        handleScrollTop(e);
    });
    // Read more
    $(function() {
        var $header = $('.entry-content');
        var $half = parseInt($(".img-cal").height()) / 2;
        var $window = $(window).on('resize', function() {
            var height = $header.height() - $half;
            $header.height(height);
        }).trigger('resize'); //on page load


    });
    $(function() {

        var $el, $ps, $up, $p, totalHeight;

        $(".entry-content .btn-show").click(function() {

            // IE 7 doesn't even get this far. I didn't feel like dicking with it.

            totalHeight = 0

            $el = $(this);
            $p = $el.parent();
            $up = $p.parent();
            $ps = $up.find(".e-text");

            // measure how tall inside should be by adding together heights of all inside paragraphs (except read-more paragraph)
            $ps.each(function() {
                totalHeight += $(this).outerHeight();
                // FAIL totalHeight += $(this).css("margin-bottom");
            });

            $up
                .css({
                    // Set height to prevent instant jumpdown when max height is removed
                    "height": $up.height(),
                    "max-height": 9999,
                    "margin-bottom": 30
                })
                .animate({
                    "height": totalHeight
                });

            // fade out read-more
            $up.removeClass('active');
            $p.fadeOut();

            // prevent jump-down
            return false;

        });

    });
    // Open Search popup
    $(".search-toggle").on("click", function() {
        $('.search-form-wrapper').addClass('search--open');
        $('body').addClass('search-opened');
    });
    $(".btn-search-close").on("click", function() {
        $('.search-form-wrapper').removeClass('search--open');
        $('body').removeClass('search-opened');
    });
      $(document).on('keyup',function(evt) {
        if (evt.keyCode == 27) {
           $('.btn-search-close').addClass('btn--hidden');
            $('.search-form-wrapper').removeClass('search--open');
            $('body').removeClass('search-opened');
        }
    });
    // Open Account popup
    $(".js-user").on("click", function() {
        
        $('.account-form-wrapper').addClass('account--open');
        $('body').addClass('search-opened');
    });
    $(".btn-search-close").on("click", function() {
        $('.account-form-wrapper').removeClass('account--open', 1000);
        $('body').removeClass('search-opened');
    });
    //   Close promo
      $('.js-promo').click(function() {
          $('.funiter-promo').addClass('br-promotion--close')
        });

    // Lookbook
    


    $('.close_promo_pd').on('click',function(){
	$('.promo_info_single_product').addClass('hidden');
});
      $(window).scroll(function() {  
        var scroll = $(window).scrollTop();
        if (scroll > 50) {
          $(".header-sticky").addClass("is-ticky");
        }else{
          $(".header-sticky").removeClass("is-ticky");
        }
      });

    if ($(".single-product-detail").hasClass("engoc-product-design-sticky")) {
    var s, o, i = $(".entry-summary"),
        n = i.find(".summary-inner"),
        r = i.width(),
        l = $(".product-images"),
        c = l.find(".shopify-product-gallery__wrapper a"),
        d = $(window).height(),
        u = l.outerHeight(),
        p = 130,
        h = 600,
        m = i.outerHeight(),
        f = $(window).scrollTop(),
        g = l.offset().top,
        v = i.offset().left + 15,
        w = g + u,
        b = f + p + m;
        i.css({ height: m }),
        $(window).resize(function() {
            d = $(window).height(),
                m = i.outerHeight(),
                u = l.outerHeight(),
                m < d - p ? i.addClass("in-viewport").removeClass("not-in-viewport") : i.removeClass("in-viewport").addClass("not-in-viewport"), f = $(window).scrollTop(),
                b = f + p + m,
                r = i.width(),
                v = i.offset().left + 15,
                g = l.offset().top,
                w = g + u, r > h && (v += o = (r - h) / 2),
                f + p >= g ? (i.addClass("block-sticked"),
                    n.css({ top: p, width: r, position: "fixed", transform: "translateY(-20px)" })) : (i.removeClass("block-sticked"),
                    n.css({ top: "auto", left: "auto", width: "auto", position: "relative", transform: "translateY(0px)" })),
                b > w ? i.addClass("hide-temporary") : i.removeClass("hide-temporary"), d = $(window).height(),
                c.each(function() { s = $(this).offset().top, f > s - d + 20 && ($(this).addClass("animate-images")) })
        }),
        $(window).scroll(function() {
            d = $(window).height(),
                c.each(function() { s = $(this).offset().top, f > s - d + 20 && ($(this).addClass("animate-images")) })

            f = $(window).scrollTop(),
                b = f + p + m,
                r = i.width(),
                v = i.offset().left + 15,
                g = l.offset().top,
                w = g + u, r > h && (v += o = (r - h) / 2),
                f + p >= g ? (i.addClass("block-sticked"),
                    n.css({ height:$(window).height(), overflow:"auto", top: p, width: r, position: "fixed", transform: "translateY(-20px)" })) : (i.removeClass("block-sticked"),
                    n.css({ top: "auto", left: "auto", width: "auto", position: "relative", transform: "translateY(0px)" })),
                b > w ? i.addClass("hide-temporary") : i.removeClass("hide-temporary")

            d = $(window).height(),
                m = i.outerHeight(),
                u = l.outerHeight(),
                m < d - p ? i.addClass("in-viewport").removeClass("not-in-viewport") : i.removeClass("in-viewport").addClass("not-in-viewport"), d = $(window).height(),
                c.each(function() { s = $(this).offset().top, f > s - d + 20 && ($(this).addClass("animate-images")) }), d = $(window).height(),
                c.each(function() { s = $(this).offset().top, f > s - d + 20 && ($(this).addClass("animate-images")) })
        })
    }
});